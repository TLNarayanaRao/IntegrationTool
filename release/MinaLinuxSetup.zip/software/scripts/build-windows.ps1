$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location "$root/frontend"; npm install; npm run build; Pop-Location
& powershell -ExecutionPolicy Bypass -File "$root/scripts/build-java-bridge.ps1"
if ($LASTEXITCODE -ne 0) { throw 'Java bridge build failed.' }
Push-Location "$root/backend"
if (!(Test-Path .venv)) { py -3.12 -m venv .venv }
& .\.venv\Scripts\pip install -r requirements.txt pyinstaller
if ($LASTEXITCODE -ne 0) { throw 'Runtime dependency installation failed.' }
& .\.venv\Scripts\python.exe "$root\scripts\verify-web-dependencies.py"
if ($LASTEXITCODE -ne 0) { throw 'Web dependency verification failed.' }
& .\.venv\Scripts\pyinstaller --noconfirm --name MINA --add-data "..\frontend\dist;frontend\dist" --add-data "app;app" --paths . run_desktop.py
Pop-Location
if (!(Test-Path "$root/backend/dist/MINA/MINA.exe")) { throw 'PyInstaller runtime output was not created.' }
Copy-Item -Recurse -Force "$root/java-bridge/build" "$root/backend/dist/MINA/java-bridge"
if (Get-Command makensis -ErrorAction SilentlyContinue) { makensis "$root\scripts\installer.nsi" } else { Write-Host 'PyInstaller build complete. Install NSIS to generate setup.exe.' }
