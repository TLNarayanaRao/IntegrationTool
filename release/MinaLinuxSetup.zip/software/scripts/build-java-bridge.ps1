$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'resolve-java-home.ps1')
$javaHome = Resolve-MinaJavaHome
$source = "$root\java-bridge\src\com\mina\bridge\MinaJavaBridge.java"
$output = "$root\java-bridge\build"
$classes = "$output\classes"
$runtime = "$output\runtime"

if (Test-Path -LiteralPath $classes) {
    $checkedClasses = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $classes).Path)
    $expectedClasses = [System.IO.Path]::GetFullPath((Join-Path $root 'java-bridge\build\classes'))
    $parent = Get-Item -LiteralPath $output
    if ($checkedClasses -ine $expectedClasses -or
        (($parent.Attributes -bor (Get-Item -LiteralPath $classes).Attributes) -band [IO.FileAttributes]::ReparsePoint)) {
        throw "Refusing to replace an unexpected Java classes directory: $checkedClasses"
    }
    Remove-Item -Recurse -Force -LiteralPath $checkedClasses
}
New-Item -ItemType Directory -Force -Path $classes | Out-Null
& (Join-Path $javaHome 'bin\javac.exe') -encoding UTF-8 -d $classes $source
if ($LASTEXITCODE -ne 0) { throw "Java connector compilation failed with exit code $LASTEXITCODE" }
if (Test-Path $runtime) {
    $checkedRuntime = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $runtime).Path)
    $expectedRuntime = [System.IO.Path]::GetFullPath((Join-Path $root 'java-bridge\build\runtime'))
    if ($checkedRuntime -ine $expectedRuntime -or ((Get-Item -LiteralPath $runtime).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw "Refusing to replace an unexpected Java build directory: $checkedRuntime"
    }
    # The Studio/runtime can leave the bundled JVM alive after a debug session.
    # Stop only java.exe launched from this exact build directory; never stop
    # an unrelated system or developer Java process.
    $runtimeJava = [System.IO.Path]::GetFullPath((Join-Path $runtime 'bin\java.exe'))
    $lockedProcesses = @(Get-Process -Name java,javaw -ErrorAction SilentlyContinue | Where-Object {
        try { $_.Path -and ([System.IO.Path]::GetFullPath($_.Path) -ieq $runtimeJava) } catch { $false }
    })
    foreach ($process in $lockedProcesses) {
        Write-Host "Stopping project Java runtime process $($process.Id) before replacing the bundled runtime."
        Stop-Process -Id $process.Id -Force -ErrorAction Stop
    }
    if ($lockedProcesses.Count -gt 0) { Start-Sleep -Milliseconds 500 }

    $removed = $false
    for ($attempt = 1; $attempt -le 5 -and !$removed; $attempt++) {
        try {
            Remove-Item -Recurse -Force -LiteralPath $runtime -ErrorAction Stop
            $removed = $true
        } catch {
            if ($attempt -eq 5) { throw }
            Start-Sleep -Milliseconds 500
        }
    }
}
& (Join-Path $javaHome 'bin\jlink.exe') --add-modules java.base,java.sql,java.naming,java.logging,java.management,java.security.jgss,java.xml,jdk.crypto.ec,jdk.naming.dns --strip-debug --no-header-files --no-man-pages --output $runtime
if ($LASTEXITCODE -ne 0) { throw "Bundled Java runtime creation failed with exit code $LASTEXITCODE" }
Write-Host "Java connector bridge ready: $output"
