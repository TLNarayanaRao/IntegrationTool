param([string]$Version = $env:MINA_VERSION)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$admin = Join-Path $root 'administrator'
if ([string]::IsNullOrWhiteSpace($Version)) { $Version = '2.1.0' }
$Version = $Version.Trim()
if ($Version -notmatch '^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$') { throw "Invalid semantic version '$Version'." }
Push-Location $admin
try {
    if (!(Test-Path .venv)) {
        if (Get-Command py -ErrorAction SilentlyContinue) { py -3.11 -m venv .venv }
        else { python -m venv .venv }
    }
    & .\.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
    if ($LASTEXITCODE -ne 0) { throw 'Administrator dependency installation failed.' }
    & .\.venv\Scripts\python.exe "$root\scripts\verify-web-dependencies.py"
    if ($LASTEXITCODE -ne 0) { throw 'Administrator web dependency verification failed.' }
    $buildInfo = Join-Path $admin 'build\build_info.json'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $buildInfo) | Out-Null
    @{ version = $Version; builtAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath $buildInfo -Encoding utf8
    & .\.venv\Scripts\pyinstaller.exe --noconfirm --clean --name MinaAdministrator --add-data "$admin\web;web" --add-data "$buildInfo;." --paths "$admin" run_admin.py
    New-Item -ItemType Directory -Force -Path "$admin\dist\MinaAdministrator\bin" | Out-Null
    Copy-Item -LiteralPath "$admin\bin\minaadmin.cmd" -Destination "$admin\dist\MinaAdministrator\bin\minaadmin.cmd" -Force
    New-Item -ItemType Directory -Force -Path "$admin\release" | Out-Null
    $archive = "$admin\release\MinaAdministrator-$Version-Windows-x64.zip"
    if (Test-Path $archive) { Remove-Item -LiteralPath $archive -Force }
    Compress-Archive -Path "$admin\dist\MinaAdministrator\*" -DestinationPath $archive
    Write-Host "Windows Administrator $Version ready: $admin\dist\MinaAdministrator\MinaAdministrator.exe"
    Write-Host "Windows distribution: $archive"
} finally { Pop-Location }
