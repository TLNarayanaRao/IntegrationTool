$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

function Assert-CommandSucceeded([string]$Step, [int]$ExitCode) {
    if ($ExitCode -ne 0) {
        throw "$Step failed with exit code $ExitCode. Correct the first reported error before continuing."
    }
}

if (!(Test-Path "$root\frontend\node_modules\electron\dist\electron.exe")) {
    if (!(Test-Path "$root\frontend\node_modules\electron\install.js")) {
        throw "Electron dependencies are incomplete. Run npm ci successfully in frontend before desktop:installer."
    }
    Push-Location "$root\frontend"
    try {
        node node_modules\electron\install.js
        Assert-CommandSucceeded 'Electron binary download' $LASTEXITCODE
    } finally { Pop-Location }
}

Push-Location "$root\frontend"
try {
    npm.cmd run build
    Assert-CommandSucceeded 'Frontend production build' $LASTEXITCODE

    # Fail early if an interrupted or partially-cleaned Vite build leaves
    # index.html pointing at an asset that was not written to dist. Without
    # this check the backend can start successfully while the Studio renders
    # a blank page after the browser receives a 404 for the entry module.
    $distPath = Join-Path $root 'frontend\dist'
    $indexPath = Join-Path $distPath 'index.html'
    if (!(Test-Path -LiteralPath $indexPath)) {
        throw "Frontend build did not produce $indexPath."
    }
    $indexHtml = Get-Content -LiteralPath $indexPath -Raw
    $assetReferences = [regex]::Matches($indexHtml, '(?:src|href)="(/assets/[^"]+)"') |
        ForEach-Object { $_.Groups[1].Value }
    if (!$assetReferences -or $assetReferences.Count -eq 0) {
        throw "Frontend entry point contains no generated asset references: $indexPath"
    }
    foreach ($assetReference in $assetReferences) {
        $assetPath = Join-Path $distPath ($assetReference.TrimStart('/') -replace '/', '\')
        if (!(Test-Path -LiteralPath $assetPath)) {
            throw "Frontend entry point references a missing asset '$assetReference'. Re-run the build before packaging."
        }
    }
    Write-Host "Frontend asset manifest verified ($($assetReferences.Count) assets)."
} finally { Pop-Location }

& "$root\scripts\build-java-bridge.ps1"
Assert-CommandSucceeded 'Java connector bridge build' $LASTEXITCODE

Push-Location "$root\backend"
try {
    $venvPath = "$root\backend\.venv"
    $buildPython = Join-Path $venvPath 'Scripts\python.exe'
    if (Test-Path $buildPython) {
        $existingVersion = & $buildPython -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($LASTEXITCODE -ne 0) {
            # A checked-in or previously created venv can retain a launcher
            # for a Python installation that was later removed. Do not block
            # a fresh package build on that stale interpreter; use the
            # isolated packaging environment below instead.
            Write-Warning "backend\.venv references an unavailable Python interpreter; using an isolated Python 3.11 packaging environment."
            $venvPath = "$root\backend\build\.venv311"
            $buildPython = Join-Path $venvPath 'Scripts\python.exe'
        } elseif ($existingVersion.Trim() -ne '3.11') {
            Write-Host "backend\.venv uses Python $existingVersion; using an isolated Python 3.11 packaging environment instead."
            $venvPath = "$root\backend\build\.venv311"
            $buildPython = Join-Path $venvPath 'Scripts\python.exe'
        }
    }
    if (!(Test-Path $buildPython)) {
        $creator = $env:MINA_BUILD_PYTHON
        $creatorArgs = @()
        if ([string]::IsNullOrWhiteSpace($creator)) {
            if (Get-Command py -ErrorAction SilentlyContinue) {
                $creator = 'py'; $creatorArgs = @('-3.11')
            } else {
                $creator = 'python'
            }
        }
        $creatorVersion = & $creator @creatorArgs -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
        Assert-CommandSucceeded 'Python 3.11 packaging interpreter detection' $LASTEXITCODE
        if ($creatorVersion.Trim() -ne '3.11') {
            throw "Desktop runtime builds require Python 3.11, but '$creator' resolves to Python $creatorVersion. Install Python 3.11 x64 or set MINA_BUILD_PYTHON to its python.exe."
        }
        & $creator @creatorArgs -m venv $venvPath
        Assert-CommandSucceeded 'Python 3.11 packaging environment creation' $LASTEXITCODE
    }
    $runtimePython = & $buildPython -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
    Assert-CommandSucceeded 'Python version detection' $LASTEXITCODE
    if ($runtimePython.Trim() -ne '3.11') {
        throw "Desktop runtime builds require Python 3.11, but the packaging environment uses Python $runtimePython. Install Python 3.11 x64 and retry."
    }
    # A venv created by older Python tooling can retain setuptools 65.x. That
    # release imports pkgutil.ImpImporter, which was removed in Python 3.12.
    # Upgrade the isolated build toolchain explicitly before PyInstaller runs.
    & $buildPython -m pip install --upgrade -r requirements-build.txt
    Assert-CommandSucceeded 'Python build-tool installation' $LASTEXITCODE
    & $buildPython -m pip install -r requirements.txt
    Assert-CommandSucceeded 'Python runtime dependency installation' $LASTEXITCODE
    & $buildPython "$root\scripts\verify-web-dependencies.py"
    Assert-CommandSucceeded 'Web dependency security version verification' $LASTEXITCODE
    & $buildPython "$root\scripts\verify-runtime-dependencies.py"
    Assert-CommandSucceeded 'Runtime connector dependency verification' $LASTEXITCODE
    & $buildPython -m compileall -q app run_sidecar.py
    Assert-CommandSucceeded 'Python 3.11 backend syntax verification' $LASTEXITCODE
    & $buildPython -c "import app.main; print('Backend application package import passed')"
    Assert-CommandSucceeded 'Backend application package verification' $LASTEXITCODE
    # Explicitly collect the local `app` package. Some clean Python 3.11
    # environments resolve generic namespace packages differently during
    # analysis, which can otherwise produce an EXE without app.main.
    # Raw Python export reads the engine and support .py files at runtime.
    # PyInstaller's module archive is importable but not readable as source.
    & $buildPython -m PyInstaller --noconfirm --clean --name MINARuntime --add-data "$root\frontend\dist;frontend\dist" --add-data "$root\backend\app;app" --paths "$root\backend" --hidden-import app.main --hidden-import ibm_db --hidden-import ibm_db_dbi --collect-submodules app --collect-submodules databricks run_sidecar.py
    Assert-CommandSucceeded 'Runtime executable build' $LASTEXITCODE
    & $buildPython -m PyInstaller --noconfirm --clean --name MINAWorker --add-data "$root\backend\app;app" --paths "$root\backend" --hidden-import app.main --hidden-import ibm_db --hidden-import ibm_db_dbi --collect-submodules app --collect-submodules databricks run_deployment.py
    Assert-CommandSucceeded 'Deployment worker executable build' $LASTEXITCODE
} finally { Pop-Location }

if (!(Test-Path "$root\backend\dist\MINARuntime\MINARuntime.exe")) {
    throw "Runtime executable output was not created."
}
if (!(Test-Path "$root\backend\dist\MINAWorker\MINAWorker.exe")) {
    throw "Deployment worker executable output was not created."
}
Copy-Item -Recurse -Force "$root\java-bridge\build" "$root\backend\dist\MINARuntime\java-bridge"
Copy-Item -Recurse -Force "$root\java-bridge\build" "$root\backend\dist\MINAWorker\java-bridge"
& $buildPython "$root\scripts\smoke-test-packaged-runtime.py" "$root\backend\dist\MINARuntime\MINARuntime.exe"
Assert-CommandSucceeded 'Packaged runtime health check' $LASTEXITCODE
Write-Host "Electron sidecar ready: $root\backend\dist\MINARuntime"
Write-Host "Deployment worker ready: $root\backend\dist\MINAWorker"
