# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['run_admin.py'],
    pathex=['D:/Integration-tool/IntegrationFabric/administrator'],
    binaries=[],
    datas=[('D:/Integration-tool/IntegrationFabric/administrator/web', 'web')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='IntegrationFabricAdministrator',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='IntegrationFabricAdministrator',
)
