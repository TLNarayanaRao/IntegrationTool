"""Standalone MINA deployment worker.

This entry point is intentionally separate from ``run_sidecar.py``.  The
sidecar serves Studio's HTTP API; this worker executes one packaged
application under Control Plane lifecycle management.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path


def load_project(application: Path):
    from app.models import Project

    python_descriptor = application / "python" / "project.py"
    if python_descriptor.is_file():
        # Python archives are a deliberate executable artifact type. The
        # Control Plane authorizes their upload through application-manager
        # RBAC before this worker imports the generated source package.
        try:
            package_name = f'_mina_generated_{hashlib.sha256(str(application).encode()).hexdigest()[:16]}'
            spec = importlib.util.spec_from_file_location(package_name, python_descriptor, submodule_search_locations=[str(python_descriptor.parent)])
            if not spec or not spec.loader: raise ValueError('Python application module could not be loaded')
            module = importlib.util.module_from_spec(spec)
            sys.modules[package_name] = module
            spec.loader.exec_module(module)
            builder = getattr(module, 'build_project', None)
            project = builder() if callable(builder) else None
        except (OSError, SyntaxError, ValueError, TypeError, ImportError) as exc:
            raise ValueError(f"Invalid generated Python application descriptor: {exc}") from exc
        if not isinstance(project, Project):
            raise ValueError("Generated Python application descriptor must define build_project() returning Project")
        return project
    project_file = application / "project.json"
    if not project_file.is_file():
        raise FileNotFoundError(f"Packaged application descriptor not found: {project_file}")
    project = Project.model_validate(json.loads(project_file.read_text(encoding="utf-8")))
    return project


async def run_deployment(application: Path, environment: str) -> None:
    from app.main import (
        _continuous_event_loop,
        _continuous_sap_event_loop,
        _environment_values,
        _event_subscription,
        _publish_runtime_state,
        append_project_logs as persist_logs,
        effective_event_activities,
        runtime,
    )
    import app.main as runtime_api

    project = load_project(application)
    profile_file = application.parent / "environments" / f"{environment}.json"
    if profile_file.is_file():
        try:
            profile_values = json.loads(profile_file.read_text(encoding="utf-8"))
            from app.models import EnvironmentProperty
            if not isinstance(profile_values, list): raise ValueError("profile must be an array")
            project.properties[environment] = [EnvironmentProperty.model_validate(value) for value in profile_values]
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError(f"Invalid deployment environment profile {profile_file}: {exc}") from exc
    if environment not in project.properties:
        raise ValueError(f"Environment {environment!r} is not present in the packaged application")
    project.active_environment = environment

    # Secrets are injected by the Control Plane into the worker environment.
    # Overlay them onto the sanitized package profile without writing them to
    # disk or altering the package.
    for prop in project.properties[environment]:
        if prop.key in os.environ:
            prop.value = os.environ[prop.key]

    # The Control Plane redirects stdout/stderr to the per-instance log. Also
    # persist structured records using the same bounded logger as Studio and
    # mirror them to stdout so deployment logs work for packaged workers.
    def record_logs(project_id, project_name, entries, configured_directory=""):
        persist_logs(project_id, project_name, entries, configured_directory)
        for entry in entries or []:
            print(json.dumps({"projectId": project_id, "project": project_name, **entry}, ensure_ascii=False, default=str), flush=True)

    runtime_api.append_project_logs = record_logs
    resources = {resource.id: resource for resource in project.resources}
    tasks = [task for task in project.tasks if task.kind == "starter"]
    enabled = os.environ.get("MINA_ENABLED_STARTERS", "").strip()
    if enabled:
        try:
            enabled_ids = set(json.loads(enabled))
            tasks = [task for task in tasks if task.id in enabled_ids]
        except (TypeError, ValueError, json.JSONDecodeError):
            print(json.dumps({"level": "WARNING", "kind": "configuration", "message": "Ignoring invalid MINA_ENABLED_STARTERS"}), flush=True)
    if not tasks:
        raise ValueError("The packaged application has no enabled Starter Tasks")

    startup = {"time": runtime_api.log_timestamp(), "level": "INFO", "kind": "lifecycle", "message": f"Deployment worker started: {project.name}", "environment": environment}
    record_logs(project.id, project.name, [startup], str(_environment_values(project, environment).get("runtime.logDirectory") or ""))

    async def run_one(task):
        events = effective_event_activities(task.activities, task.transitions)
        event = events[0] if events and events[0].type != "start" else None
        if event is not None:
            subscription = _event_subscription(project, task, event, environment)
            print(json.dumps({"projectId": project.id, "project": project.name, "level": "INFO", "kind": "endpoint", "message": f"{event.name} listener ready", "subscription": subscription}, ensure_ascii=False, default=str), flush=True)
            if event.type == "sap":
                await _continuous_sap_event_loop(project, task, event, environment)
            else:
                await _continuous_event_loop(project, task, event, environment)
            return
        result = await runtime.run(task, {}, resources, _environment_values(project, environment), project=project)
        record_logs(project.id, project.name, result.logs, str(_environment_values(project, environment).get("runtime.logDirectory") or ""))
        if result.status != "completed":
            raise RuntimeError(f"Starter Task {task.name} finished with status {result.status}")

    await asyncio.gather(*(run_one(task) for task in tasks))
    # A one-shot application remains managed until Control Plane stops it.
    await asyncio.Event().wait()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a packaged MINA application")
    parser.add_argument("--application", required=True, help="Path to the packaged application directory")
    parser.add_argument("--environment", "--env", dest="environment", default=None)
    # Accept the environment as a positional fallback as well. This keeps
    # deployments compatible with Windows command-line wrappers that can
    # separate a quoted option value while CreateProcess parses the command.
    parser.add_argument("environment_positional", nargs="?")
    args = parser.parse_args()
    environment = args.environment or args.environment_positional or os.environ.get("MINA_ENVIRONMENT", "local")
    try:
        asyncio.run(run_deployment(Path(args.application).resolve(), environment))
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print(json.dumps({"level": "ERROR", "kind": "runtime", "message": str(exc)}, ensure_ascii=False), file=sys.stderr, flush=True)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
