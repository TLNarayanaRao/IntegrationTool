import io, json, tarfile, tempfile, unittest, zipfile
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from app.main import app
from app.project_logging import close_project_log_handlers
from unittest.mock import patch

class TaskRuntimeTests(unittest.TestCase):
    def setUp(self): self.client = TestClient(app)

    def test_activity_testing_starts_paused_and_accepts_whole_payload(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        session = None
        try:
            with patch('app.main._start_continuous_listener') as listener:
                response = self.client.post('/api/projects/task-runtime-test/debug', json={
                    'task_id': 'main', 'input': {}, 'test_mode': True})
                self.assertEqual(response.status_code, 200, response.text)
                state = response.json()
                session = state['sessionId']
                self.assertEqual(state['status'], 'paused')
                self.assertEqual(state['currentActivityId'], 's')
                listener.assert_not_called()
            endpoint = f'/api/debug/{session}/action'
            edited = self.client.post(endpoint, json={'action': 'set_value', 'path': 'input', 'value': None})
            self.assertEqual(edited.status_code, 200, edited.text)
            self.assertIsNone(edited.json()['variables']['input'])
            tested = self.client.post(endpoint, json={'action': 'test_activity', 'activity_id': 's', 'value': [1, 2]})
            self.assertEqual(tested.status_code, 200, tested.text)
            self.assertEqual(tested.json()['lastActivityTest']['output'], [1, 2])
            self.assertEqual(tested.json()['currentActivityId'], 's')
        finally:
            if session: self.client.post(f'/api/debug/{session}/action', json={'action': 'stop'})
            self.client.delete('/api/projects/task-runtime-test')

    def test_package_failure_reports_cause_and_persists_diagnostics(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        try:
            with tempfile.TemporaryDirectory() as folder, \
                 patch('app.main._project_log_directory', return_value=folder), \
                 patch('app.main.build_deployment_archive', side_effect=FileNotFoundError('Python engine source is missing')):
                response = self.client.get('/api/projects/task-runtime-test/package?archive=python&environment=local')
                self.assertEqual(response.status_code, 500)
                self.assertIn('Python engine source is missing', response.json()['detail'])
                self.assertIn('See project log:', response.json()['detail'])
                log_path = Path(folder) / 'Task-Runtime-Test' / 'Task-Runtime-Test.log'
                self.assertTrue(log_path.exists())
                entry = json.loads(log_path.read_text(encoding='utf-8').splitlines()[-1])
                self.assertEqual(entry['kind'], 'packaging')
                self.assertIn('FileNotFoundError', entry['traceback'])
                close_project_log_handlers('task-runtime-test')
        finally:
            self.client.delete('/api/projects/task-runtime-test')

    def project(self):
        return {
            'id':'task-runtime-test','name':'Task Runtime Test','description':'',
            'resources':[{'id':'k1','type':'kafka','name':'Local Kafka','config':{'mode':'memory'}}],
            'properties':{'local':[],'dev':[],'qa':[],'pre':[],'production':[]},'active_environment':'local','schemas':[],
            'tasks':[
                {'id':'main','name':'Starter','kind':'starter','activities':[
                    {'id':'s','type':'start','name':'Start','position':{'x':0,'y':0},'config':{}},
                    {'id':'c','type':'call_task','name':'Call child','position':{'x':1,'y':0},'config':{'taskId':'child','inputMappings':{'value':'${input.value}'}}},
                    {'id':'p','type':'kafka','name':'Publish','position':{'x':2,'y':0},'config':{'operation':'publish','resourceId':'k1','topic':'orders','message':'${last}'}},
                    {'id':'r','type':'kafka','name':'Receive','position':{'x':3,'y':0},'config':{'operation':'receive','resourceId':'k1','topic':'orders','maxMessages':1}},
                    {'id':'e','type':'end','name':'End','position':{'x':4,'y':0},'config':{}}],
                 'transitions':[{'id':'1','source':'s','target':'c'},{'id':'2','source':'c','target':'p'},{'id':'3','source':'p','target':'r'},{'id':'4','source':'r','target':'e'}]},
                {'id':'child','name':'Child','kind':'subtask','activities':[
                    {'id':'cs','type':'start','name':'Start','position':{'x':0,'y':0},'config':{'interfaceSchemaText':'{"type":"object","properties":{"value":{"type":"integer"}}}'}},
                    {'id':'ce','type':'end','name':'End','position':{'x':1,'y':0},'config':{'interfaceSchemaText':'{"type":"object","properties":{"answer":{"type":"object","properties":{"value":{"type":"integer"}}}}}', 'inputMappings':{'answer.value':'${input.value}'}}}],
                 'transitions':[{'id':'c1','source':'cs','target':'ce'}]}
            ],'active_task_id':'main'
        }

    def test_subtask_messaging_export_import_and_debug(self):
        payload = self.project()
        payload['properties']['production'] = [{'key':'custom.password','value':'do-not-package','data_type':'password'}]
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        result = self.client.post('/api/projects/task-runtime-test/run', json={'task_id':'main','input':{'value':42},'environment':'local'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['status'], 'completed')
        self.assertEqual(result.json()['output']['count'], 1)
        self.assertEqual(result.json()['activity_outputs']['c']['output'], {'answer': {'value': 42}})
        self.assertEqual(result.json()['task_outputs']['child']['output'], {'answer': {'value': 42}})
        exported = self.client.get('/api/projects/task-runtime-test/export')
        self.assertEqual(exported.status_code, 200)
        self.assertIn('filename="Task-Runtime-Test.mpackage"', exported.headers['content-disposition'])
        with zipfile.ZipFile(io.BytesIO(exported.content)) as archive:
            self.assertIn('tasks/child.json', archive.namelist())
            self.assertIn('resources/kafka/k1.json', archive.namelist())
        imported = self.client.post('/api/projects/import', files={'file':('project.mpackage', exported.content, 'application/zip')})
        self.assertEqual(imported.status_code, 200)
        self.assertEqual(len(imported.json()['tasks']), 2)
        for legacy_name in ('project.ifproject', 'project.ifpackage'):
            legacy = self.client.post('/api/projects/import', files={'file':(legacy_name, exported.content, 'application/zip')})
            self.assertEqual(legacy.status_code, 200, legacy.text)
        debug = self.client.post('/api/projects/task-runtime-test/debug', json={'task_id':'main','input':{'value':42},'breakpoints':['c']})
        self.assertEqual(debug.status_code, 200)
        stepped = self.client.post(f"/api/debug/{debug.json()['sessionId']}/action", json={'action':'step_over'})
        self.assertEqual(stepped.status_code, 200)
        self.assertEqual(stepped.json()['currentActivityId'], 'c')
        entered = self.client.post(f"/api/debug/{debug.json()['sessionId']}/action", json={'action':'step_in'})
        self.assertEqual(entered.json()['currentTaskId'], 'child')
        self.assertEqual(entered.json()['currentActivityId'], 'cs')
        child_step = self.client.post(f"/api/debug/{debug.json()['sessionId']}/action", json={'action':'step_over'})
        self.assertEqual(child_step.json()['currentActivityId'], 'ce')
        returned = self.client.post(f"/api/debug/{debug.json()['sessionId']}/action", json={'action':'step_out'})
        self.assertEqual(returned.json()['currentTaskId'], 'main')
        self.assertEqual(returned.json()['currentActivityId'], 'p')
        captured = returned.json()['taskOutputs']
        self.assertEqual(captured['child']['input'], {'value': 42})
        self.assertEqual(captured['child']['activities']['ce']['output'], {'answer': {'value': 42}})
        self.assertEqual(captured['main']['activities']['c']['calledTaskId'], 'child')
        self.assertEqual(captured['main']['activities']['c']['input'], {'value': 42})
        self.assertEqual(returned.json()['activityOutputs']['c']['output'], {'answer': {'value': 42}})
        json_file = self.client.get('/api/projects/task-runtime-test/json')
        self.assertEqual(json_file.status_code, 200)
        self.assertEqual(json.loads(json_file.content)['id'], 'task-runtime-test')
        mina_package = self.client.get('/api/projects/task-runtime-test/package?target=cloud&environment=production')
        self.assertEqual(mina_package.status_code, 200)
        self.assertIn('filename="task-runtime-test-1.0.0-cloud.mpkg"', mina_package.headers['content-disposition'])
        cloud_package = self.client.get('/api/projects/task-runtime-test/package?target=cloud&environment=production&archive=ifpkg')
        self.assertEqual(cloud_package.status_code, 200)
        self.assertIn('filename="task-runtime-test-1.0.0-cloud.ifpkg"', cloud_package.headers['content-disposition'])
        self.assertNotIn(b'do-not-package', cloud_package.content)
        with zipfile.ZipFile(io.BytesIO(cloud_package.content)) as archive:
            names = archive.namelist()
            self.assertIn('deployment/cloud/Dockerfile', names)
            self.assertIn('deployment/cloud/configmap.yaml', names)
            self.assertIn('deployment/cloud/secret.yaml', names)
            self.assertIn('deployment/cloud/deployment.yaml', names)
            self.assertIn('deployment/cloud/service.yaml', names)
            self.assertIn('deployment/cloud/hpa.yaml', names)
            self.assertIn('deployment/cloud/kustomization.yaml', names)
            manifest = json.loads(archive.read('manifest.json'))
            self.assertEqual(manifest['target'], 'cloud')
            self.assertIn('deployment', manifest['selectedArtifacts'])
        selected_cloud = self.client.get('/api/projects/task-runtime-test/package?target=cloud&environment=production&archive=ifpkg&artifacts=deployment,service')
        self.assertEqual(selected_cloud.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(selected_cloud.content)) as archive:
            self.assertIn('deployment/cloud/deployment.yaml', archive.namelist())
            self.assertIn('deployment/cloud/service.yaml', archive.namelist())
            self.assertNotIn('deployment/cloud/Dockerfile', archive.namelist())
            self.assertNotIn('deployment/cloud/secret.yaml', archive.namelist())
        on_prem_package = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environment=production&archive=tar.gz')
        self.assertEqual(on_prem_package.status_code, 200)
        with tarfile.open(fileobj=io.BytesIO(on_prem_package.content), mode='r:gz') as archive:
            self.assertIsNotNone(archive.getmember('deployment/on-prem/application.json'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/environment.properties'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/deploy.sh'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/install.sh'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/deploy.ps1'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/install.ps1'))
            self.assertIsNotNone(archive.getmember('deployment/on-prem/start.ps1'))
        deleted = self.client.delete('/api/projects/task-runtime-test')
        self.assertEqual(deleted.status_code, 200)
        self.assertEqual(self.client.get('/api/projects/task-runtime-test').status_code, 404)

    def test_success_fans_out_to_all_parallel_branches(self):
        payload = self.project()
        task = payload['tasks'][0]
        task['activities'] = [
            {'id':'s','type':'start','name':'Start','config':{}},
            {'id':'fan','type':'log','name':'Fan out','config':{'message':'fan'}},
            {'id':'a','type':'log','name':'Branch A','config':{'message':'a'}},
            {'id':'b','type':'log','name':'Branch B','config':{'message':'b'}},
            {'id':'e','type':'end','name':'End','config':{}},
        ]
        task['transitions'] = [
            {'id':'1','source':'s','target':'fan'},
            {'id':'2','source':'fan','target':'a','type':'success'},
            {'id':'3','source':'fan','target':'b','type':'success'},
            {'id':'4','source':'a','target':'e'},
            {'id':'5','source':'b','target':'e'},
        ]
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        result = self.client.post('/api/projects/task-runtime-test/run', json={'task_id':'main','input':{},'environment':'local'})
        self.assertEqual(result.status_code, 200)
        body = result.json()
        self.assertEqual(body['status'], 'completed')
        self.assertIn('a', body['activity_outputs'])
        self.assertIn('b', body['activity_outputs'])
        self.assertIsNotNone(body['activity_outputs']['a']['output'])
        self.assertIsNotNone(body['activity_outputs']['b']['output'])
        debug = self.client.post('/api/projects/task-runtime-test/debug', json={'task_id':'main','input':{}})
        self.assertEqual(debug.status_code, 200)
        debug_run = self.client.post(f"/api/debug/{debug.json()['sessionId']}/action", json={'action':'continue'})
        self.assertEqual(debug_run.status_code, 200)
        self.assertEqual(debug_run.json()['status'], 'completed')
        self.assertIn('a', debug_run.json()['activityOutputs'])
        self.assertIn('b', debug_run.json()['activityOutputs'])

    def test_dynamic_subtask_override_is_resolved_from_environment_properties(self):
        payload = self.project()
        payload['properties']['local'] = [{'key':'routing.targetTask','value':'Child','data_type':'string'}]
        call = next(item for item in payload['tasks'][0]['activities'] if item['type'] == 'call_task')
        call['config']['taskId'] = 'missing-static-fallback'
        call['config']['dynamicTaskId'] = '${properties.routing.targetTask}'
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        result = self.client.post('/api/projects/task-runtime-test/run', json={'task_id':'main','input':{'value':42},'environment':'local'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['activity_outputs']['c']['output'], {'answer': {'value': 42}})
        self.client.delete('/api/projects/task-runtime-test')

    def test_multi_environment_package_has_common_application_and_profile_specific_descriptors(self):
        payload = self.project()
        payload['properties']['dev'] = [{'key':'service.url','value':'https://dev.example','data_type':'string'}, {'key':'service.password','value':'dev-secret','data_type':'password'}]
        payload['properties']['qa'] = [{'key':'service.url','value':'https://qa.example','data_type':'string'}, {'key':'service.password','value':'qa-secret','data_type':'password'}]
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        response = self.client.get('/api/projects/task-runtime-test/package?target=cloud&environments=dev,qa&archive=ifpkg&artifacts=configmap,secret,deployment,service,package')
        self.assertEqual(response.status_code, 200, response.text)
        self.assertNotIn(b'dev-secret', response.content); self.assertNotIn(b'qa-secret', response.content)
        with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
            names = archive.namelist()
            self.assertIn('application/project.json', names)
            self.assertIn('environments/dev.json', names); self.assertIn('environments/qa.json', names)
            self.assertIn('deployment/cloud/profiles/dev/configmap.yaml', names)
            self.assertIn('deployment/cloud/profiles/qa/configmap.yaml', names)
            self.assertIn('deployment/cloud/profiles/dev/deployment.yaml', names)
            self.assertIn('deployment/cloud/profiles/qa/secret.yaml', names)
            manifest = json.loads(archive.read('manifest.json'))
            self.assertEqual(manifest['environments'], ['dev', 'qa'])
            self.assertEqual(json.loads(archive.read('application/project.json'))['properties'].keys(), {'dev', 'qa'})
            self.assertIn(b'https://dev.example', archive.read('deployment/cloud/profiles/dev/configmap.yaml'))
            self.assertIn(b'https://qa.example', archive.read('deployment/cloud/profiles/qa/configmap.yaml'))
        self.client.delete('/api/projects/task-runtime-test')

    def test_package_includes_selected_starters_and_only_transitive_subtask_dependencies(self):
        payload = self.project()
        payload['tasks'].extend([
            {'id':'secondary','name':'Secondary Starter','kind':'starter','activities':[{'id':'ss','type':'start','name':'Start','position':{'x':0,'y':0},'config':{}},{'id':'se','type':'end','name':'End','position':{'x':1,'y':0},'config':{}}], 'transitions':[{'id':'s1','source':'ss','target':'se'}]},
            {'id':'orphan','name':'Unused Sub Task','kind':'subtask','activities':[{'id':'os','type':'start','name':'Start','position':{'x':0,'y':0},'config':{}},{'id':'oe','type':'end','name':'End','position':{'x':1,'y':0},'config':{}}], 'transitions':[{'id':'o1','source':'os','target':'oe'}]},
        ])
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environments=dev&starters=main&archive=ifpkg')
        self.assertEqual(response.status_code, 200, response.text)
        with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
            names = archive.namelist()
            self.assertIn('application/tasks/main.json', names)
            self.assertIn('application/tasks/child.json', names)
            self.assertNotIn('application/tasks/secondary.json', names)
            self.assertNotIn('application/tasks/orphan.json', names)
            project = json.loads(archive.read('application/project.json'))
            self.assertEqual([task['id'] for task in project['tasks']], ['main', 'child'])
            manifest = json.loads(archive.read('manifest.json'))
            self.assertEqual(manifest['starterTaskIds'], ['main'])
            self.assertEqual(manifest['includedTaskIds'], ['main', 'child'])
        self.client.delete('/api/projects/task-runtime-test')

    def test_python_archive_contains_direct_async_source_without_mina_descriptors(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environments=dev&starters=main&archive=python')
        self.assertEqual(response.status_code, 200, response.text)
        self.assertIn('filename="task-runtime-test-1.0.0-on-prem.pympkg"', response.headers['content-disposition'])
        with tempfile.TemporaryDirectory() as folder, zipfile.ZipFile(io.BytesIO(response.content)) as archive:
            names = archive.namelist()
            self.assertIn('application/main.py', names)
            self.assertIn('application/tasks/task_0_main.py', names)
            self.assertIn('application/tasks/task_1_child.py', names)
            self.assertIn('application/engine/runtime.py', names)
            self.assertIn('application/project.py', names)
            self.assertNotIn('application/project.json', names)
            self.assertNotIn('application/tasks/main.json', names)
            self.assertNotIn('application/resources/kafka/k1.json', names)
            self.assertNotIn('application/python/mina_dsl.py', names)
            self.assertIn(b'async def run(initial=', archive.read('application/tasks/task_0_main.py'))
            task_source = archive.read('application/tasks/task_0_main.py')
            self.assertIn(b"Activity(\n            id='s'", task_source)
            self.assertNotIn(b'Activity(**', task_source)
            self.assertNotIn(b'position=', task_source)
            self.assertIn(b"operation='publish'", task_source)
            self.assertNotIn(b'Project(**', archive.read('application/project.py'))
            self.assertTrue(all(name.endswith('.py') or name == 'manifest.json' for name in names))
            manifest = json.loads(archive.read('manifest.json'))
            self.assertEqual(manifest['runtime'], 'python-async-standalone')
            self.assertEqual(manifest['pythonSource']['entrypoint'], 'application/main.py')
            self.assertEqual(manifest['pythonSource']['mode'], 'engine')
            archive.extractall(folder)
            import subprocess, sys
            result = subprocess.run([sys.executable, '-m', 'application.main', '--environment', 'dev', '--task', 'main', '--input', '{"value":42}'], cwd=folder, capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)['count'], 1)
        normal = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environments=dev&starters=main&archive=ifpkg')
        self.assertEqual(normal.status_code, 200, normal.text)
        with zipfile.ZipFile(io.BytesIO(normal.content)) as archive:
            self.assertIn('application/project.json', archive.namelist())
            self.assertNotIn('application/python/project.py', archive.namelist())
        self.client.delete('/api/projects/task-runtime-test')

    def test_modern_debugger_conditions_watches_edit_and_run_to(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        try:
            started = self.client.post('/api/projects/task-runtime-test/debug', json={
                'task_id':'main', 'input':{'value':42}, 'breakpoints':['p'],
                'breakpoint_conditions':{'p':'${last.answer.value} == 42'},
                'watches':['${last.answer.value}', '${vars.threshold}'], 'pause_on_error':True,
            })
            self.assertEqual(started.status_code, 200, started.text)
            session_id = started.json()['sessionId']
            paused = self.client.post(f'/api/debug/{session_id}/action', json={'action':'continue'})
            self.assertEqual(paused.status_code, 200, paused.text)
            self.assertEqual(paused.json()['status'], 'paused')
            self.assertEqual(paused.json()['currentActivityId'], 'p')
            self.assertEqual(paused.json()['pauseReason'], 'conditional-breakpoint:p')
            self.assertEqual(paused.json()['watchValues'][0]['value'], 42)

            changed = self.client.post(f'/api/debug/{session_id}/action', json={'action':'set_value', 'path':'vars.threshold', 'value':100})
            self.assertEqual(changed.status_code, 200, changed.text)
            self.assertEqual(changed.json()['variables']['vars']['threshold'], 100)
            evaluated = self.client.post(f'/api/debug/{session_id}/action', json={'action':'evaluate', 'expression':'${vars.threshold}'})
            self.assertEqual(evaluated.json()['lastEvaluation']['value'], 100)
            configured = self.client.post(f'/api/debug/{session_id}/action', json={'action':'configure', 'breakpoints':[], 'watches':['${vars.threshold}'], 'pause_on_error':False})
            self.assertFalse(configured.json()['pauseOnError'])
            self.assertEqual(configured.json()['breakpoints'], [])

            run_to = self.client.post(f'/api/debug/{session_id}/action', json={'action':'run_to', 'activity_id':'r'})
            self.assertEqual(run_to.json()['status'], 'paused')
            self.assertEqual(run_to.json()['currentActivityId'], 'r')
            self.assertEqual(run_to.json()['pauseReason'], 'run-to:r')
            stopped = self.client.post(f'/api/debug/{session_id}/action', json={'action':'stop'})
            self.assertEqual(stopped.json()['status'], 'stopped')
        finally:
            self.client.delete('/api/projects/task-runtime-test')

    def test_strict_direct_python_archive_uses_compiled_task_code(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        try:
            response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environments=dev&starters=main&archive=python-direct')
            self.assertEqual(response.status_code, 200, response.text)
            with tempfile.TemporaryDirectory() as folder, zipfile.ZipFile(io.BytesIO(response.content)) as archive:
                names = archive.namelist()
                self.assertIn('application/main.py', names)
                self.assertIn('run.py', names)
                self.assertIn('__main__.py', names)
                self.assertNotIn('application/engine/runtime.py', names)
                self.assertTrue(all(name.endswith('.py') or name == 'manifest.json' for name in names))
                source = archive.read('application/tasks/task_0_main.py')
                self.assertIn(b"if current == 'p':", source)
                self.assertNotIn(b'TRANSITIONS =', source)
                self.assertNotIn(b'Activity(**', source)
                python_source = json.loads(archive.read('manifest.json'))['pythonSource']
                self.assertEqual(python_source['mode'], 'direct')
                self.assertEqual(python_source['scriptEntrypoint'], 'run.py')
                self.assertEqual(python_source['preflightCommand'], 'python run.py --check')
                self.assertIn('application/diagnostics.py', names)
                archive.extractall(folder)
                import subprocess, sys
                result = subprocess.run([sys.executable, '-m', 'application.main', '--environment', 'dev', '--task', 'main', '--input', '{"value":42}'], cwd=folder, capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['count'], 1)
                preflight = subprocess.run([sys.executable, '-m', 'application.main', '--check'], cwd=folder, capture_output=True, text=True, timeout=20)
                self.assertEqual(preflight.returncode, 0, preflight.stderr)
                self.assertTrue(json.loads(preflight.stdout)['ready'])
                direct_path = Path(folder) / 'direct.pyifpkg'
                direct_path.write_bytes(response.content)
                result = subprocess.run([sys.executable, str(direct_path), '--task', 'main', '--input', '{"value":42}'], capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['count'], 1)
        finally:
            self.client.delete('/api/projects/task-runtime-test')

    def test_strict_direct_python_rejects_malformed_transaction_group(self):
        payload = self.project()
        payload['tasks'][0]['groups'] = [{'id': 'g1', 'type': 'transaction_jdbc', 'name': 'Transaction', 'member_activity_ids': ['c', 'p']}]
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        try:
            response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environments=dev&starters=main&archive=python-direct')
            self.assertEqual(response.status_code, 400)
            self.assertIn('JDBC transaction group needs JDBC activities', response.json()['detail'])
        finally:
            self.client.delete('/api/projects/task-runtime-test')

    def test_raw_python_packages_groups_with_the_full_python_engine(self):
        payload = self.project()
        payload['tasks'][0]['groups'] = [{'id': 'g1', 'type': 'transaction_jdbc', 'name': 'Transaction', 'member_activity_ids': ['c', 'p']}]
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environment=dev&archive=python')
        self.assertEqual(response.status_code, 200, response.text)
        with zipfile.ZipFile(io.BytesIO(response.content)) as bundle:
            self.assertIn(b"GroupDefinition(\n            id='g1'", bundle.read('application/tasks/task_0_main.py'))
            self.assertIn('application/engine/runtime.py', bundle.namelist())
        normal = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environment=dev&archive=ifpkg')
        self.assertEqual(normal.status_code, 200)
        self.client.delete('/api/projects/task-runtime-test')

    def test_raw_python_secrets_are_sanitized_and_use_resource_ids(self):
        payload = self.project()
        payload['resources'][0]['config']['password'] = 'private-value'
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        response = self.client.get('/api/projects/task-runtime-test/package?target=on-prem&environment=dev&archive=python')
        self.assertEqual(response.status_code, 200, response.text)
        self.assertNotIn(b'private-value', response.content)
        with zipfile.ZipFile(io.BytesIO(response.content)) as bundle:
            manifest = json.loads(bundle.read('manifest.json'))
            self.assertIn('resources.k1.config.password', manifest['secretKeys'])
            self.assertFalse(any(key.startswith('resources[') for key in manifest['secretKeys']))
        self.client.delete('/api/projects/task-runtime-test')

    def test_raw_python_direct_deploy_uploads_independent_archive(self):
        self.assertEqual(self.client.post('/api/projects', json=self.project()).status_code, 200)
        uploaded = []
        class ControlPlaneClient:
            def __init__(self, *args, **kwargs): pass
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            async def post(self, url, **kwargs):
                request = httpx.Request('POST', url)
                if url.endswith('/api/packages'):
                    with zipfile.ZipFile(io.BytesIO(kwargs['files']['file'][1])) as archive:
                        uploaded.extend(archive.namelist())
                        self_outer.assertEqual(json.loads(archive.read('manifest.json'))['pythonSource']['entrypoint'], 'application/main.py')
                        self_outer.assertEqual(json.loads(archive.read('manifest.json'))['pythonSource']['mode'], 'direct')
                    return httpx.Response(200, request=request, json={'packageId': 'task-runtime-test:1.0.0'})
                return httpx.Response(200, request=request, json={'id': 'raw-deployment', 'state': 'DEPLOYED'})
        self_outer = self
        with patch('app.main.httpx.AsyncClient', ControlPlaneClient):
            response = self.client.post('/api/projects/task-runtime-test/package/deploy', json={
                'target': 'on-prem', 'environments': ['dev'], 'starterTaskIds': ['main'],
                'archive': 'python-direct', 'deploymentEnvironment': 'dev', 'controlPlaneUrl': 'https://control.example',
                'dataPlaneId': 'localhost', 'start': False,
            })
        self.assertEqual(response.status_code, 200, response.text)
        self.assertIn('application/main.py', uploaded)
        self.assertNotIn('application/project.json', uploaded)
        self.assertNotIn('application/engine/runtime.py', uploaded)
        self.client.delete('/api/projects/task-runtime-test')

    def test_direct_control_plane_deployment_uploads_generated_archive_then_creates_deployment(self):
        payload = self.project()
        self.assertEqual(self.client.post('/api/projects', json=payload).status_code, 200)
        calls = []
        class ControlPlaneClient:
            def __init__(self, *args, **kwargs): pass
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            async def post(self, url, **kwargs):
                calls.append((url, kwargs))
                request = httpx.Request('POST', url)
                if url.endswith('/api/packages'):
                    archive = kwargs['files']['file'][1]
                    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
                        self_outer.assertIn('deployment/cloud/Dockerfile', bundle.namelist())
                        self_outer.assertEqual(json.loads(bundle.read('manifest.json'))['starterTaskIds'], ['main'])
                    return httpx.Response(200, request=request, json={'packageId':'integration-application:1.0.0'})
                return httpx.Response(200, request=request, json={'id':'deployment-1','state':'DEPLOYED'})
        self_outer = self
        with patch('app.main.httpx.AsyncClient', ControlPlaneClient):
            response = self.client.post('/api/projects/task-runtime-test/package/deploy', json={
                'target':'cloud', 'environments':['dev'], 'starterTaskIds':['main'], 'archive':'ifpkg',
                'controlPlaneUrl':'https://control.example', 'credential':'token',
                'deploymentEnvironment':'dev', 'dataPlaneId':'kubernetes-dev', 'namespace':'team-a',
            })
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()['deployment']['id'], 'deployment-1')
        self.assertTrue(response.json()['submittedToDataPlane'])
        self.assertEqual([url.rsplit('/', 1)[-1] for url, _ in calls], ['packages', 'deployments'])
        self.assertEqual(calls[0][1]['headers']['x-control-plane-key'], 'token')
        self.client.delete('/api/projects/task-runtime-test')

    def test_project_save_removes_retry_from_non_outbound_activities_only(self):
        payload = self.project()
        retry = {'retryEnabled':True, 'retryCount':3, 'retryIntervalSeconds':5, 'logPayload':False}
        activities = payload['tasks'][0]['activities']
        next(item for item in activities if item['id'] == 'p')['config']['advanced'] = dict(retry)
        next(item for item in activities if item['id'] == 'r')['config']['advanced'] = dict(retry)
        saved = self.client.post('/api/projects', json=payload)
        self.assertEqual(saved.status_code, 200, saved.text)
        saved_activities = saved.json()['tasks'][0]['activities']
        publish_advanced = next(item for item in saved_activities if item['id'] == 'p')['config']['advanced']
        receive_advanced = next(item for item in saved_activities if item['id'] == 'r')['config']['advanced']
        self.assertIn('retryEnabled', publish_advanced)
        self.assertNotIn('retryEnabled', receive_advanced)
        self.assertEqual(receive_advanced, {'logPayload':False})
        self.client.delete('/api/projects/task-runtime-test')

    def test_dataweave_transform_executes_selectors_defaults_collections_and_xml(self):
        script = '''%dw 2.0
output application/json
var fallback = "Unknown"
---
{ customer: upper(payload.name default fallback), ids: payload.lines map (line) -> line.id }'''
        response = self.client.post('/api/dataweave/test', json={'script':script, 'input':{'name':'ada','lines':[{'id':1},{'id':2}]}})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()['output'], {'customer':'ADA','ids':[1,2]})
        xml = self.client.post('/api/dataweave/test', json={'script':'%dw 2.0\noutput application/xml\n---\n{ order: { id: payload.id } }', 'input':{'id':7}})
        self.assertEqual(xml.status_code, 200, xml.text)
        self.assertEqual(xml.json()['output'], '<order><id>7</id></order>')
        metadata = self.client.post('/api/dataweave/test', json={
            'script':'%dw 2.0\noutput application/json\n---\n{ requestId: attributes.requestId, region: vars.region }',
            'input':{}, 'attributes':{'requestId':'req-7'}, 'variables':{'region':'west'}
        })
        self.assertEqual(metadata.status_code, 200, metadata.text)
        self.assertEqual(metadata.json()['output'], {'requestId':'req-7','region':'west'})
        csv_output = self.client.post('/api/dataweave/test', json={
            'script':'%dw 2.0\noutput text/csv\n---\npayload',
            'input':[{'id':1,'name':'Ada'},{'id':2,'name':'Lin'}]
        })
        self.assertEqual(csv_output.status_code, 200, csv_output.text)
        self.assertEqual(csv_output.json()['output'], 'id,name\n1,Ada\n2,Lin\n')

    def test_dataweave_custom_functions_coercions_and_extended_collections(self):
        script = '''%dw 2.0
output application/json
fun normalize(value: String) = upper(trim(value))
---
{
  name: normalize(payload.name),
  id: payload.id as String,
  numeric: payload.id is Number,
  values: payload.groups flatMap (group) -> group.values,
  wildcard: payload.labels.*,
  entries: payload.labels pluck (value, key) -> { name: key, value: value }
}'''
        response = self.client.post('/api/dataweave/test', json={'script': script, 'input': {
            'name': ' ada ', 'id': 7, 'groups': [{'values': [1, 2]}, {'values': [3]}], 'labels': {'a': 'A', 'b': 'B'},
        }})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()['output'], {
            'name': 'ADA', 'id': '7', 'numeric': True, 'values': [1, 2, 3], 'wildcard': ['A', 'B'],
            'entries': [{'name': 'a', 'value': 'A'}, {'name': 'b', 'value': 'B'}],
        })

if __name__ == '__main__': unittest.main()
