# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['app.main', 'ibm_db', 'ibm_db_dbi']
hiddenimports += collect_submodules('app')
hiddenimports += collect_submodules('databricks')


a = Analysis(
    ['run_sidecar.py'],
    pathex=['D:/Integration-tool/IntegrationFabric/backend'],
    binaries=[],
    datas=[('D:/Integration-tool/IntegrationFabric/frontend/dist', 'frontend/dist'), ('D:/Integration-tool/IntegrationFabric/backend/app', 'app')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='IntegrationFabricRuntime',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='IntegrationFabricRuntime',
)
