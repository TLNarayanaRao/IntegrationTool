"""Small, dependency-light execution primitives for generated async tasks."""
from __future__ import annotations

import asyncio
import json
import logging
import re
import copy
from contextlib import nullcontext
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from typing import Any
from .native.mapping_literals import parse_literal
from .retry_policy import ActivityCircuits, CircuitPlan, RetryPlan, outbound_activity, retry_boolean
from time import perf_counter


REFERENCE = re.compile(r'^\$\{([^}]+)\}$')
_GROUP_LOCKS: dict[str, asyncio.Lock] = {}
_ACTIVITY_CIRCUITS = ActivityCircuits()


def group_lock(name: str) -> asyncio.Lock:
    return _GROUP_LOCKS.setdefault(name, asyncio.Lock())


@dataclass(frozen=True)
class Reference:
    path: str


@dataclass(frozen=True)
class Template:
    parts: tuple[str | Reference, ...]


@dataclass
class Context:
    input: Any
    properties: dict[str, Any]
    resources: dict[str, Any]
    last: Any = None
    variables: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)
    transactions: dict[str, Any] = field(default_factory=dict)
    transport: dict[str, Any] = field(default_factory=dict)
    attributes: dict[str, Any] = field(default_factory=dict)
    environment_name: str = 'local'
    error: Exception | None = None
    format_cursors: dict[str, Any] = field(default_factory=dict)
    task_id: str = ''

    def __post_init__(self) -> None:
        self.last = self.input

    def record(self, activity_id: str, result: Any) -> None:
        self.last = result
        self.outputs[activity_id] = {'output': result}

    def fork(self) -> 'Context':
        """Give a parallel branch its own flow values and shared output index."""
        child = Context(copy.deepcopy(self.input), self.properties, self.resources)
        child.last = copy.deepcopy(self.last)
        child.variables = copy.deepcopy(self.variables)
        child.outputs = self.outputs
        child.transactions = self.transactions
        child.transport = self.transport
        child.attributes = dict(self.attributes)
        child.environment_name = self.environment_name
        child.task_id = self.task_id
        child.error = self.error
        return child


def lookup(path: str, ctx: Context) -> Any:
    # Environment properties are stored as flat keys so that property names
    # such as ``connections.sap.applicationServer`` remain valid Python
    # deployment configuration.  Studio permits both the explicit
    # ``${properties.<key>}`` form and the concise ``${<key>}`` form.  Check
    # the complete path before treating dots as object-navigation separators.
    if path in ctx.properties:
        return ctx.properties[path]
    head, _, rest = path.partition('.')
    if head == 'properties' and rest in ctx.properties:
        return ctx.properties[rest]
    value = {'input': ctx.input, 'last': ctx.last, 'properties': ctx.properties,
             'vars': ctx.variables, 'activities': ctx.outputs, 'attributes': ctx.attributes}.get(head)
    if head not in {'input', 'last', 'properties', 'vars', 'activities', 'attributes'}:
        if head in ctx.outputs: value = ctx.outputs[head].get('output')
        else: raise KeyError(f'Unknown expression root: {head}')
    for part in rest.split('.') if rest else []:
        try:
            if isinstance(value, dict): value = value[part]
            elif isinstance(value, (list, tuple)): value = value[int(part)]
            else: value = getattr(value, part)
        except (KeyError, IndexError, AttributeError, ValueError) as error:
            if head == 'properties':
                raise KeyError(f'Missing property {rest!r} in environment {ctx.environment_name!r}') from error
            raise
    return value


def resolve(value: Any, ctx: Context) -> Any:
    if isinstance(value, Reference): return lookup(value.path, ctx)
    if isinstance(value, Template): return ''.join(str(resolve(part, ctx)) for part in value.parts)
    if isinstance(value, str):
        if value.startswith('__mina_constant__:'):
            return json.loads(value.split(':', 1)[1])
        match = REFERENCE.fullmatch(value)
        if match: return lookup(match.group(1), ctx)
        return re.sub(r'\$\{([^}]+)\}', lambda item: str(lookup(item.group(1), ctx)), value)
    if isinstance(value, dict): return {key: copy.deepcopy(child) if key in ('openApiDocument','openApiReferenceDocuments') and not isinstance(child,Reference) and not (isinstance(child,str) and REFERENCE.fullmatch(child)) else resolve(child, ctx) for key, child in value.items()}
    if isinstance(value, list): return [resolve(child, ctx) for child in value]
    return value


def mapping_expression(value: Any) -> Any:
    """Keep field references symbolic until the mapper enters its loop scope."""
    if isinstance(value, Reference): return '${' + value.path + '}'
    if isinstance(value, Template): return ''.join(str(mapping_expression(part)) for part in value.parts)
    if isinstance(value, dict): return {key: mapping_expression(child) for key, child in value.items()}
    if isinstance(value, list): return [mapping_expression(child) for child in value]
    return value


def mapping_document(ctx: Context) -> dict:
    return {**(ctx.last if isinstance(ctx.last, dict) else {}), 'input': ctx.input,
            'last': ctx.last, 'properties': ctx.properties, 'vars': ctx.variables, 'activities': ctx.outputs, 'attributes': ctx.attributes}


def boundary_value(values, wrapper, fallback):
    if not values:
        return fallback
    return values[wrapper] if set(values) == {wrapper} else values


def assign_path(target: dict, path: str, value: Any) -> None:
    parts = path.split('.')
    cursor = target
    for part in parts[:-1]:
        cursor = cursor.setdefault(part, {})
    cursor[parts[-1]] = value


def resolve_sap_connection(raw: dict, ctx: Context) -> dict:
    """Resolve only active SNC fields; never suppress missing active mappings."""
    connection_type = str(resolve(raw.get('connectionType', 'dedicated'), ctx) or 'dedicated').strip().lower()
    snc_mode = resolve(raw.get('sncMode', ''), ctx)
    snc_enabled = connection_type in {'snc', 'sncwithlogongroup'} or str(snc_mode).strip().lower() not in {'', '0', 'false', 'none', 'off'}
    snc_fields = {'sncPartnerName', 'sncLibraryPath', 'sncMyName', 'sncQop',
                  'snc_partnername', 'snc_lib', 'snc_myname', 'snc_qop'}
    active = {key: value for key, value in raw.items() if snc_enabled or key not in snc_fields}
    active['connectionType'] = connection_type
    if 'sncMode' in active: active['sncMode'] = snc_mode if snc_enabled else ''
    return resolve(active, ctx)


def _cron_matches(field: str, value: int, minimum: int, maximum: int) -> bool:
    for item in field.split(','):
        base, _, step_text = item.strip().partition('/')
        step = int(step_text or 1)
        if step < 1: raise ValueError('Cron step must be positive')
        if base == '*': start, end = minimum, maximum
        elif '-' in base: start, end = (int(piece) for piece in base.split('-', 1))
        else: start = end = int(base)
        if start < minimum or end > maximum or start > end: raise ValueError(f'Invalid cron field {item!r}')
        if start <= value <= end and (value - start) % step == 0: return True
    return False


def _next_cron(expression: str, now: datetime) -> datetime:
    fields = expression.split()
    if len(fields) != 5: raise ValueError('Cron schedule needs five fields')
    candidate = now.replace(second=0, microsecond=0) + timedelta(minutes=1)
    for _ in range(527040):
        weekday = (candidate.weekday() + 1) % 7
        if all(_cron_matches(field, value, minimum, maximum) for field, value, minimum, maximum in zip(
            fields, (candidate.minute, candidate.hour, candidate.day, candidate.month, weekday),
            (0, 0, 1, 1, 0), (59, 23, 31, 12, 6))):
            return candidate
        candidate += timedelta(minutes=1)
    raise ValueError('Cron schedule has no occurrence within one year')


def mapped(config: dict, ctx: Context) -> dict:
    entries = config.get('inputMappings') or {}
    occurrences = entries.get('$occurrences')
    has_active_copy = isinstance(occurrences, list) and any(
        isinstance(rule, dict) and rule.get('duplicateOf') and rule.get('enabled', True)
        and (rule.get('select') or rule.get('source')) for rule in occurrences)
    if has_active_copy or any(isinstance(value, dict) and '$rule' in value or
           isinstance(value, (str, Template)) and re.match(r'[\w:-]+\(', str(mapping_expression(value)).strip())
           for value in entries.values()):
        from .native.mapper import INPUT_OCCURRENCES, activity_occurrence_rules, execute as execute_mapping
        rules = []
        for path, value in entries.items():
            if path == INPUT_OCCURRENCES: continue
            if isinstance(value, dict) and '$rule' in value:
                rule = mapping_expression(value)
                rule = {**rule, 'operator': rule['$rule']}
            elif isinstance(value, (Reference, Template)) or isinstance(value, str) and (
                    value.startswith('${') or re.match(r'[\w:-]+\(', value.strip()) or
                    len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'")):
                rule = {'source': mapping_expression(value)}
                if has_active_copy and isinstance(value, Template): rule['inputTemplate'] = True
            else:
                literal, parsed = parse_literal(value)
                rule = {'constant': literal if parsed else resolve(value, ctx)}
            rules.append({**rule, 'target': path})
        if has_active_copy: rules.extend(mapping_expression(rule) for rule in activity_occurrence_rules(entries))
        return execute_mapping(mapping_document(ctx), rules, {'validateOutput': False, 'nullPolicy': 'keep', 'inputMappingSemantics': True, 'customFunctions': config.get('customFunctions') or ctx.attributes.get('customFunctions', [])})
    result = {}
    for path, expression in entries.items():
        if path == '$occurrences': continue
        literal, parsed = parse_literal(expression)
        value = literal if parsed else resolve(expression, ctx)
        assign_path(result, path, value)
    return result


def condition(expression: Any, ctx: Context, bw_xpath=None) -> bool:
    if bw_xpath is not None:
        from .native.mapper_xml import bw_transition_condition
        return bw_transition_condition(expression, bw_xpath, lambda path: lookup(path, ctx), ctx.properties)
    from .native.mapper import execute as execute_mapping
    # Use the same scope-aware expression engine as field mappings. Values are
    # resolved before comparison, never interpolated into executable Python.
    result = execute_mapping(mapping_document(ctx), [dict(target='passed', operator='if', condition=expression, constant=True)], {'validateOutput': False, 'customFunctions': ctx.attributes.get('customFunctions', [])})
    return bool(result.get('passed'))


def choose_transition(edges: list[dict], source: str, ctx: Context, error: Exception | None = None) -> str | None:
    outgoing = [edge for edge in edges if edge['source'] == source]
    if error is not None:
        return next((edge['target'] for edge in outgoing if edge.get('type') == 'error'), None)
    conditional = [edge for edge in outgoing if edge.get('type') == 'success_condition']
    for edge in conditional:
        if condition(edge.get('condition'), ctx):
            return edge['target']
    if conditional:
        return next((edge['target'] for edge in outgoing if edge.get('type') == 'success_no_match'), None)
    return next((edge['target'] for edge in outgoing if edge.get('type', 'success') == 'success'), None)


async def execute_with_policy(kind: str, raw: dict, ctx: Context, activity_id: str, name: str) -> Any:
    advanced = {key.removeprefix('advanced.'): value for key, value in ctx.properties.items() if key.startswith('advanced.retry')}
    advanced.update(resolve(raw.get('advanced') or {}, ctx))
    policy = resolve(raw.get('errorPolicy') or {}, ctx)
    operation = raw.get('operation', '')
    retry = RetryPlan(outbound_activity(kind, operation), advanced, policy)
    circuit = CircuitPlan(kind, operation, advanced)
    if circuit.enabled:
        key = (ctx.environment_name, ctx.task_id, activity_id, kind, operation)

        def circuit_event(state):
            logging.log(logging.INFO if state == 'closed' else logging.WARNING, '%s circuit %s', name, state)
    started = perf_counter()
    for attempt in range(retry.count + 1):
        ticket = None
        try:
            with _ACTIVITY_CIRCUITS.attempt(key, circuit, circuit_event) if circuit.enabled else nullcontext() as ticket:
                result = await execute(kind, raw, ctx, activity_id, name)
            if raw.get('outputName'): ctx.variables[str(raw['outputName'])] = result
            return result
        except Exception as error:
            delay = None if ticket and ticket.stops_retry else retry.delay(attempt, error, perf_counter() - started)
            if delay is not None:
                logging.warning('%s failed; retry %s of %s in %s seconds', name, attempt + 1, retry.count, delay)
                if delay: await asyncio.sleep(delay)
                continue
            fault = {'type': getattr(error, 'fault_type', type(error).__name__), 'description': str(error), 'activityId': activity_id}
            if retry_boolean(policy.get('includeInput', True)): fault['input'] = ctx.last
            if policy.get('outputVariable'): ctx.variables[policy['outputVariable']] = fault
            if policy.get('action') == 'ignore': return ctx.last
            if policy.get('action') == 'continue': return fault
            raise


async def execute(kind: str, raw: dict, ctx: Context, activity_id: str, name: str) -> Any:
    """Execute supported Python-native operations; never load Mina JSON or DSL."""
    # SAP tRFC confirmation is identified by the live listener delivery,
    # rather than a generic broker acknowledgement token.  A Confirm activity
    # placed after an IDoc Parser can therefore retain an editor-created
    # ``ackId`` mapping without attempting to resolve a field that SAP never
    # exposes.  This mirrors the regular runtime's early-confirm behaviour.
    sap_early_confirm = (
        kind == 'confirm'
        and ctx.transport.get('technology') == 'sap'
        and ctx.transport.get('deliveryId')
        and ctx.transport.get('listenerKey')
    )
    ignored_confirm_handles = {'ackId', 'ackIds', 'acknowledgementHandle'} if sap_early_confirm else set()
    literal_keys = {'script', 'libraries', 'outputs', 'sourceSchema', 'targetSchema', 'targetSchemaText', 'sourceSchemaText', 'schemaText', '_dataFormatText', 'interfaceSchemaText', 'lookupTables', 'testCases', 'templateHistory', 'contractBaseline', 'xmlSource', 'xmlStylesheet', 'xmlNamespaces', 'xmlVariables', 'sourceTypeOverrides', 'sourceCoercions', 'xmlSchemaDocuments'}
    static_config = {
        key: value for key, value in raw.items()
        if key not in literal_keys and key not in {'inputMappings', 'mappings', 'customFunctions'} and key not in ignored_confirm_handles
    }
    cfg = resolve(static_config, ctx)
    cfg.update({key: value for key, value in raw.items() if key in literal_keys})
    if raw.get('customFunctions'):
        cfg['customFunctions'] = raw['customFunctions']
        ctx.attributes['customFunctions'] = raw['customFunctions']
    input_mappings = {
        key: value for key, value in (raw.get('inputMappings') or {}).items()
        if key not in ignored_confirm_handles
    }
    resolved_input = mapped({'inputMappings': input_mappings, 'customFunctions': raw.get('customFunctions')}, ctx)
    if kind == 'json': cfg['_mappedInput'] = resolved_input
    for key, value in resolved_input.items():
        cfg[key] = value
    operation = str(cfg.get('operation') or '')
    if kind == 'start': return boundary_value(resolved_input, 'payload', ctx.input)
    if kind == 'end': return boundary_value(resolved_input, 'result', ctx.last)
    if kind == 'catch':
        if not ctx.error: return ctx.last
        return {'type': getattr(ctx.error, 'fault_type', type(ctx.error).__name__),
                'code': str(getattr(ctx.error, 'code', '') or ''), 'message': str(ctx.error),
                'details': getattr(ctx.error, 'details', {}) or {}, 'stackTrace': ''}
    # CAPABILITY timer START
    if kind == 'timer':
        now = datetime.now(timezone.utc)
        run_once = bool(cfg.get('runOnceOnLocalStart', True)) and ctx.environment_name == 'local'
        mode = str(cfg.get('scheduleMode') or 'dateTime')
        if run_once:
            scheduled, trigger_mode = now, 'local-run-once'
        elif mode == 'cron':
            scheduled, trigger_mode = _next_cron(str(cfg.get('cronExpression') or ''), now), 'cron'
        else:
            raw_time = str(cfg.get('scheduledDateTime') or '')
            if not raw_time: raise ValueError('Scheduler needs a date/time or a local Run once setting')
            scheduled = datetime.fromisoformat(raw_time.replace('Z', '+00:00'))
            if scheduled.tzinfo is None: scheduled = scheduled.astimezone()
            scheduled, trigger_mode = scheduled.astimezone(timezone.utc), 'dateTime'
        delay = max(0.0, (scheduled - now).total_seconds())
        if delay: await asyncio.sleep(delay)
        return {'scheduledTime': scheduled.isoformat(), 'actualTime': datetime.now(timezone.utc).isoformat(),
                'sequence': 1, 'triggerMode': trigger_mode, 'payload': ctx.last}
    # CAPABILITY timer END
    # CAPABILITY confirm START
    if kind == 'confirm':
        from . import connectors
        delivery = ctx.transport
        delivery_id, listener_key = delivery.get('deliveryId'), delivery.get('listenerKey')
        if not delivery_id or not listener_key:
            if cfg.get('failIfMissing', True): raise RuntimeError('Confirm Message requires an active acknowledgement handle')
            return {'confirmed': False, 'count': 0}
        if str(cfg.get('ackId') or cfg.get('acknowledgementHandle') or delivery_id) != str(delivery_id):
            raise RuntimeError('Confirm Message acknowledgement handle does not match the active delivery')
        if delivery.get('completed'): raise RuntimeError('Delivery was already confirmed')
        if delivery.get('technology') == 'sap':
            await connectors.settle_sap_delivery(delivery, True)
        else:
            connectors.acknowledge_jms(listener_key, delivery_id, True)
        delivery['completed'] = True
        return {'confirmed': True, 'count': 1, 'ackIds': [str(delivery_id)]}
    # CAPABILITY confirm END
    # CAPABILITY faults START
    if kind in {'throw', 'rethrow'}:
        if kind == 'rethrow' and ctx.error: raise ctx.error
        raise RuntimeError(str(cfg.get('message') or 'Business fault'))
    # CAPABILITY faults END
    # CAPABILITY log START
    if kind == 'log':
        level = str(cfg.get('level') or 'INFO').upper()
        message = cfg.get('message') or f'{name} payload'
        payload = cfg.get('payload', ctx.last)
        logging.log(getattr(logging, level, logging.INFO), '%s%s', message,
                    f' | payload={json.dumps(payload, default=str)}' if cfg.get('includePayload') else '')
        return ctx.last
    # CAPABILITY log END
    # CAPABILITY basic START
    if kind == 'basic':
        if operation in {'deduplicate', 'message_receipt', 'replay_messages', 'aggregate_messages', 'split_records'}:
            from .native.message_state import operate
            return await asyncio.to_thread(operate, operation, cfg, cfg.get('payload', ctx.last))
        if operation == 'empty': return ctx.last
        if operation == 'assign':
            key = str(cfg.get('variable') or '')
            if not key: raise ValueError('Assign Variable needs a name')
            ctx.variables[key] = cfg.get('value', ctx.last)
            return {'name': key, 'value': ctx.variables[key]}
        if operation == 'sleep':
            duration = float(cfg.get('duration') or 0)
            unit = str(cfg.get('unit') or 'milliseconds')
            seconds = duration * (60 if unit == 'minutes' else 1 if unit == 'seconds' else .001)
            await asyncio.sleep(max(0, seconds))
            return {'sleptMilliseconds': round(seconds * 1000), 'payload': ctx.last}
        if operation == 'checkpoint':
            from uuid import uuid4
            return {'checkpointId': str(uuid4()), 'name': str(cfg.get('checkpointName') or name),
                    'timestamp': datetime.now(timezone.utc).isoformat(), 'activityId': activity_id}
        if operation in {'get_shared_variable', 'set_shared_variable'}:
            from . import activities
            return activities.shared_variable(operation, cfg, ctx.last)
        if operation == 'external_command':
            from . import activities
            return await activities.external_command(cfg)
    # CAPABILITY basic END
    # CAPABILITY mapper START
    if kind == 'mapper':
        if retry_boolean(cfg.get('streamEnabled', False)):
            from .native.transform_engine import execute_activity_async
            from .config import SCHEMAS
            plan = await execute_activity_async({**cfg, 'mappings': mapping_expression(raw.get('mappings') or [])}, ctx.last, ctx.attributes, ctx.variables, [vars(a) | {'id': key} for key, a in SCHEMAS.items()], kind='mapper', mapping_context=mapping_document(ctx))
            return plan['output']
        from .native.mapper import execute_async as execute_mapping_async
        mappings = raw.get('mappings') or []
        rules = [{'target': key, 'source': value} for key, value in mappings.items()] if isinstance(mappings, dict) else mappings
        normalized = []
        for rule in rules:
            if not isinstance(rule, dict): continue
            item = dict(rule)
            for field_name in ('source', 'select', 'condition', 'whens', 'otherwise'):
                if field_name in item: item[field_name] = mapping_expression(item[field_name])
            normalized.append(item)
        document = mapping_document(ctx)
        return await execute_mapping_async(document, normalized, cfg)
    # CAPABILITY mapper END
    # CAPABILITY call_task START
    if kind == 'call_task':
        from unicodedata import normalize
        from .registry import TASKS, TASK_DETAILS
        reference = str(cfg.get('dynamicTaskId') or cfg.get('taskId') or '').strip()
        caller_origin = TASK_DETAILS[ctx.task_id][3] if ctx.task_id in TASK_DETAILS else None
        def visible(entry):
            _, _, kind, origin = entry
            return kind == 'subtask' and (not origin or origin.get('public') or
                (caller_origin and caller_origin['alias'] == origin['alias']))
        if reference in TASK_DETAILS and visible(TASK_DETAILS[reference]):
            target = reference
        else:
            def key(value):
                return '/'.join(normalize('NFKC', '-'.join(part.split())).lower() for part in value.split('/'))
            matches = [identity for identity, entry in TASK_DETAILS.items()
                       if visible(entry) and key(f'{entry[1]}/{entry[0]}' if '/' in reference else entry[0]) == key(reference)]
            if len(matches) != 1:
                raise RuntimeError(f'Sub Task {reference!r} was not found')
            target = matches[0]
        values = mapped(raw, ctx)
        fallback = ctx.last if isinstance(ctx.last, dict) else {'value': ctx.last}
        child = Context(boundary_value(values, 'payload', fallback), ctx.properties, ctx.resources)
        return await TASKS[target](child)
    # CAPABILITY call_task END
    # CAPABILITY file START
    if kind == 'file':
        from . import activities
        from .native.file_operations import run_io
        return await run_io(activities.file_activity, operation, cfg, ctx.last)
    # CAPABILITY file END
    # CAPABILITY data_formats START
    if kind in {'xml', 'json', 'flat'}:
        from . import activities
        from .config import SCHEMAS
        cfg['_formatSchemaAssets'] = [(asset.source_path or asset.name, asset.content) for asset in SCHEMAS.values()
                                      if (asset.source_path or asset.name).lower().endswith('.xsd')]
        return await activities.data_activity_async(kind, operation, cfg, ctx.last, ctx.format_cursors, activity_id)
    # CAPABILITY data_formats END
    # CAPABILITY excel START
    if kind == 'excel':
        from . import activities
        return await asyncio.to_thread(activities.excel_read, cfg)
    # CAPABILITY excel END
    # CAPABILITY transfer START
    if kind in {'ftp', 'sftp'}:
        from . import activities
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != kind: raise ValueError(f'{name} requires a shared {kind.upper()} connection')
        from .native.file_operations import run_io
        return await run_io(activities.transfer, kind, operation, resolve(resource.config, ctx), cfg)
    # CAPABILITY transfer END
    # CAPABILITY inbound_http START
    if kind == 'http_listener' or kind == 'rest' and operation == 'receiver' or kind == 'soap' and operation == 'service':
        return ctx.input
    # CAPABILITY inbound_http END
    # CAPABILITY http_client START
    if kind in {'http', 'rest', 'soap'}:
        from . import activities
        resource = ctx.resources.get(str(cfg.get('resourceId') or ''))
        connection = resolve(resource.config, ctx) if resource else {}
        request_cfg = dict(cfg)
        if kind == 'soap':
            request_cfg['method'] = 'POST'; request_cfg['body'] = cfg.get('envelope', ctx.last); request_cfg['bodyType'] = 'text'
            request_cfg['headers'] = {'Content-Type': cfg.get('contentType') or 'text/xml; charset=utf-8', **(cfg.get('headers') or {})}
            if cfg.get('soapAction'): request_cfg['headers']['SOAPAction'] = cfg['soapAction']
        response = await asyncio.to_thread(activities.http_request, request_cfg, connection)
        if cfg.get('operation') in ('sse_read', 'websocket_exchange', 'write_precondition'):
            return response
        return response['body'] if kind == 'http' and cfg.get('responseMode', 'payload') == 'payload' and not (cfg.get('RestInputRequest') is not None or cfg.get('requestModel') == 'tree') else response
    # CAPABILITY http_client END
    # CAPABILITY http_response START
    if kind == 'http_response':
        from .native.http_messages import response_message
        return {'sent': True, **response_message(cfg,ctx.last)}
    # CAPABILITY http_response END
    # CAPABILITY script_transform START
    if kind == 'script_transform':
        from .native.transform_engine import execute_activity_async
        from .config import SCHEMAS
        plan = await execute_activity_async(cfg, ctx.last, ctx.attributes, ctx.variables, [vars(a) | {'id': key} for key, a in SCHEMAS.items()])
        if plan['attributesChanged']: ctx.attributes = plan['attributes']
        ctx.variables.update(plan['variables'])
        return plan['output']
    # CAPABILITY script_transform END
    # CAPABILITY python START
    if kind == 'python':
        from . import activities
        return await activities.python_invoke(cfg, ctx.last)
    # CAPABILITY python END
    # CAPABILITY java START
    if kind == 'java':
        from . import activities
        return await activities.java_invoke(cfg, ctx.last)
    # CAPABILITY java END
    # CAPABILITY kafka START
    if kind == 'kafka':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource: raise ValueError(f'{name} requires a shared {kind} connection')
        connection = resolve(resource.config, ctx)
        return await connectors.kafka(operation, connection, cfg, ctx.last)
    # CAPABILITY kafka END
    # CAPABILITY pubsub START
    if kind == 'pubsub':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource: raise ValueError(f'{name} requires a shared Pub/Sub connection')
        return await connectors.pubsub(operation, resolve(resource.config, ctx), cfg, ctx.last)
    # CAPABILITY pubsub END
    # CAPABILITY sap START
    if kind == 'sap':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != 'sap':
            raise ValueError(f'{name} requires a shared SAP connection')
        connection = resolve_sap_connection(resource.config, ctx)
        source = str(cfg.get('messagingSource') or 'NoMessaging').strip().lower().replace(' ', '')
        if operation == 'idoc_listener' and source not in {'', 'nomessaging', 'direct', 'sapjcorfc/idoc_inbound_asynchronous'}:
            technology = {'ems': 'ems', 'jms': 'jms', 'kafka': 'kafka'}.get(source)
            if not technology: raise ValueError(f'Unsupported SAP IDoc messaging source: {cfg.get("messagingSource")}')
            broker_resource = ctx.resources.get(str(cfg.get('messagingResourceId') or ''))
            if not broker_resource or broker_resource.type != technology:
                raise ValueError(f'{name} requires a shared {technology.upper()} messaging connection')
            broker_connection = resolve(broker_resource.config, ctx)
            destination = cfg.get('messagingDestination') or cfg.get('destination') or cfg.get('topic')
            broker_cfg = {**cfg, 'destination': destination, 'topic': destination, 'maxMessages': 1}
            if technology == 'kafka': received = await connectors.kafka('receive', broker_connection, broker_cfg, ctx.last)
            else: received = await connectors.jms(technology, 'queue_receiver' if technology == 'ems' else 'receive_message', broker_connection, broker_cfg, ctx.last, ctx)
            messages = received.get('messages') if isinstance(received, dict) else []
            first = messages[0] if isinstance(messages, list) and messages else {}
            broker_payload = received.get('body') if technology in {'ems', 'jms'} else (first.get('data') if isinstance(first, dict) else first)
            properties = received.get('properties') or {}
            from .native.sap import SapAdapter
            sap_idoc = properties.get('SAPIDoc', {}) if isinstance(properties, dict) else {}
            return {**received, 'payload': broker_payload, 'SAPIDoc': SapAdapter._normalize_idoc_arrays(sap_idoc, {**connection, **cfg}), 'messagingSource': technology.upper()}
        return await connectors.sap(operation, connection, cfg, cfg.get('payload', ctx.last), ctx)
    # CAPABILITY sap END
    # CAPABILITY jms START
    if kind in {'ems', 'jms'}:
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != kind: raise ValueError(f'{name} requires a shared {kind.upper()} connection')
        connection = resolve(resource.config, ctx)
        cfg['_activityId'] = activity_id
        return await connectors.jms(kind, operation, connection, cfg, cfg.get('data', cfg.get('message', ctx.last)), ctx)
    # CAPABILITY jms END
    # CAPABILITY jdbc START
    if kind == 'jdbc':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != 'jdbc':
            raise ValueError(f'{name} requires a shared JDBC connection')
        return await connectors.jdbc(resolve(resource.config, ctx), cfg, ctx.transactions.get(resource_id))
    # CAPABILITY jdbc END
    # CAPABILITY snowflake START
    if kind == 'snowflake':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != 'snowflake': raise ValueError(f'{name} requires a shared Snowflake connection')
        return await connectors.snowflake(operation, resolve(resource.config, ctx), cfg, ctx.last)
    # CAPABILITY snowflake END
    # CAPABILITY amqp START
    if kind == 'amqp':
        from . import connectors
        resource_id = str(cfg.get('resourceId') or '')
        resource = ctx.resources.get(resource_id)
        if not resource or resource.type != 'amqp': raise ValueError(f'{name} requires a shared AMQP connection')
        return await connectors.amqp(operation, resolve(resource.config, ctx), cfg, ctx.last)
    # CAPABILITY amqp END
    raise NotImplementedError(f'Raw Python operation is not implemented: {kind}/{operation}')
