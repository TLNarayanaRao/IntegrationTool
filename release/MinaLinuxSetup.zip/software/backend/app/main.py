import asyncio, io, json, os, socket, sys, tarfile, traceback, zipfile
from pprint import pformat
import re
import platform
import threading
import httpx
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .models import AIBuildRequest, DebugAction, DebugRequest, Project, RunRequest, SharedResource, effective_event_activities
from .store import delete_project, get_project, list_projects, project_dir, save_project, safe_component
from .project_import import MAX_IMPORT_BYTES, project_payload
from .runtime import WorkflowRuntime
from .http_transport import HTTPFault
from .debugger import DebugManager
from .mapper import execute as execute_mapping, recommend, rewrite_references, validate_output
from .dataweave import DataWeaveError, execute_details as execute_dataweave
from .sap import sap_adapter
from .snowflake import snowflake_adapter
from .jdbc import jdbc_adapter
from .amqp import amqp_adapter
from .java_bridge import JavaBridgeError, terminate_execution_processes, test_jms
from .google_pubsub import client_configuration as pubsub_client_configuration, create_client as create_pubsub_client, credential_summary as pubsub_credential_summary
from .ai_builder import generate as generate_ai_design
from .project_logging import append_project_logs, project_log_info, read_project_logs
from .observability import telemetry_status, span
from .time_utils import log_timestamp

app = FastAPI(title='MINA Runtime', version='0.1.0')

@app.exception_handler(HTTPFault)
async def http_configuration_fault(request: Request,error: HTTPFault):
    return JSONResponse({'detail':str(error),'faultType':error.fault_type},status_code=error.status)
runtime = WorkflowRuntime()
debugger = DebugManager(runtime)
runtime_states: dict[str, dict] = {}
active_runs: dict[str, asyncio.Task] = {}
debug_runs: dict[str, asyncio.Task] = {}
debug_stop_locks: dict[str, asyncio.Lock] = {}

async def _cancel_and_wait(task: asyncio.Task | None, timeout: float = 3.0) -> None:
    """Cancel an owned runtime task and observe its cleanup before returning."""
    if not task or task.done() or task is asyncio.current_task(): return
    task.cancel()
    try:
        await asyncio.wait_for(asyncio.shield(task), timeout=timeout)
    except (asyncio.CancelledError, asyncio.TimeoutError):
        pass
    except Exception:
        # Runtime errors have already been captured in the execution log. Stop
        # remains a lifecycle operation and must not be blocked by them.
        pass

async def _stop_debug_session(session_id: str) -> dict:
    """Stop every task owned by a debug session, then rollback its resources."""
    lock = debug_stop_locks.setdefault(session_id, asyncio.Lock())
    async with lock:
        state = debugger.sessions.get(session_id)
        if not state: raise ValueError('Debug session not found')
        if state.get('status') == 'stopped': return debugger.view(state)
        project = state['project']
        # Publish the stop intent synchronously. Listener/debug loops inspect
        # this flag, so they cannot re-arm while cancellation is delivered.
        state['stopRequested'] = True
        state['status'] = 'stopping'
        debug_task = debug_runs.pop(session_id, None)
        listener_task = active_runs.pop(project.id, None)
        await asyncio.gather(
            _cancel_and_wait(debug_task),
            _cancel_and_wait(listener_task),
            asyncio.to_thread(terminate_execution_processes, session_id),
        )
        pending = state.pop('pendingSapDelivery', None)
        if pending and not pending.get('transport', {}).get('completed'):
            try: sap_adapter.acknowledge_idoc(pending['listenerKey'], pending['deliveryId'], False)
            except Exception: pass
        view = await debugger.stop(session_id)
        cursor = int(state.get('persistedLogCount', 0))
        append_project_logs(project.id, project.name, state['logs'][cursor:], _project_log_directory(project, state.get('environment', 'local')))
        state['persistedLogCount'] = len(state['logs'])
        return view

@app.middleware('http')
async def prevent_stale_studio_entry(request: Request, call_next):
    """Always revalidate the HTML shell while allowing hashed assets to cache.

    Vite changes the JS/CSS filenames on every production build. Caching
    index.html can therefore leave the browser requesting hashes from an old
    build and produce a blank Studio after a 404. Static hashed assets remain
    cacheable; only the entry document is marked as non-cacheable.
    """
    response = await call_next(request)
    if request.url.path in {'/', '/index.html'}:
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response

@app.on_event('shutdown')
async def shutdown_native_connectors():
    """Stop persistent JCo processes before the runtime exits/reloads."""
    pending = [task for task in [*active_runs.values(), *debug_runs.values()] if task and not task.done()]
    for task in pending: task.cancel()
    if pending: await asyncio.gather(*pending, return_exceptions=True)
    active_runs.clear()
    debug_runs.clear()
    debug_stop_locks.clear()
    sap_adapter.close_all()
    await asyncio.to_thread(runtime.close_publishers)
    from .http_transport import close_clients
    await asyncio.to_thread(close_clients)

INBOUND_OPERATIONS = {None, 'listen', 'receiver', 'service'}
CONTINUOUS_EVENT_OPERATIONS = {
    'timer': {'schedule'},
    'file': {'poll'},
    'ems': {'queue_receiver', 'topic_subscriber'},
    'jms': {'receive_message'},
    'amqp': {'receive'},
    'kafka': {'receive', 'get'},
    'pubsub': {'subscribe'},
    'sap': {'idoc_listener', 'rfc_bapi_listener'},
}

def _environment_values(item: Project, environment: str) -> dict:
    return {prop.key: prop.value for prop in item.properties.get(environment, [])}

def _project_log_directory(item: Project, environment: str) -> str:
    return str(_environment_values(item, environment).get('runtime.logDirectory') or '').strip()

def _resolved_resource_config(item: Project, activity, properties: dict) -> dict:
    resource = next((value for value in item.resources if value.id == activity.config.get('resourceId')), None)
    if not resource: return {}
    context = {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}
    return {key: runtime.resolve(value, context) for key, value in resource.config.items()}

async def _start_http_listener(item,task,event,environment):
    from .http_server import serve
    resources={value.id:value for value in item.resources};properties=_environment_values(item,environment)
    context={'properties':properties,'input':{},'last':{},'vars':{},'context':{}}
    connection={**_resolved_resource_config(item,event,properties),'_httpScope':item.id}
    previous=active_runs.pop(item.id,None)
    if previous:await _cancel_and_wait(previous)
    async def handle(metadata,payload):
        result=await runtime.run(task,payload,resources,properties,event.id,item)
        append_project_logs(item.id,item.name,result.logs,_project_log_directory(item,environment))
        _publish_runtime_state(item.id,status='listening',logs=(runtime_states.get(item.id,{}).get('logs',[])+result.logs)[-500:],result=result,environment=environment)
        if result.status!='completed':raise RuntimeError('HTTP integration failed')
        return result.output
    ready=asyncio.Event();job=asyncio.create_task(serve([(None,connection,runtime.resolve(event.config,context))],handle,ready));active_runs[item.id]=job
    waiter=asyncio.create_task(ready.wait())
    try:
        done,_=await asyncio.wait([job,waiter],timeout=15,return_when=asyncio.FIRST_COMPLETED)
        if job in done:await job
        if not ready.is_set():raise RuntimeError('HTTP listener did not start within 15 seconds')
    except Exception:
        active_runs.pop(item.id,None);await _cancel_and_wait(job);raise
    finally:waiter.cancel()


def _listener_endpoints(item: Project, task, environment: str, base_url: str = '') -> list[dict]:
    properties = {prop.key: prop.value for prop in item.properties.get(environment, [])}
    endpoints = []
    for activity in task.activities:
        if activity.type not in ('http_listener', 'rest', 'soap') or activity.config.get('operation') not in INBOUND_OPERATIONS: continue
        cfg = _resolved_resource_config(item, activity, properties)
        path = str(runtime.resolve(activity.config.get('path', '/'), {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}) or '/')
        if not path.startswith('/'): path = '/' + path
        from .http_server import listener_config
        effective=listener_config(cfg,runtime.resolve(activity.config,{'properties':properties,'input':{},'last':{},'vars':{},'context':{}}))
        deployment_path=effective['path']
        path=deployment_path
        from .http_server import server_tls
        tls = server_tls(cfg)
        scheme = 'https' if tls else str(cfg.get('scheme') or 'http')
        host = str(cfg.get('host') or 'localhost')
        port = int(cfg.get('port') or 8080)
        default_port = (scheme == 'https' and port == 443) or (scheme == 'http' and port == 80)
        configured_url = f'{scheme}://{host}{"" if default_port else f":{port}"}{deployment_path}'
        relative_url = f'/api/listeners/{item.id}{path}'
        methods = str(effective.get('methods') or effective.get('method') or 'POST').replace(' ', '').split(',')
        endpoints.append({'taskId': task.id, 'activityId': activity.id, 'name': activity.name, 'type': activity.type,
                          'methods': methods, 'path': path, 'url': configured_url, 'previewUrl': base_url.rstrip('/') + relative_url if base_url else relative_url,
                          'relativeUrl': relative_url, 'configuredUrl': configured_url, 'tlsEnabled': tls,
                          'authentication': cfg.get('authentication', 'None')})
    return endpoints

def _lifecycle_logs(item: Project, endpoints: list[dict]) -> list[dict]:
    now = log_timestamp()
    logs = [
        {'time': now, 'level': 'INFO', 'kind': 'lifecycle', 'message': f'MINA runtime initializing application {item.name}', 'startedAt': now},
        {'time': now, 'level': 'INFO', 'kind': 'lifecycle', 'message': f'Application module loaded: {item.name} ({len(item.tasks)} task(s), {len(item.resources)} shared resource(s))'},
        {'time': now, 'level': 'INFO', 'kind': 'lifecycle', 'message': f'Application {item.name} started', 'startedAt': now},
    ]
    logs.extend({'time': now, 'level': 'INFO', 'kind': 'endpoint', 'message': (f'{endpoint["name"]} is ready and waiting on {endpoint["url"]}' if endpoint.get('kind') == 'subscription' else f'{", ".join(endpoint["methods"])} listener ready at {endpoint["url"]}')} for endpoint in endpoints)
    return logs

def _startup_diagnostics(item: Project, task, resources: dict, properties: dict, environment: str, mode: str) -> list[dict]:
    """Create production-safe startup diagnostics without logging secrets."""
    now = log_timestamp()
    entries: list[dict] = []
    emit = lambda phase, message, **details: entries.append({'time': now, 'level': 'INFO', 'kind': 'startup', 'phase': phase, 'message': message, **details})
    emit('application', f'Integration solution kickoff: {item.name}', mode=mode, buildVersion=os.getenv('MINA_BUILD_VERSION', 'source'), taskId=task.id, environment=environment)
    loaded_modules = []
    for name, module in sorted(sys.modules.items()):
        if module is None: continue
        loaded_modules.append({'name': name, 'package': getattr(module, '__package__', '') or '', 'file': str(getattr(module, '__file__', '') or '')})
    emit('python', 'Python runtime modules loaded at startup', pythonVersion=platform.python_version(), executable=sys.executable, frozen=bool(getattr(sys, '_MEIPASS', None)), moduleCount=len(loaded_modules), modules=loaded_modules)
    property_source = project_dir(item.id) / 'properties' / f'{safe_component(environment)}.json'
    emit('properties', 'Environment properties loaded', source=str(property_source) if property_source.exists() else 'project model / environment store', propertyCount=len(properties), secretValuesRedacted=True)
    configured_threads = os.getenv('MINA_WORKER_THREADS') or properties.get('advanced.workerThreads') or properties.get('advanced.threadCount') or 'auto'
    emit('threads', 'Runtime thread configuration resolved', configuredWorkers=str(configured_threads), processThreads=threading.active_count(), cpuCount=os.cpu_count() or 1)
    otel = telemetry_status()
    emit('telemetry', 'OpenTelemetry status inspected', **otel, status='registered' if otel.get('registered') else 'not_registered')
    used_ids = {activity.config.get('resourceId') for solution_task in item.tasks for activity in solution_task.activities if activity.config.get('resourceId')}
    connector_inventory = []
    for resource in resources.values():
        if resource.id not in used_ids: continue
        context = {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}
        resolved = {key: runtime.resolve(value, context) for key, value in resource.config.items()}
        endpoint = _connector_endpoint(resource.type, resolved)
        connector_inventory.append({'id': resource.id, 'name': resource.name, 'type': resource.type, 'status': 'pending', 'connectionPolicy': 'lazy / opened when the activity executes', 'endpoint': endpoint})
    emit('connectors', 'Connectors used by the integration solution discovered', count=len(connector_inventory), connectors=connector_inventory, unusedResourceCount=len(resources) - len(connector_inventory))
    errors = []
    for resource in resources.values():
        if resource.type == 'sap' and str(resource.config.get('mode') or 'external').lower() == 'external':
            if not str(resource.config.get('driverDirectory') or '').strip(): errors.append(f'{resource.name}: SAP JCo driver directory uses default search locations')
    if errors:
        entries.append({'time': now, 'level': 'WARN', 'kind': 'configuration', 'phase': 'validation', 'message': 'Application configuration warnings detected', 'issues': errors})
    emit('configuration', 'Application configuration validation completed', status='warnings' if errors else 'valid', taskCount=len(item.tasks), resourceCount=len(resources), activityCount=sum(len(value.activities) for value in item.tasks))
    emit('application', f'Application startup sequence prepared for {mode} mode', status='starting')
    return entries

def _connector_endpoint(connector_type: str, config: dict) -> dict:
    """Return connection targets without credentials or secret query values."""
    kind = str(connector_type or '').lower()
    if kind in ('http', 'rest', 'soap'):
        scheme = config.get('scheme') or ('https' if config.get('tlsEnabled') else 'http')
        host, port = config.get('host') or config.get('hostname') or '', config.get('port')
        base = f'{scheme}://{host}{f":{port}" if port and str(port) not in ("80", "443") else ""}'
        return {'protocol': scheme, 'url': base + str(config.get('basePath') or config.get('path') or '')}
    if kind in ('sap', 'sap_tid'):
        return {'protocol': 'sap-jco', 'applicationServer': config.get('applicationServerHost'), 'systemNumber': config.get('systemNumber'), 'gateway': f'{config.get("gatewayHost") or ""}:{config.get("gatewayService") or ""}', 'programId': config.get('programId')}
    if kind in ('kafka',): return {'protocol': 'kafka', 'bootstrapServers': config.get('bootstrapServers') or config.get('serverUrl'), 'topic': config.get('topic')}
    if kind in ('ems', 'jms', 'amqp'): return {'protocol': kind, 'url': config.get('serverUrl') or config.get('brokerUrl'), 'destination': config.get('destination') or config.get('queue') or config.get('topic')}
    if kind in ('jdbc', 'snowflake'): return {'protocol': 'jdbc', 'url': config.get('url') or config.get('serverUrl') or config.get('account'), 'database': config.get('database'), 'schema': config.get('schema')}
    if kind == 'pubsub': return {'protocol': 'gcp-pubsub', 'project': config.get('projectId'), 'subscription': config.get('subscription'), 'topic': config.get('topic')}
    return {'protocol': kind}

def _publish_runtime_state(project_id: str, *, status: str, logs: list[dict], endpoints=None, result=None, environment: str | None = None):
    from .execution_analytics import activity_timings
    previous = runtime_states.get(project_id, {})
    executions = list(previous.get('executions', []))
    if result is not None:
        execution = {
            'runId': result.run_id, 'correlationId': result.correlation_id, 'status': result.status,
            'startedAt': result.started_at, 'endedAt': result.ended_at, 'durationMs': result.duration_ms,
            'activityOutputs': result.activity_outputs, 'taskOutputs': result.task_outputs,
            'activityTimings': activity_timings(result.logs),
        }
        executions = ([execution] + executions)[:100]
    state = {
        'status': status, 'updatedAt': log_timestamp(),
        'environment': environment or previous.get('environment', 'local'),
        'logs': logs, 'endpoints': endpoints if endpoints is not None else previous.get('endpoints', []),
        'activityOutputs': result.activity_outputs if result is not None else previous.get('activityOutputs', {}),
        'taskOutputs': result.task_outputs if result is not None else previous.get('taskOutputs', {}),
        'lastExecution': executions[0] if executions else None, 'executions': executions,
    }
    runtime_states[project_id] = state
    return state

def _is_continuous_event(activity) -> bool:
    return activity.config.get('operation') in CONTINUOUS_EVENT_OPERATIONS.get(activity.type, set())

def _event_subscription(item: Project, task, activity, environment: str) -> dict:
    properties = _environment_values(item, environment)
    context = {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}
    config = runtime.resolve(activity.config, context)
    resource = next((value for value in item.resources if value.id == config.get('resourceId')), None)
    resource_config = _resolved_resource_config(item, activity, properties)
    # Display and runtime diagnostics must use the effective configuration:
    # SAP gateway/program settings usually live on the shared resource, not
    # on the listener activity itself.
    effective = {**resource_config, **config}
    resource_name = resource.name if resource else str(config.get('resourceId') or 'unconfigured connection')
    if activity.type == 'sap':
        messaging_source = str(effective.get('messagingSource') or 'NoMessaging')
        if messaging_source.lower().replace(' ', '') not in ('', 'nomessaging', 'direct'):
            destination = f"{messaging_source} · {effective.get('messagingDestination') or 'unconfigured destination'}"
            messaging_resource = next((value for value in item.resources if value.id == effective.get('messagingResourceId')), None)
            if messaging_resource: resource_name = f'{resource.name if resource else "SAP"} / {messaging_resource.name}'
        else:
            gateway = f"{effective.get('gatewayHost') or effective.get('gwhost') or 'unknown-host'}:{effective.get('gatewayService') or effective.get('gwserv') or 'unknown-service'}"
            program_id = effective.get('programId') or effective.get('progid') or 'unconfigured-program-id'
            destination = f"{program_id} · gateway {gateway}"
    else:
        destination = effective.get('destination') or effective.get('queue') or effective.get('topic') or effective.get('subscription') or effective.get('programId') or effective.get('path') or ('configured schedule' if activity.type == 'timer' else 'default')
    technology = activity.type.upper()
    return {
        'taskId': task.id, 'activityId': activity.id, 'name': activity.name, 'type': activity.type,
        'kind': 'subscription', 'methods': ['EVENT'], 'status': 'ready', 'destination': str(destination),
        'resourceName': resource_name, 'url': f'{technology} · {resource_name} · {destination}',
    }

def _event_available(output) -> bool:
    if not isinstance(output, dict): return output is not None
    # A timer emits a schedule event rather than a transport envelope. Its
    # payload intentionally has no messageId/body/count, so it must still
    # enter the workflow and trigger the downstream activities.
    if output.get('scheduledTime'): return True
    if 'received' in output: return bool(output.get('received'))
    if 'count' in output: return int(output.get('count') or 0) > 0
    if output.get('messages'): return True
    return bool(output.get('MessageID') or output.get('messageId') or output.get('body') is not None)

def _listener_context(item: Project, task, resources: dict, properties: dict, environment: str, debug_session_id: str | None = None) -> dict:
    return {
        'input': {}, 'vars': {}, 'last': {}, 'resources': resources, 'properties': properties,
        'project': item, 'runtime': runtime, 'logs': [], 'activities': {},
        'tasks': {task.id: {'name': task.name, 'activities': {}}},
        'context': {'taskId': task.id, 'activityId': '', 'environment': environment, 'debugSessionId': debug_session_id, 'executionId': debug_session_id or item.id},
    }

async def _continuous_event_loop(item: Project, task, activity, environment: str, debug_session_id: str | None = None):
    project_id = item.id
    resources = {resource.id: resource for resource in item.resources}
    properties = _environment_values(item, environment)
    retry_delay = 1.0
    seen_files: dict[str, str] | None = None
    current = asyncio.current_task()
    try:
        while True:
            sap_delivery_id = None
            sap_listener_key = None
            if debug_session_id:
                session = debugger.sessions.get(debug_session_id)
                if not session or session.get('status') == 'stopped': return
                if session.get('status') not in ('listening',):
                    await asyncio.sleep(.1)
                    continue
            context = _listener_context(item, task, resources, properties, environment, debug_session_id)
            try:
                output = await runtime.execute_with_policy(activity, context)
                retry_delay = 1.0
                resolved_config = runtime.resolve(activity.config, context)
                if activity.type == 'file' and activity.config.get('operation') == 'poll':
                    current_files = {str(value.get('fullName')): str(value.get('lastModified')) for value in output.get('files', []) if value.get('fullName')}
                    include_existing = runtime.as_bool(resolved_config.get('includeExisting', False))
                    event_type = str(resolved_config.get('eventType') or 'Created').lower()
                    if seen_files is None:
                        changed = list(output.get('files', [])) if include_existing else []
                    else:
                        created = [value for value in output.get('files', []) if str(value.get('fullName')) not in seen_files]
                        modified = [value for value in output.get('files', []) if str(value.get('fullName')) in seen_files and seen_files[str(value.get('fullName'))] != str(value.get('lastModified'))]
                        deleted = [{'fullName': name, 'fileName': Path(name).name, 'eventType':'Deleted'} for name in seen_files if name not in current_files]
                        changed = created if event_type == 'created' else modified if event_type == 'modified' else deleted if event_type == 'deleted' else created + modified + deleted
                    seen_files = current_files
                    output = {**output, 'files': changed, 'count': len(changed), 'eventType': resolved_config.get('eventType', 'Created')}
                jco_diagnostics = output.pop('jcoDiagnostics', []) if isinstance(output, dict) else []
                if jco_diagnostics:
                    diagnostic_logs = []
                    for detail in jco_diagnostics:
                        diagnostic_logs.append({'time': log_timestamp(), 'level': detail.get('level', 'INFO'), 'kind': 'connector', 'phase': detail.get('phase'), 'message': detail.get('message'), 'connector': 'SAP JCo', **{key: detail[key] for key in ('serverName', 'programId', 'gatewayHost', 'gatewayService', 'repositoryDestination', 'tidStore', 'functionName', 'connectionCount') if key in detail}, 'activityId': activity.id, 'taskId': task.id})
                    if debug_session_id:
                        session = debugger.sessions.get(debug_session_id)
                        if session: session['logs'].extend(diagnostic_logs)
                    else:
                        previous = runtime_states.get(project_id, {})
                        logs = (list(previous.get('logs', [])) + diagnostic_logs)[-500:]
                        _publish_runtime_state(project_id, status='listening', logs=logs, environment=environment)
                    append_project_logs(project_id, item.name, diagnostic_logs, _project_log_directory(item, environment))
                if not _event_available(output):
                    await asyncio.sleep(max(.1, float(resolved_config.get('pollInterval', 1) or 1)) if activity.type == 'file' else .1)
                    continue
                if activity.type == 'sap' and isinstance(output, dict):
                    # These are transport-control values, not business payload.
                    # Keep them out of mappings and logs while retaining them
                    # until the workflow has committed or rolled back the SAP
                    # transaction.
                    sap_delivery_id = output.pop('_sapDeliveryId', None)
                    sap_listener_key = output.pop('_sapListenerKey', None)
                if debug_session_id:
                    delivery_transport = {
                        'deliveryId': sap_delivery_id,
                        'listenerKey': sap_listener_key,
                        'functionName': output.get('functionName') if isinstance(output, dict) else None,
                        'operation': activity.config.get('operation'),
                        'invocationProtocol': output.get('invocationProtocol') if isinstance(output, dict) else None,
                    }
                    session = debugger.sessions.get(debug_session_id)
                    if session and session.get('frames'):
                        session['frames'][-1]['context']['transport'] = delivery_transport
                    await debugger.trigger_event(debug_session_id, output)
                    session = debugger.sessions.get(debug_session_id)
                    if sap_delivery_id and sap_listener_key and not delivery_transport.get('completed'):
                        if session and session.get('status') == 'listening':
                            request_reply = activity.config.get('operation') == 'rfc_bapi_listener' and str(delivery_transport.get('invocationProtocol') or 'Request/Reply').lower().replace('-', '').replace('/', '') in ('requestreply', 'srfc')
                            sap_adapter.acknowledge_idoc(sap_listener_key, sap_delivery_id, not request_reply)
                            if request_reply:
                                session['status'] = 'failed'
                                session['logs'].append({'time': log_timestamp(), 'level': 'ERROR', 'kind': 'connector', 'message': 'RFC/BAPI request completed without a Reply from RFC/BAPI activity; SAP request was rolled back.', 'activityId': activity.id, 'taskId': task.id})
                        elif session and session.get('status') in ('failed', 'stopped'):
                            sap_adapter.acknowledge_idoc(sap_listener_key, sap_delivery_id, False)
                        elif session:
                            # A breakpoint pauses before completion. Hold the
                            # SAP transaction until the user resumes or stops.
                            session['pendingSapDelivery'] = {'listenerKey': sap_listener_key, 'deliveryId': sap_delivery_id, 'transport': delivery_transport}
                    if session:
                        cursor = int(session.get('persistedLogCount', 0))
                        append_project_logs(project_id, item.name, session['logs'][cursor:], _project_log_directory(item, environment))
                        session['persistedLogCount'] = len(session['logs'])
                        _publish_runtime_state(project_id, status=session.get('status', 'listening'), logs=session['logs'][-500:], endpoints=session.get('endpoints', []), environment=environment)
                    if activity.type == 'timer':
                        repeat = runtime.as_bool(resolved_config.get('repeatEnabled', False))
                        cron = str(resolved_config.get('scheduleMode') or '').lower() == 'cron'
                        if not repeat and not cron: return
                        if repeat and not cron:
                            multiplier = {'seconds':1, 'minutes':60, 'hours':3600, 'days':86400}.get(str(resolved_config.get('unit') or 'minutes').lower(), 60)
                            await asyncio.sleep(max(1.0, float(resolved_config.get('interval', 1) or 1) * multiplier))
                    elif activity.type == 'file':
                        await asyncio.sleep(max(.1, float(resolved_config.get('pollInterval', 1) or 1)))
                    continue
                try:
                    result = await runtime.run(task, output, resources, properties, activity.id, item, event_output=output)
                    if sap_delivery_id and sap_listener_key:
                        sap_adapter.acknowledge_idoc(sap_listener_key, sap_delivery_id, result.status == 'completed')
                except Exception:
                    if sap_delivery_id and sap_listener_key:
                        try: sap_adapter.acknowledge_idoc(sap_listener_key, sap_delivery_id, False)
                        except Exception: pass
                    raise
                previous = runtime_states.get(project_id, {})
                combined_logs = list(previous.get('logs', [])) + result.logs
                append_project_logs(project_id, item.name, result.logs, _project_log_directory(item, environment))
                _publish_runtime_state(project_id, status='listening', logs=combined_logs[-500:], result=result, environment=environment)
                if activity.type == 'timer':
                    repeat = runtime.as_bool(resolved_config.get('repeatEnabled', False))
                    cron = str(resolved_config.get('scheduleMode') or '').lower() == 'cron'
                    if not repeat and not cron: return
                    if repeat and not cron:
                        multiplier = {'seconds':1, 'minutes':60, 'hours':3600, 'days':86400}.get(str(resolved_config.get('unit') or 'minutes').lower(), 60)
                        await asyncio.sleep(max(1.0, float(resolved_config.get('interval', 1) or 1) * multiplier))
                elif activity.type == 'file':
                    await asyncio.sleep(max(.1, float(resolved_config.get('pollInterval', 1) or 1)))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                now = log_timestamp()
                entry = {'time': now, 'level': 'ERROR', 'kind': 'listener', 'message': f'{activity.name} listener error; reconnecting in {retry_delay:g} seconds: {exc}', 'activityId': activity.id, 'taskId': task.id}
                previous = runtime_states.get(project_id, {})
                logs = (list(previous.get('logs', [])) + [entry])[-500:]
                append_project_logs(project_id, item.name, [entry], _project_log_directory(item, environment))
                _publish_runtime_state(project_id, status='listening', logs=logs, environment=environment)
                await asyncio.sleep(retry_delay)
                retry_delay = min(30.0, retry_delay * 2)
    finally:
        if activity.type == 'sap':
            # Cancelling the Python listener task does not automatically stop
            # the persistent Java/JCo process. Close it when a Debug session
            # ends so a restarted session cannot share the old stdout stream.
            try:
                cfg = runtime.resolve(activity.config, {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}})
                resource = resources.get(cfg.get('resourceId'))
                if resource: cfg = {**runtime.resolve(resource.config, {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}), **cfg}
                sap_adapter.stop_listener(cfg)
            except Exception:
                pass
        if active_runs.get(project_id) is current: active_runs.pop(project_id, None)

async def _continuous_sap_event_loop(item: Project, task, activity, environment: str):
    """Process SAP IDocs concurrently while keeping one TID per workflow.

    JCo invokes callbacks concurrently.  The old deployment loop consumed one
    callback only after the complete workflow finished, which could leave SAP
    callbacks waiting long enough to hit CPIC/tRFC timeouts during a batch.
    Each worker below owns one delivery and acknowledges it only after the
    workflow succeeds; the bounded worker count provides backpressure without
    dropping IDocs.
    """
    project_id = item.id
    resources = {resource.id: resource for resource in item.resources}
    properties = _environment_values(item, environment)
    sap_config = {}
    try:
        configured = runtime.resolve(activity.config, {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}})
        resource = resources.get(configured.get('resourceId'))
        sap_config = {**(runtime.resolve(resource.config, {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}) if resource else {}), **configured}
        worker_count = max(1, min(64, int(sap_config.get('maxConcurrentIdocs') or sap_config.get('maximumConnections') or 8)))
    except (TypeError, ValueError):
        worker_count = 8
    retry_delay = 1.0
    stop = asyncio.Event()
    # A JCo server is one registered RFC listener, not one listener per
    # application worker.  Reading its event stream concurrently lets workers
    # consume each other's startup/log events and can make the bridge appear
    # to exit while SAP is still connected.  Serialize only the receive call;
    # the workflow itself remains concurrently processed below.
    receive_lock = asyncio.Lock()

    async def worker(index: int):
        nonlocal retry_delay
        while not stop.is_set():
            context = _listener_context(item, task, resources, properties, environment)
            delivery_id = None
            listener_key = None
            try:
                async with receive_lock:
                    output = await runtime.execute_with_policy(activity, context)
                diagnostics = output.pop('jcoDiagnostics', []) if isinstance(output, dict) else []
                if diagnostics:
                    entries = [{'time': log_timestamp(), 'level': detail.get('level', 'INFO'), 'kind': 'connector', 'phase': detail.get('phase'), 'message': detail.get('message'), 'connector': 'SAP JCo', **{key: detail[key] for key in ('serverName', 'programId', 'gatewayHost', 'gatewayService', 'repositoryDestination', 'tidStore', 'functionName', 'connectionCount') if key in detail}, 'activityId': activity.id, 'taskId': task.id} for detail in diagnostics]
                    previous = runtime_states.get(project_id, {})
                    combined = (list(previous.get('logs', [])) + entries)[-500:]
                    append_project_logs(project_id, item.name, entries, _project_log_directory(item, environment))
                    _publish_runtime_state(project_id, status='listening', logs=combined, environment=environment)
                if not _event_available(output):
                    await asyncio.sleep(.1)
                    continue
                delivery_id = output.pop('_sapDeliveryId', None)
                listener_key = output.pop('_sapListenerKey', None)
                transport = {
                    'deliveryId': delivery_id,
                    'listenerKey': listener_key,
                    'functionName': output.get('functionName') if isinstance(output, dict) else None,
                    'operation': activity.config.get('operation'),
                    'invocationProtocol': output.get('invocationProtocol') if isinstance(output, dict) else None,
                }
                result = await runtime.run(task, output, resources, properties, activity.id, item, event_output=output, transport=transport)
                request_reply = activity.config.get('operation') == 'rfc_bapi_listener' and str(transport.get('invocationProtocol') or 'Request/Reply').lower().replace('-', '').replace('/', '') in ('requestreply', 'srfc')
                if delivery_id and listener_key and request_reply and result.status == 'completed' and not transport.get('completed'):
                    result.status = 'failed'
                    result.output = {}
                    result.logs.append({'time': log_timestamp(), 'level': 'ERROR', 'kind': 'connector', 'message': 'RFC/BAPI request completed without a Reply from RFC/BAPI activity; SAP request was rolled back.', 'activityId': activity.id, 'taskId': task.id})
                if delivery_id and listener_key and not transport.get('completed'):
                    sap_adapter.acknowledge_idoc(listener_key, delivery_id, result.status == 'completed')
                previous = runtime_states.get(project_id, {})
                combined_logs = (list(previous.get('logs', [])) + result.logs)[-500:]
                append_project_logs(project_id, item.name, result.logs, _project_log_directory(item, environment))
                _publish_runtime_state(project_id, status='listening', logs=combined_logs, result=result, environment=environment)
                retry_delay = 1.0
            except asyncio.CancelledError:
                if delivery_id and listener_key and not transport.get('completed'):
                    try: sap_adapter.acknowledge_idoc(listener_key, delivery_id, False)
                    except Exception: pass
                raise
            except Exception as exc:
                if delivery_id and listener_key and not transport.get('completed'):
                    try: sap_adapter.acknowledge_idoc(listener_key, delivery_id, False)
                    except Exception: pass
                entry = {'time': log_timestamp(), 'level': 'ERROR', 'kind': 'listener', 'message': f'{activity.name} worker {index} failed; retrying in {retry_delay:g} seconds: {exc}', 'activityId': activity.id, 'taskId': task.id, 'worker': index, 'deliveryId': delivery_id}
                previous = runtime_states.get(project_id, {})
                logs = (list(previous.get('logs', [])) + [entry])[-500:]
                append_project_logs(project_id, item.name, [entry], _project_log_directory(item, environment))
                _publish_runtime_state(project_id, status='listening', logs=logs, environment=environment)
                await asyncio.sleep(retry_delay)
                retry_delay = min(30.0, retry_delay * 2)

    workers = [asyncio.create_task(worker(index), name=f'sap-idoc-worker-{index}') for index in range(worker_count)]
    try:
        await asyncio.gather(*workers)
    finally:
        stop.set()
        for task_handle in workers:
            if not task_handle.done(): task_handle.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        try:
            sap_adapter.stop_listener(sap_config)
        except Exception:
            pass

def _start_continuous_listener(item: Project, task, activity, environment: str, debug_session_id: str | None = None):
    previous = active_runs.get(item.id)
    if previous and not previous.done(): previous.cancel()
    if activity.type == 'sap':
        # Close an existing JCo server before starting the replacement. This
        # avoids two reader threads competing for one inbound event stream
        # when Debug is stopped and started quickly.
        properties = _environment_values(item, environment)
        context = {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}}
        cfg = runtime.resolve(activity.config, context)
        resource = next((value for value in item.resources if value.id == cfg.get('resourceId')), None)
        if resource: cfg = {**runtime.resolve(resource.config, context), **cfg}
        sap_adapter.stop_listener(cfg)
    listener = asyncio.create_task(
        _continuous_event_loop(item, task, activity, environment, debug_session_id)
        if debug_session_id or activity.type != 'sap'
        else _continuous_sap_event_loop(item, task, activity, environment),
        name=f'{item.id}-{task.id}-{activity.id}-listener',
    )
    active_runs[item.id] = listener
    return listener

@app.get('/api/health')
def health(): return {'status': 'ok', 'runtime': 'python'}

@app.get('/api/ai/status')
def ai_status():
    return {'available': True, 'provider': 'openai' if os.getenv('OPENAI_API_KEY') else 'local-blueprint', 'model': os.getenv('MINA_AI_MODEL', 'gpt-5') if os.getenv('OPENAI_API_KEY') else None, 'credentialsStoredInProject': False}

@app.post('/api/ai/generate')
async def ai_generate(request: AIBuildRequest):
    try: return await generate_ai_design(request.requirement, request.scope, request.current_task)
    except httpx.HTTPStatusError as exc: raise HTTPException(502, f'AI provider rejected the design request: {exc.response.text[:500]}')
    except (ValueError, json.JSONDecodeError) as exc: raise HTTPException(422, f'AI design did not pass Studio validation: {exc}')

@app.get('/api/projects', response_model=list[Project])
def projects(): return list_projects()

@app.get('/api/projects/{project_id}', response_model=Project)
def project(project_id: str):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    return item

@app.get('/api/projects/{project_id}/runtime-state')
def runtime_state(project_id: str):
    if not get_project(project_id): raise HTTPException(404, 'Project not found')
    return runtime_states.get(project_id, {'status': 'stopped', 'logs': [], 'endpoints': [], 'activityOutputs': {}, 'taskOutputs': {}, 'lastExecution': None, 'executions': []})

@app.get('/api/projects/{project_id}/logs')
def project_logs(project_id: str, limit: int = 1000, environment: str = 'local'):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    if environment not in item.properties: raise HTTPException(400, f'Environment {environment!r} was not found')
    directory = _project_log_directory(item, environment)
    return {**project_log_info(project_id, item.name, directory), 'environment': environment, 'propertyKey': 'runtime.logDirectory', 'configuredDirectory': directory, 'entries': read_project_logs(project_id, item.name, limit, directory)}

@app.post('/api/projects', response_model=Project)
def create_project(item: Project):
    try: return save_project(item)
    except ValueError as error: raise HTTPException(400, str(error)) from error

@app.put('/api/projects/{project_id}', response_model=Project)
def update_project(project_id: str, item: Project):
    if project_id != item.id: raise HTTPException(400, 'Project id mismatch')
    try: return save_project(item)
    except ValueError as error: raise HTTPException(400, str(error)) from error

@app.delete('/api/projects/{project_id}')
def remove_project(project_id: str):
    if not delete_project(project_id): raise HTTPException(404, 'Project not found')
    return {'deleted': True, 'projectId': project_id}

@app.get('/api/projects/{project_id}/json')
def project_json(project_id: str):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    filename = re.sub(r'[^A-Za-z0-9_.-]+','-',item.name).strip('-') or item.id
    return Response(item.model_dump_json(indent=2), media_type='application/json', headers={'Content-Disposition':f'attachment; filename="{filename}.json"','X-Project-Storage':str(project_dir(project_id))})

@app.post('/api/projects/{project_id}/run')
async def run(project_id: str, http_request: Request, request: RunRequest):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    resources = {resource.id: resource for resource in item.resources}
    selected = item.properties.get(request.environment, [])
    properties = {prop.key: prop.value for prop in selected}
    task_id = request.task_id or item.active_task_id
    task = next((task for task in item.tasks if task.id == task_id), None)
    if not task: raise HTTPException(404, 'Task not found')
    if task.kind != 'starter': raise HTTPException(400, 'Sub Tasks are invoked by a Call Sub Task activity; run a Starter Task')
    events = effective_event_activities(task.activities, task.transitions)
    if len(events) != 1: raise HTTPException(400, f'Starter Task requires exactly one event activity; found {len(events)}')
    event = events[0]
    diagnostics = _startup_diagnostics(item, task, resources, properties, request.environment, 'RUN')
    endpoints = _listener_endpoints(item, task, request.environment, str(http_request.base_url).rstrip('/'))
    if endpoints:
        try:await _start_http_listener(item,task,event,request.environment)
        except Exception as error:raise HTTPException(400,f'HTTP listener startup failed: {error}')
        lifecycle = diagnostics + _lifecycle_logs(item, endpoints)
        append_project_logs(project_id, item.name, lifecycle, _project_log_directory(item, request.environment))
        _publish_runtime_state(project_id, status='listening', logs=lifecycle, endpoints=endpoints, environment=request.environment)
        return {'status': 'listening', 'output': {}, 'logs': lifecycle,
                'activity_outputs': {}, 'task_outputs': {}, 'endpoints': endpoints, 'executions': []}
    if _is_continuous_event(event):
        subscriptions = [_event_subscription(item, task, event, request.environment)]
        lifecycle = diagnostics + _lifecycle_logs(item, subscriptions)
        append_project_logs(project_id, item.name, lifecycle, _project_log_directory(item, request.environment))
        _publish_runtime_state(project_id, status='listening', logs=lifecycle, endpoints=subscriptions, environment=request.environment)
        _start_continuous_listener(item, task, event, request.environment)
        return {'status': 'listening', 'output': {}, 'logs': lifecycle,
                'activity_outputs': {}, 'task_outputs': {}, 'endpoints': subscriptions, 'executions': []}
    current_run = asyncio.current_task()
    if current_run: active_runs[project_id] = current_run
    runtime_states.setdefault(project_id, {})['environment'] = request.environment
    try:
        result = await runtime.run(task, request.input, resources, properties, project=item)
    except asyncio.CancelledError:
        now = log_timestamp()
        logs = list(runtime_states.get(project_id, {}).get('logs', [])) + [{'time': now, 'level': 'INFO', 'kind': 'lifecycle', 'message': f'Application {item.name} stopped by user', 'endedAt': now}]
        state = _publish_runtime_state(project_id, status='stopped', logs=logs[-500:], endpoints=[])
        return {'status': 'stopped', 'output': {}, 'logs': state['logs'], 'activity_outputs': state['activityOutputs'], 'task_outputs': state['taskOutputs'], 'endpoints': []}
    finally:
        if active_runs.get(project_id) is current_run: active_runs.pop(project_id, None)
    payload = result.model_dump()
    payload['logs'] = _lifecycle_logs(item, []) + payload.get('logs', [])
    payload['endpoints'] = []
    append_project_logs(project_id, item.name, payload['logs'], _project_log_directory(item, request.environment))
    _publish_runtime_state(project_id, status=result.status, logs=payload['logs'], endpoints=[], result=result, environment=request.environment)
    return payload

@app.post('/api/projects/{project_id}/stop')
async def stop_project(project_id: str):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    # A project may own both a debugger driver task and a continuous listener.
    # Stop all matching sessions first; the operation is deliberately
    # idempotent because Studio also sends the project-level stop request.
    sessions = [session_id for session_id, state in debugger.sessions.items() if getattr(state.get('project'), 'id', None) == project_id and state.get('status') not in ('stopping', 'stopped', 'completed', 'failed')]
    for session_id in sessions:
        await _stop_debug_session(session_id)
    active = active_runs.pop(project_id, None)
    if active and not active.done(): active.cancel()
    # Release application-scoped persistent EMS/JMS senders, including a send
    # blocked in its Java worker. Debug session scopes are closed separately.
    await asyncio.to_thread(runtime.close_application_senders, project_id)
    await _cancel_and_wait(active)
    previous = runtime_states.get(project_id, {})
    environment = str(previous.get('environment') or item.active_environment or 'local')
    now = log_timestamp()
    logs = list(previous.get('logs', []))
    if not logs or logs[-1].get('message') != f'Application {item.name} stopped by user':
        stopped_entry = {'time': now, 'level': 'INFO', 'kind': 'lifecycle', 'message': f'Application {item.name} stopped by user', 'endedAt': now}
        logs.append(stopped_entry)
        append_project_logs(project_id, item.name, [stopped_entry], _project_log_directory(item, environment))
    state = _publish_runtime_state(project_id, status='stopped', logs=logs[-500:], endpoints=[], environment=environment)
    return state

@app.get('/api/projects/{project_id}/export')
def export_project(project_id: str):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json', json.dumps({'format':'mina-project','version':2,'projectId':item.id,'name':item.name,'features':{'groups':'runtime-v1'}}, indent=2))
        archive.writestr('project.json', item.model_dump_json(indent=2))
        for task in item.tasks: archive.writestr(f'tasks/{task.id}.json', task.model_dump_json(indent=2))
        for resource in item.resources: archive.writestr(f'resources/{resource.type}/{resource.id}.json', resource.model_dump_json(indent=2))
        for schema in item.schemas: archive.writestr(f'schemas/{schema.name}', schema.content)
        for environment, values in item.properties.items(): archive.writestr(f'environments/{environment}.json', json.dumps([value.model_dump() for value in values], indent=2))
        archive.writestr('packaging.json', json.dumps(item.packaging, indent=2))
    stream.seek(0)
    filename = re.sub(r'[^A-Za-z0-9_.-]+','-',item.name).strip('-') or item.id
    return StreamingResponse(stream, media_type='application/zip', headers={'Content-Disposition':f'attachment; filename="{filename}.mpackage"'})

DEPLOYMENT_ARTIFACTS = {
    'cloud': {'dockerfile', 'configmap', 'secret', 'deployment', 'service', 'hpa', 'package'},
    'on-prem': {'application', 'environment', 'administrator', 'systemd', 'install', 'readme'},
}

def python_source_files(project_payload: dict) -> dict[str, bytes]:
    """Generate readable workflow Python using the packaged Mina DSL."""
    header = '# Generated by MINA Studio. Changes are overwritten on export.\n\n'
    def snake(name: str) -> str:
        return re.sub(r'(?<!^)(?=[A-Z])', '_', str(name)).replace('-', '_')
    def expression(value: object, indent: int = 0) -> str:
        if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
            return f'ref({value[2:-1]!r})'
        if isinstance(value, dict):
            if not value: return 'options()'
            pad = ' ' * indent; inner = ' ' * (indent + 4)
            parts = [f'{inner}{snake(key)}={expression(child, indent + 4)},' if re.fullmatch(r'[A-Za-z_]\w*', snake(key)) else f'{inner}({key!r}, {expression(child, indent + 4)}),' for key, child in value.items()]
            return 'options(\n' + '\n'.join(parts) + '\n' + pad + ')'
        if isinstance(value, list): return '[' + ', '.join(expression(item, indent) for item in value) + ']'
        return repr(value)
    def named(values: dict, indent: int = 8) -> str:
        return ''.join(f"{' ' * indent}{snake(key)}={expression(value, indent)},\n" for key, value in values.items())
    dsl = '''"""Small runtime DSL used by generated MINA Python applications."""
from app.models import Activity, CustomFunction, EnvironmentProperty, GroupDefinition, Project, SchemaAsset, SharedResource, TaskDefinition, Transition
import re

def _camel(name):
    return re.sub(r'_([a-z])', lambda match: match.group(1).upper(), name)

def _normalize(value):
    if isinstance(value, dict): return {_camel(str(key)): _normalize(child) for key, child in value.items()}
    if isinstance(value, list): return [_normalize(child) for child in value]
    return value

def options(*pairs, **values):
    result = dict(pairs); result.update(values); return _normalize(result)

def ref(path): return '${' + str(path) + '}'
def point(x=100, y=100): return {'x': x, 'y': y}

class ActivityRef:
    def __init__(self, task, activity): self.task, self.activity = task, activity
    @property
    def id(self): return self.activity.id
    def on_success(self, target, label=''):
        self.task._transition(self, target, 'success', label); return target
    def when(self, condition, target, label=''):
        self.task._transition(self, target, 'success_condition', label, condition); return target
    def otherwise(self, target, label=''):
        self.task._transition(self, target, 'success_no_match', label); return target
    def on_error(self, target, label=''):
        self.task._transition(self, target, 'error', label); return target

class ActivityFamily:
    def __init__(self, task, kind): self.task, self.kind = task, kind
    def __getattr__(self, operation):
        return lambda **values: self.task._activity(self.kind, operation if operation != 'default' else '', **values)

class Task:
    def __init__(self, id, name, kind='starter', description='', input_schema=None, output_schema=None):
        self.id, self.name, self.kind, self.description = id, name, kind, description
        self.input_schema, self.output_schema = input_schema or {}, output_schema or {}
        self.activities, self.transitions, self.groups = [], [], []
    def __getattr__(self, kind): return ActivityFamily(self, kind)
    def _activity(self, kind, operation, **values):
        activity = Activity(id=values.pop('id'), type=kind, name=values.pop('name'), position=values.pop('position', point()), config=options(operation=operation, **values))
        self.activities.append(activity); return ActivityRef(self, activity)
    def _transition(self, source, target, kind, label='', condition=''):
        self.transitions.append(Transition(id=f'{source.id}-to-{target.id}-{len(self.transitions)+1}', source=source.id, target=target.id, type=kind, label=label, condition=condition))
    def group(self, **values):
        values = dict(values); values['config'] = options(**values.pop('config', {}))
        self.groups.append(GroupDefinition(**values))
    def build(self): return TaskDefinition(id=self.id, name=self.name, kind=self.kind, description=self.description, input_schema=self.input_schema, output_schema=self.output_schema, activities=self.activities, transitions=self.transitions, groups=self.groups)

def resource(kind, *, id, name, **config): return SharedResource(id=id, type=kind, name=name, config=options(**config))
def schema(*, id, name, content): return SchemaAsset(id=id, name=name, content=content)
def function(*, id, name, parameters=None, expression='', description=''): return CustomFunction(id=id, name=name, parameters=parameters or [], expression=expression, description=description)
def profile(name, *values):
    return name, [EnvironmentProperty(key=value['key'], value=value.get('value', ''), data_type=value.get('dataType', value.get('data_type', 'string'))) for value in values]
def project(*, resources, schemas, tasks, profiles, custom_functions=None, **values): return Project(resources=resources, schemas=schemas, tasks=tasks, properties=dict(profiles), custom_functions=custom_functions or [], **values)
'''
    files: dict[str, bytes] = {
        'application/python/__init__.py': b'"""Generated MINA Python application."""\n',
        'application/python/mina_dsl.py': dsl.encode('utf-8'),
        'application/python/tasks/__init__.py': b'"""Generated executable task modules."""\n',
        'application/python/README.md': b'''# MINA Python archive

This archive contains generated workflow Python. Tasks use named activity calls
such as `task.sap.idoc_listener(...)` and transitions such as
`listener.on_success(parser)`. The included `mina_dsl.py` converts this
readable source into the MINA runtime model at startup.
''',
    }
    task_imports: list[str] = []; task_builders: list[str] = []
    for index, task in enumerate(project_payload.get('tasks', [])):
        module_name = f'task_{index}_{re.sub(r"[^A-Za-z0-9_]+", "_", str(task.get("id") or "task")).strip("_") or "task"}'
        builder_name = f'build_task_{index}'
        task_imports.append(f'from .tasks.{module_name} import build_task as {builder_name}')
        task_builders.append(f'        {builder_name}(),')
        activity_variables: dict[str, str] = {}; used: set[str] = set(); body: list[str] = []
        for position, activity in enumerate(task.get('activities', [])):
            base = snake(activity.get('name') or activity.get('id') or f'activity_{position}').lower()
            variable = re.sub(r'\W+', '_', base).strip('_') or f'activity_{position}'
            while variable in used: variable += '_next'
            used.add(variable); activity_variables[str(activity.get('id'))] = variable
            config = dict(activity.get('config') or {}); operation = str(config.pop('operation', '') or 'default')
            values = {'id': activity.get('id'), 'name': activity.get('name'), 'position': activity.get('position', {})}
            values.update(config)
            body.append(f'    {variable} = task.{activity.get("type")}.{operation}(\n{named(values)}    )\n')
        for transition in task.get('transitions', []):
            source, target = activity_variables.get(str(transition.get('source'))), activity_variables.get(str(transition.get('target')))
            if not source or not target: continue
            kind = transition.get('type') or 'success'; label = transition.get('label') or ''; condition = transition.get('condition') or ''
            if kind == 'success_condition': body.append(f'    {source}.when({expression(condition)}, {target}, label={label!r})\n')
            elif kind == 'success_no_match': body.append(f'    {source}.otherwise({target}, label={label!r})\n')
            elif kind == 'error': body.append(f'    {source}.on_error({target}, label={label!r})\n')
            else: body.append(f'    {source}.on_success({target}, label={label!r})\n')
        for group in task.get('groups', []): body.append(f'    task.group(\n{named(group)}    )\n')
        fields = {key: value for key, value in task.items() if key not in {'activities', 'transitions', 'groups'}}
        files[f'application/python/tasks/{module_name}.py'] = (header +
            'from ..mina_dsl import Task, options, point, ref\n\n\n'
            'def build_task():\n'
            '    task = Task(\n' + named(fields) + '    )\n' + ''.join(body) + '    return task.build()\n').encode('utf-8')
    resources = ''.join(f"        resource({resource.get('type')!r},\n{named({**{key: value for key, value in resource.items() if key not in {'type', 'config'}}, **dict(resource.get('config') or {})}, 12)}        ),\n" for resource in project_payload.get('resources', []))
    files['application/python/resources.py'] = (header + 'from .mina_dsl import options, ref, resource\n\n\ndef build_resources():\n    return [\n' + resources + '    ]\n').encode('utf-8')
    schemas = ''.join(f"        schema(\n{named(schema_value, 12)}        ),\n" for schema_value in project_payload.get('schemas', []))
    files['application/python/schemas.py'] = (header + 'from .mina_dsl import options, ref, schema\n\n\ndef build_schemas():\n    return [\n' + schemas + '    ]\n').encode('utf-8')
    project_fields = {key: value for key, value in project_payload.items() if key not in {'resources', 'schemas', 'tasks', 'custom_functions', 'properties'}}
    functions = ''.join(f"        function(\n{named(function_value, 12)}        ),\n" for function_value in project_payload.get('custom_functions', []))
    profiles = ''.join(f"        profile({environment!r},\n" + ''.join(f"            options(\n{named(value, 16)}            ),\n" for value in values) + '        ),\n' for environment, values in project_payload.get('properties', {}).items())
    files['application/python/project.py'] = (header +
        'from .mina_dsl import function, options, profile, project, ref\nfrom .resources import build_resources\nfrom .schemas import build_schemas\n' + '\n'.join(task_imports) + '\n\n\n'
        'def build_project():\n    return project(\n' + named(project_fields) +
        '        resources=build_resources(),\n        schemas=build_schemas(),\n        tasks=[\n' + '\n'.join(task_builders) + '\n        ],\n        profiles=[\n' + profiles + '        ],\n        custom_functions=[\n' + functions + '        ],\n    )\n').encode('utf-8')
    return files

def packaging_task_closure(item: Project, starter_ids: list[str] | None = None) -> tuple[Project, list[str], list[str]]:
    """Select package roots and follow statically determinable Call Process dependencies."""
    tasks = {task.id: task for task in item.tasks}
    names = {task.name.casefold(): task.id for task in item.tasks}
    available_roots = [task.id for task in item.tasks if task.kind == 'starter']
    roots = list(dict.fromkeys(starter_ids or available_roots))
    if not roots: raise HTTPException(400, 'The project has no Starter Tasks to package')
    invalid = [task_id for task_id in roots if task_id not in tasks or tasks[task_id].kind != 'starter']
    if invalid: raise HTTPException(400, f'Packaging roots must be Starter Tasks: {", ".join(invalid)}')
    included: list[str] = []
    visiting: set[str] = set()
    def visit(task_id: str):
        if task_id in visiting: return
        visiting.add(task_id); included.append(task_id)
        for activity in tasks[task_id].activities:
            if activity.type != 'call_task': continue
            configured = str(activity.config.get('taskId') or '').strip()
            dynamic = str(activity.config.get('dynamicTaskId') or '').strip()
            candidates = [configured]
            if dynamic and not dynamic.startswith('${'): candidates.insert(0, dynamic)
            target_id = next((value for value in candidates if value in tasks), '')
            if not target_id: target_id = next((names.get(value.casefold(), '') for value in candidates if value and names.get(value.casefold())), '')
            if not target_id:
                if dynamic.startswith('${') and not configured:
                    raise HTTPException(400, f'{tasks[task_id].name} / {activity.name} uses a dynamic Call Process expression without a static fallback; packaging cannot determine its dependency')
                raise HTTPException(400, f'{tasks[task_id].name} / {activity.name} references missing Sub Task {configured or dynamic!r}')
            if tasks[target_id].kind != 'subtask': raise HTTPException(400, f'{tasks[task_id].name} / {activity.name} must call a Sub Task, not Starter Task {tasks[target_id].name}')
            visit(target_id)
    for root in roots: visit(root)
    selected = item.model_copy(deep=True)
    selected_by_id = {task.id: task for task in selected.tasks}
    selected.tasks = [selected_by_id[task_id] for task_id in included]
    selected.active_task_id = roots[0]
    selected.packaging = {**selected.packaging, 'starterTaskIds': roots, 'includedTaskIds': included}
    return selected, roots, included

PROPERTY_REFERENCE = re.compile(r"\$\{properties\.([^}]+)\}")

def deployment_property_profile(item: Project, environment: str) -> list[dict]:
    """Return only properties needed by the selected application package.

    References are discovered from the selected tasks and shared resources,
    then followed through property-to-property expressions. The runtime log
    directory is retained because the runtime consumes it outside activity
    configuration. Unreferenced connector defaults are intentionally omitted.
    """
    source = [value.model_dump() for value in item.properties[environment]]
    by_key = {str(value.get('key')): value for value in source}
    task_models = [task.model_dump() for task in item.tasks]
    referenced_resource_ids: set[str] = set()
    def collect_resource_ids(value):
        if isinstance(value, dict):
            resource_id = value.get('resourceId')
            if isinstance(resource_id, str) and resource_id.strip(): referenced_resource_ids.add(resource_id.strip())
            for child in value.values(): collect_resource_ids(child)
        elif isinstance(value, list):
            for child in value: collect_resource_ids(child)
    for task in task_models: collect_resource_ids(task)
    resources = [resource.model_dump() for resource in item.resources if resource.id in referenced_resource_ids]
    searchable = task_models + resources
    referenced: set[str] = set()
    for value in searchable:
        referenced.update(match.group(1) for match in PROPERTY_REFERENCE.finditer(json.dumps(value, ensure_ascii=False)))
    if 'runtime.logDirectory' in by_key:
        referenced.add('runtime.logDirectory')
    # Resolve property aliases such as ${properties.connections.sap.host}.
    pending = list(referenced)
    while pending:
        key = pending.pop()
        value = by_key.get(key)
        if not value: continue
        for alias in PROPERTY_REFERENCE.findall(str(value.get('value', ''))):
            if alias not in referenced:
                referenced.add(alias); pending.append(alias)
    # Keep every value the user actually configured, even when a dynamic
    # expression prevents static reference discovery. Empty connector
    # placeholders remain excluded unless they are referenced explicitly.
    return [
        value for value in source
        if value.get('key') in referenced or value.get('value') not in (None, '')
    ]

def deployment_package_files(item: Project, target: str, environment: str, artifacts: set[str] | None = None) -> dict[str, bytes]:
    if target not in {'on-prem', 'cloud'}:
        raise HTTPException(400, 'Target must be on-prem or cloud')
    if environment not in item.properties:
        raise HTTPException(400, f'Unknown environment: {environment}')
    allowed_artifacts = DEPLOYMENT_ARTIFACTS[target]
    selected_artifacts = set(artifacts) if artifacts is not None else set(allowed_artifacts)
    unknown_artifacts = selected_artifacts - allowed_artifacts
    if unknown_artifacts:
        raise HTTPException(400, f'Unsupported {target} deployment artifacts: {", ".join(sorted(unknown_artifacts))}')
    artifact = item.packaging.get('artifact_name') or item.id
    version = item.packaging.get('version') or '1.0.0'
    properties = deployment_property_profile(item, environment)
    # Only configured secret values are deployment requirements. Environment
    # profiles contain many connector-specific password placeholders; marking
    # every placeholder as required makes the Control Plane reject otherwise
    # valid deployments with "required secrets are missing".
    secret_keys = [
        value['key'] for value in properties
        if value.get('data_type') == 'password'
        and value.get('value') not in (None, '')
    ]
    for value in properties:
        if value.get('data_type') == 'password': value['value'] = ''
    sensitive = re.compile(r'(password|passwd|secret|token|private.?key|credential|service.?account)', re.I)
    def scrub(value, path=''):
        if isinstance(value, dict):
            output = {}
            for key, child in value.items():
                child_path = f'{path}.{key}'.strip('.')
                location = str(key).lower().endswith(('url','file','path'))
                if sensitive.search(str(key)) and not location and isinstance(child, (str, bytes)) and not str(child).startswith('${properties.'):
                    output[key] = ''
                    if child: secret_keys.append(child_path)
                else: output[key] = scrub(child, child_path)
            return output
        if isinstance(value, list): return [scrub(child, f'{path}[{index}]') for index, child in enumerate(value)]
        return value
    sanitized_project = item.model_dump()
    sanitized_project['properties'] = {environment: properties}
    sanitized_project = scrub(sanitized_project)
    sanitized_project['properties'] = {environment: properties}
    sanitized_resources = [scrub(resource.model_dump(), f'resources.{resource.id}') for resource in item.resources]
    secret_keys = sorted(set(secret_keys))
    manifest = {
        'format': 'mina-deployment', 'formatVersion': 2,
        'applicationId': item.id, 'applicationName': item.name,
        'artifact': artifact, 'version': version, 'target': target,
        'environment': environment, 'runtime': 'mina-python',
        'secretKeys': secret_keys,
        'selectedArtifacts': sorted(selected_artifacts),
        'features': {'groups': 'runtime-v1'},
    }
    files: dict[str, bytes] = {
        'manifest.json': json.dumps(manifest, indent=2).encode(),
        'application/project.json': json.dumps(sanitized_project, indent=2).encode(),
        f'environments/{environment}.json': json.dumps(properties, indent=2).encode(),
        'deployment/secrets.required.json': json.dumps({'required': secret_keys}, indent=2).encode(),
    }
    for task in item.tasks: files[f'application/tasks/{task.id}.json'] = task.model_dump_json(indent=2).encode()
    for resource, payload in zip(item.resources, sanitized_resources): files[f'application/resources/{resource.type}/{resource.id}.json'] = json.dumps(payload, indent=2).encode()
    for schema in item.schemas: files[f'application/schemas/{schema.name}'] = schema.content.encode()
    if str(item.packaging.get('sourceFormat') or '').lower() == 'python':
        manifest['runtime'] = 'mina-python-source'
        manifest['pythonSource'] = {'entrypoint': 'application/python/project.py', 'formatVersion': 1}
        files['manifest.json'] = json.dumps(manifest, indent=2).encode()
        files.update(python_source_files(sanitized_project))
    deployment_name = re.sub(r'[^a-z0-9-]+', '-', artifact.lower()).strip('-')[:63] or 'mina-app'
    if target == 'cloud':
        image = str(item.packaging.get('image') or f'mina/{artifact}:{version}')
        replicas = max(1, int(item.packaging.get('replicas') or 1))
        minimum_replicas = max(1, int(item.packaging.get('minimumReplicas') or replicas))
        maximum_replicas = max(minimum_replicas, int(item.packaging.get('maximumReplicas') or max(3, minimum_replicas)))
        cpu_target = min(100, max(1, int(item.packaging.get('cpuTargetPercent') or 70)))
        service_type = str(item.packaging.get('serviceType') or 'ClusterIP')
        discovered_ports: list[int] = []
        for resource in item.resources:
            if resource.type != 'http': continue
            try:
                port = int(resource.config.get('port') or 0)
                if 1 <= port <= 65535: discovered_ports.append(port)
            except (TypeError, ValueError): pass
        container_port = int(item.packaging.get('containerPort') or (discovered_ports[0] if discovered_ports else 8787))
        public_properties = [value for value in properties if value.get('data_type') != 'password']
        config_data = '\n'.join(f'  {value["key"]}: {json.dumps(str(value.get("value", "")))}' for value in public_properties) or '  {}'
        secret_data = '\n'.join(f'  {key}: ""' for key in secret_keys) or '  {}'
        if 'dockerfile' in selected_artifacts:
            files['deployment/cloud/Dockerfile'] = (f'''FROM mina-runtime:latest
LABEL org.opencontainers.image.title="{artifact}" org.opencontainers.image.version="{version}"
COPY application /opt/mina/application
COPY environments /opt/mina/environments
ENV MINA_ENVIRONMENT={environment} MINA_APPLICATION_DIR=/opt/mina/application
EXPOSE {container_port}
USER 10001
ENTRYPOINT ["mina-runtime"]
''').encode()
        if 'configmap' in selected_artifacts:
            files['deployment/cloud/configmap.yaml'] = f'''apiVersion: v1
kind: ConfigMap
metadata:
  name: {deployment_name}-config
  labels:
    app.kubernetes.io/name: {deployment_name}
    app.kubernetes.io/version: {json.dumps(version)}
data:
{config_data}
'''.encode()
        if 'secret' in selected_artifacts:
            files['deployment/cloud/secret.yaml'] = f'''apiVersion: v1
kind: Secret
metadata:
  name: {deployment_name}-secrets
type: Opaque
stringData:
{secret_data}
'''.encode()
        if 'deployment' in selected_artifacts:
            env_from = ''
            if 'configmap' in selected_artifacts: env_from += f'            - configMapRef:\n                name: {deployment_name}-config\n'
            if 'secret' in selected_artifacts: env_from += f'            - secretRef:\n                name: {deployment_name}-secrets\n'
            # Keep escape sequences outside the replacement field so this
            # module remains valid on the Python 3.11 desktop build runtime.
            env_from_yaml = env_from or '            []\n'
            files['deployment/cloud/deployment.yaml'] = f'''apiVersion: apps/v1
kind: Deployment
metadata:
  name: {deployment_name}
  labels:
    app.kubernetes.io/name: {deployment_name}
spec:
  replicas: {replicas}
  selector:
    matchLabels:
      app.kubernetes.io/name: {deployment_name}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {deployment_name}
    spec:
      containers:
        - name: runtime
          image: {image}
          imagePullPolicy: IfNotPresent
          ports:
            - name: http
              containerPort: {container_port}
          env:
            - name: MINA_ENVIRONMENT
              value: {json.dumps(environment)}
            - name: MINA_APPLICATION_DIR
              value: /opt/mina/application
          envFrom:
{env_from_yaml}          readinessProbe:
            tcpSocket:
              port: http
            initialDelaySeconds: 5
          livenessProbe:
            tcpSocket:
              port: http
            initialDelaySeconds: 15
          resources:
            requests: {{cpu: 100m, memory: 256Mi}}
            limits: {{cpu: "1", memory: 1Gi}}
'''.encode()
        if 'service' in selected_artifacts:
            files['deployment/cloud/service.yaml'] = f'''apiVersion: v1
kind: Service
metadata:
  name: {deployment_name}
spec:
  type: {service_type}
  selector:
    app.kubernetes.io/name: {deployment_name}
  ports:
    - name: http
      port: {container_port}
      targetPort: http
'''.encode()
        if 'hpa' in selected_artifacts:
            files['deployment/cloud/hpa.yaml'] = f'''apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {deployment_name}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {deployment_name}
  minReplicas: {minimum_replicas}
  maxReplicas: {maximum_replicas}
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: {cpu_target}
'''.encode()
        if 'package' in selected_artifacts:
            resources = [f'{name}.yaml' for name in ('configmap', 'secret', 'deployment', 'service', 'hpa') if name in selected_artifacts]
            resource_lines = '\n'.join(f'  - {name}' for name in resources) or '  []'
            files['deployment/cloud/kustomization.yaml'] = f'''apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
{resource_lines}
commonLabels:
  app.kubernetes.io/managed-by: mina
'''.encode()
            files['deployment/cloud/package.json'] = json.dumps({'image': image, 'environment': environment, 'artifacts': sorted(selected_artifacts)}, indent=2).encode()
    else:
        instances = max(1, int(item.packaging.get('instances') or 1))
        start_on_boot = str(item.packaging.get('startOnBoot') or 'false').lower() in ('true', '1', 'yes', 'on')
        shutdown_seconds = max(1, int(item.packaging.get('gracefulShutdownSeconds') or 60))
        install_root = str(item.packaging.get('installRoot') or f'/opt/mina/apps/{artifact}')
        windows_install_root = str(item.packaging.get('windowsInstallRoot') or f'C:\\ProgramData\\MINA\\apps\\{artifact}')
        if 'application' in selected_artifacts:
            files['deployment/on-prem/application.json'] = json.dumps({
                'application': artifact, 'version': version, 'environment': environment,
                'engine': 'isolated', 'instances': instances, 'startOnBoot': start_on_boot,
                'gracefulShutdownSeconds': shutdown_seconds, 'secretProvider': 'administrator',
                'installRoot': install_root,
            }, indent=2).encode()
        if 'environment' in selected_artifacts:
            files['deployment/on-prem/environment.properties'] = ('\n'.join(f'{value["key"]}={value.get("value", "")}' for value in properties if value.get('data_type') != 'password') + '\n').encode()
        if 'administrator' in selected_artifacts:
            files['deployment/on-prem/deploy.sh'] = f'''#!/usr/bin/env sh
set -eu
mina-admin deploy --application {artifact} --version {version} --environment {environment} --package "$1"
mina-admin scale --application {artifact} --instances {instances}
{'mina-admin start --application ' + artifact if start_on_boot else '# Start manually with: mina-admin start --application ' + artifact}
'''.encode()
            files['deployment/on-prem/deploy.ps1'] = f'''param([Parameter(Mandatory=$true)][string]$PackagePath)
$ErrorActionPreference = "Stop"
mina-admin deploy --application "{artifact}" --version "{version}" --environment "{environment}" --package $PackagePath
mina-admin scale --application "{artifact}" --instances {instances}
{'mina-admin start --application "' + artifact + '"' if start_on_boot else '# Start manually with: mina-admin start --application "' + artifact + '"'}
'''.encode()
        if 'systemd' in selected_artifacts:
            files[f'deployment/on-prem/{deployment_name}.service'] = f'''[Unit]
Description=MINA {artifact}
After=network-online.target
[Service]
Type=simple
User=mina
WorkingDirectory={install_root}
Environment=MINA_ENVIRONMENT={environment}
ExecStart=/usr/local/bin/mina-runtime --application {install_root}/application
TimeoutStopSec={shutdown_seconds}
Restart=on-failure
[Install]
WantedBy=multi-user.target
'''.encode()
        if 'install' in selected_artifacts:
            files['deployment/on-prem/install.sh'] = f'''#!/usr/bin/env sh
set -eu
install -d -m 0750 "{install_root}"
cp -R application environments "{install_root}/"
echo "Install required secrets listed in deployment/secrets.required.json before starting."
'''.encode()
            files['deployment/on-prem/install.ps1'] = f'''param([string]$InstallRoot = "{windows_install_root.replace(chr(34), chr(34) * 2)}")
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
Copy-Item -Recurse -Force application,environments -Destination $InstallRoot
Write-Host "Installed {artifact} {version} to $InstallRoot. Configure deployment/secrets.required.json values in Control Plane before starting."
'''.encode()
            files['deployment/on-prem/start.ps1'] = f'''param([string]$InstallRoot = "{windows_install_root.replace(chr(34), chr(34) * 2)}")
$env:MINA_ENVIRONMENT = "{environment}"
$env:MINA_APPLICATION_DIR = Join-Path $InstallRoot "application"
& mina-runtime --application $env:MINA_APPLICATION_DIR
'''.encode()
        if 'readme' in selected_artifacts:
            files['deployment/on-prem/README.txt'] = f'''MINA on-premises deployment
Application: {artifact}
Version: {version}
Environment: {environment}
Instances: {instances}
Install root: {install_root}

1. Supply values listed in deployment/secrets.required.json through Administrator.
2. Run install.sh, or import application.json through MINA Control Plane.
3. Run deploy.sh with this package path and start the application when ready.

Windows PowerShell:
1. Run: .\\install.ps1
2. Deploy through Control Plane, or run: .\\deploy.ps1 -PackagePath <archive-path>
3. For a standalone foreground runtime, run: .\\start.ps1
Windows install root: {windows_install_root}
'''.encode()
    return files

def multi_environment_package_files(item: Project, target: str, environments: list[str], artifacts: set[str] | None = None) -> dict[str, bytes]:
    """Build one immutable application with independently deployable environment profiles."""
    selected = list(dict.fromkeys(value.strip() for value in environments if value.strip()))
    if not selected: raise HTTPException(400, 'Select at least one packaging environment')
    unknown = [value for value in selected if value not in item.properties]
    if unknown: raise HTTPException(400, f'Unknown environments: {", ".join(unknown)}')
    if len(selected) == 1: return deployment_package_files(item, target, selected[0], artifacts)
    profiles = {environment: deployment_package_files(item, target, environment, artifacts) for environment in selected}
    first = profiles[selected[0]]
    files = {name: body for name, body in first.items() if not name.startswith('deployment/') and not name.startswith('environments/')}
    project_payload = json.loads(files['application/project.json'])
    project_payload['properties'] = {}
    required_by_environment: dict[str, list[str]] = {}
    for environment, generated in profiles.items():
        properties = json.loads(generated[f'environments/{environment}.json'])
        project_payload['properties'][environment] = properties
        files[f'environments/{environment}.json'] = generated[f'environments/{environment}.json']
        required = json.loads(generated['deployment/secrets.required.json']).get('required', [])
        required_by_environment[environment] = required
        profile_root = f'deployment/{target}/profiles/{environment}'
        source_root = f'deployment/{target}/'
        for name, body in generated.items():
            if not name.startswith(source_root): continue
            relative = name[len(source_root):]
            if target == 'cloud' and relative == 'Dockerfile':
                files['deployment/cloud/Dockerfile'] = body
            else: files[f'{profile_root}/{relative}'] = body
        files[f'{profile_root}/secrets.required.json'] = json.dumps({'environment': environment, 'required': required}, indent=2).encode()
    files['application/project.json'] = json.dumps(project_payload, indent=2).encode()
    files['deployment/secrets.required.json'] = json.dumps({'profiles': required_by_environment}, indent=2).encode()
    manifest = json.loads(files['manifest.json'])
    manifest.pop('environment', None); manifest['environments'] = selected; manifest['profileLayout'] = f'deployment/{target}/profiles/<environment>'
    manifest['secretKeysByEnvironment'] = required_by_environment
    files['manifest.json'] = json.dumps(manifest, indent=2).encode()
    return files

def build_deployment_archive(item: Project, target: str, environments: list[str], starter_ids: list[str] | None,
                             archive: str, artifacts: set[str] | None) -> tuple[bytes, str, str, dict]:
    """Build the exact archive used by both download and direct Control Plane deployment."""
    selected, root_tasks, included_tasks = packaging_task_closure(item, starter_ids)
    selected.packaging.pop('sourceFormat', None)
    files = multi_environment_package_files(selected, target, environments, artifacts)
    manifest = json.loads(files['manifest.json'])
    manifest['starterTaskIds'], manifest['includedTaskIds'] = root_tasks, included_tasks
    if archive in ('python', 'python-engine', 'python-direct'):
        from .raw_python import engine_python_files, raw_python_files, raw_python_requirements
        # The standard package builder provides exactly the same secret
        # sanitization and selected profile closure.  Its JSON descriptors
        # are input to the compiler only; none enter the raw archive.
        project_payload = json.loads(files['application/project.json'])
        profile_values = project_payload['properties']
        try:
            python_files = raw_python_files(project_payload, profile_values) if archive == 'python-direct' else engine_python_files(project_payload, profile_values)
        except ValueError as error:
            raise HTTPException(400, str(error)) from error
        manifest['runtime'] = 'python-async-standalone'
        manifest['pythonSource'] = {'entrypoint': 'application/main.py', 'formatVersion': 2, 'mode': 'direct' if archive == 'python-direct' else 'engine'}
        if archive == 'python-direct':
            manifest['pythonSource']['scriptEntrypoint'] = 'run.py'
            manifest['pythonSource']['zipEntrypoint'] = '__main__.py'
            dependency_checks, external_files = raw_python_requirements(project_payload)
            manifest['pythonSource']['preflightCommand'] = 'python run.py --check'
            manifest['pythonSource']['qualificationCommand'] = 'python run.py --qualify-task <task-id> --iterations 1000 --concurrency 10'
            manifest['pythonSource']['dependencies'] = dependency_checks
            manifest['pythonSource']['externalFiles'] = external_files
        manifest.pop('profileLayout', None)
        manifest['selectedArtifacts'] = []
        def raw_secret_keys(keys: list[str]) -> list[str]:
            normalized = []
            for key in keys:
                match = re.fullmatch(r'resources\[(\d+)\](\..+)', key)
                if match:
                    index = int(match.group(1))
                    if index < len(selected.resources):
                        key = f'resources.{selected.resources[index].id}{match.group(2)}'
                if key.startswith('tasks['):
                    raise HTTPException(400, 'Raw Python cannot inject task-level inline secrets; map them to typed environment properties')
                normalized.append(key)
            return sorted(set(normalized))
        manifest['secretKeys'] = raw_secret_keys(manifest.get('secretKeys') or [])
        if isinstance(manifest.get('secretKeysByEnvironment'), dict):
            manifest['secretKeysByEnvironment'] = {
                environment: raw_secret_keys(keys) for environment, keys in manifest['secretKeysByEnvironment'].items()
            }
        manifest['taskInventory'] = [
            {'id': task.id, 'name': task.name, 'kind': task.kind, 'starter': task.kind == 'starter',
             'description': task.description, 'activityCount': len(task.activities),
             'activities': [{'id': activity.id, 'name': activity.name, 'type': activity.type} for activity in task.activities]}
            for task in selected.tasks
        ]
        files = python_files
    files['manifest.json'] = json.dumps(manifest, indent=2).encode()
    artifact = re.sub(r'[^A-Za-z0-9_.-]+', '-', selected.packaging.get('artifact_name') or selected.id).strip('-')
    version = re.sub(r'[^A-Za-z0-9_.-]+', '-', selected.packaging.get('version') or '1.0.0').strip('-')
    stream = io.BytesIO()
    if archive == 'tar.gz':
        with tarfile.open(fileobj=stream, mode='w:gz') as bundle:
            for name, body in files.items():
                info = tarfile.TarInfo(name); info.size = len(body); bundle.addfile(info, io.BytesIO(body))
        extension, media = 'tar.gz', 'application/gzip'
    elif archive in {'mpkg', 'ifpkg', 'ear', 'zip', 'python', 'python-engine', 'python-direct'}:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as bundle:
            for name, body in files.items(): bundle.writestr(name, body)
        extension = 'ear' if archive == 'ear' else ('zip' if archive == 'zip' else ('pympkg' if archive in {'python', 'python-engine', 'python-direct'} else archive))
        media = 'application/java-archive' if archive == 'ear' else 'application/zip'
    else:
        raise HTTPException(400, 'Archive must be mpkg, zip, ear, tar.gz, python-engine, or python-direct (legacy ifpkg is also accepted)')
    return stream.getvalue(), f'{artifact}-{version}-{target}.{extension}', media, manifest

def _package_failure(item: Project, environments: list[str], error: Exception) -> HTTPException:
    """Persist useful build diagnostics while keeping configured secrets out of logs/UI."""
    status = error.status_code if isinstance(error, HTTPException) else 500
    detail = str(error.detail if isinstance(error, HTTPException) else error) or type(error).__name__
    trace = ''.join(traceback.format_exception(error))
    secrets = []
    for values in item.properties.values():
        for prop in values:
            if any(word in prop.key.lower() for word in ('password', 'secret', 'token', 'private', 'credential')):
                secrets.append(str(prop.value or ''))
    for resource in item.resources:
        for key, value in resource.config.items():
            if any(word in key.lower() for word in ('password', 'secret', 'token', 'private', 'credential')):
                secrets.append(str(value or ''))
    for secret in sorted({value for value in secrets if len(value) >= 4}, key=len, reverse=True):
        detail = detail.replace(secret, '[REDACTED]')
        trace = trace.replace(secret, '[REDACTED]')
    # Studio's saved-log button reads the active environment; package-build
    # failures belong there even when the archive targets other profiles.
    environment = item.active_environment or (environments[0] if environments else 'local')
    directory = _project_log_directory(item, environment)
    try:
        append_project_logs(item.id, item.name, [{
            'time': log_timestamp(), 'level': 'ERROR', 'kind': 'packaging',
            'message': f'{type(error).__name__}: {detail}',
            'traceback': trace[-12000:], 'environments': environments,
        }], directory)
        path = project_log_info(item.id, item.name, directory)['path']
        suffix = f' See project log: {path}'
    except Exception:
        suffix = ' The diagnostic log could not be written; check log directory permissions.'
    return HTTPException(status, f'Package generation failed: {detail}.{suffix}')

class ControlPlaneDeployRequest(BaseModel):
    target: str = 'on-prem'
    environments: list[str] = Field(default_factory=list)
    starterTaskIds: list[str] = Field(default_factory=list)
    archive: str = 'mpkg'
    artifacts: list[str] = Field(default_factory=list)
    controlPlaneUrl: str
    credential: str = ''
    verifyTls: bool = True
    caCertificatePath: str = ''
    teamId: str | None = None
    deploymentEnvironment: str
    dataPlaneId: str = 'localhost'
    capabilityId: str | None = None
    namespace: str = 'default'
    instances: int = Field(default=1, ge=1, le=100)
    secrets: dict[str, str] = Field(default_factory=dict)
    start: bool = True

class ControlPlaneConnectionRequest(BaseModel):
    controlPlaneUrl: str
    credential: str = ''
    verifyTls: bool = True
    caCertificatePath: str = ''

def _control_plane_client_options(payload: ControlPlaneDeployRequest | ControlPlaneConnectionRequest) -> tuple[str, dict, bool | str]:
    base_url = payload.controlPlaneUrl.strip().rstrip('/')
    if not re.match(r'^https?://', base_url, re.I):
        raise HTTPException(400, 'Control Plane URL must begin with http:// or https://')
    headers = {'x-control-plane-key': payload.credential.strip()} if payload.credential.strip() else {}
    verify: bool | str = payload.verifyTls
    if payload.caCertificatePath.strip():
        certificate = Path(payload.caCertificatePath).expanduser()
        if not certificate.is_file(): raise HTTPException(400, 'Control Plane CA certificate file was not found')
        verify = str(certificate.resolve())
    return base_url, headers, verify

@app.post('/api/control-plane/deployment-targets')
async def control_plane_deployment_targets(payload: ControlPlaneConnectionRequest):
    base_url, headers, verify = _control_plane_client_options(payload)
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=10.0), verify=verify, follow_redirects=False) as client:
            planes_response = await client.get(f'{base_url}/api/data-planes', headers=headers)
            planes_response.raise_for_status()
            capabilities_response = await client.get(f'{base_url}/api/capabilities', headers=headers)
            capabilities_response.raise_for_status()
        return {'dataPlanes': planes_response.json(), 'capabilities': capabilities_response.json()}
    except httpx.HTTPStatusError as exc:
        try: detail = exc.response.json().get('detail')
        except Exception: detail = exc.response.text[:500]
        raise HTTPException(502, f'Control Plane rejected target discovery: {detail or exc.response.reason_phrase}') from exc
    except httpx.RequestError as exc:
        raise HTTPException(502, f'Unable to reach Control Plane at {base_url}: {exc}') from exc

@app.get('/api/projects/{project_id}/package')
def package_project(project_id: str, target: str = 'on-prem', environment: str = 'local', environments: str = '', starters: str = '', archive: str = 'mpkg', artifacts: str = ''):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    selected_starters = [value.strip() for value in starters.split(',') if value.strip()] if starters else None
    selected_artifacts = {value.strip() for value in artifacts.split(',') if value.strip()} if artifacts else None
    selected_environments = [value.strip() for value in environments.split(',') if value.strip()] if environments else [environment]
    # Normal packages keep their established JSON layout. The explicit raw
    # Python archive is compiled on a separate path in build_deployment_archive.
    try:
        body, filename, media, _ = build_deployment_archive(item, target, selected_environments, selected_starters, archive, selected_artifacts)
    except Exception as error:
        raise _package_failure(item, selected_environments, error) from error
    return StreamingResponse(io.BytesIO(body), media_type=media, headers={'Content-Disposition': f'attachment; filename="{filename}"'})

@app.post('/api/projects/{project_id}/package/deploy')
async def package_and_deploy_project(project_id: str, payload: ControlPlaneDeployRequest):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    environments = payload.environments or [payload.deploymentEnvironment]
    if payload.deploymentEnvironment not in environments:
        raise HTTPException(400, 'Deployment environment must be one of the packaged environment profiles')
    artifacts = set(payload.artifacts) if payload.artifacts else None
    # Archive creation can include many tasks, resources, schemas, and
    # environment profiles. Keep CPU/file work off the async API loop so the
    # Studio remains responsive while the package is assembled.
    try:
        body, filename, media, _ = await asyncio.to_thread(
            build_deployment_archive, item, payload.target, environments,
            payload.starterTaskIds or None, payload.archive, artifacts,
        )
    except Exception as error:
        raise _package_failure(item, environments, error) from error
    base_url, headers, verify = _control_plane_client_options(payload)
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(180.0, connect=10.0), verify=verify, follow_redirects=False) as client:
            upload = await client.post(f'{base_url}/api/packages', params={'teamId': payload.teamId} if payload.teamId else None,
                                       headers=headers, files={'file': (filename, body, media)})
            upload.raise_for_status()
            package_record = upload.json()
            deployment_payload = {
                'packageId': package_record['packageId'], 'teamId': payload.teamId,
                'environment': payload.deploymentEnvironment, 'machine': payload.dataPlaneId,
                'dataPlaneId': payload.dataPlaneId, 'capabilityId': payload.capabilityId,
                'namespace': payload.namespace, 'instances': payload.instances, 'secrets': payload.secrets,
            }
            deployed = await client.post(f'{base_url}/api/deployments', headers={**headers, 'content-type': 'application/json'}, json=deployment_payload)
            deployed.raise_for_status()
            deployment = deployed.json()
            # Kubernetes deployments are reconciled by the selected data-plane
            # agent as soon as the desired deployment is created. The lifecycle
            # start endpoint is reserved for the local command runtime adapter.
            if payload.start and payload.target == 'on-prem' and payload.dataPlaneId == 'localhost':
                started = await client.post(f'{base_url}/api/deployments/{deployment["id"]}/start', headers=headers)
                started.raise_for_status()
                deployment = started.json()
        return {'package': package_record, 'deployment': deployment, 'archiveName': filename,
                'started': payload.start and payload.target == 'on-prem' and payload.dataPlaneId == 'localhost',
                'submittedToDataPlane': payload.target == 'cloud'}
    except httpx.HTTPStatusError as exc:
        try: detail = exc.response.json().get('detail')
        except Exception: detail = exc.response.text[:500]
        raise HTTPException(502, f'Control Plane rejected the deployment: {detail or exc.response.reason_phrase}') from exc
    except httpx.RequestError as exc:
        raise HTTPException(502, f'Unable to reach Control Plane at {base_url}: {exc}') from exc

@app.post('/api/projects/import', response_model=Project)
async def import_project(file: UploadFile = File(...)):
    raw = await file.read(MAX_IMPORT_BYTES + 1)
    try:
        item = Project.model_validate_json(project_payload(raw))
        return await asyncio.to_thread(save_project, item)
    except Exception as exc: raise HTTPException(400, f'Invalid MINA project: {exc}')

@app.post('/api/connections/test')
async def test_connection(resource: SharedResource):
    cfg = resource.config
    if cfg.get('mode') == 'memory': return {'ok': True, 'message': 'Local in-memory broker is ready'}
    if resource.type == 'jdbc':
        try: return await __import__('asyncio').to_thread(jdbc_adapter.test, cfg)
        except Exception as exc: return {'ok':False,'message':str(exc)}
    if resource.type == 'snowflake':
        try: return await __import__('asyncio').to_thread(snowflake_adapter.test, cfg)
        except Exception as exc: return {'ok':False,'message':str(exc)}
    if resource.type == 'amqp':
        try:
            timeout = min(60.0, max(3.0, float(cfg.get('connectionTimeoutMsec') or 30000) / 1000 + 1))
            return await asyncio.wait_for(asyncio.to_thread(amqp_adapter.test, cfg), timeout=timeout)
        except asyncio.TimeoutError: return {'ok':False,'message':'AMQP connection test timed out. Verify the endpoint, port, TLS, and firewall settings.'}
        except Exception as exc: return {'ok':False,'message':str(exc)}
    if resource.type == 'sap_tid' and cfg.get('mode','none') == 'none': return {'ok':True,'message':'SAP TID duplicate management is disabled'}
    if resource.type == 'sap_tid' and cfg.get('driver','sqlite') == 'sqlite':
        import sqlite3
        conn = sqlite3.connect(cfg.get('url','sap-tid.db')); conn.execute('CREATE TABLE IF NOT EXISTS sap_tid (tid TEXT PRIMARY KEY, state TEXT, updated_at TEXT)'); conn.close(); return {'ok':True,'message':'SAP TID Manager database is ready'}
    if resource.type == 'http':
        from .http_transport import request as send_http, tls_context, boolean
        from .http_server import listener_config, server_tls
        try:
            if cfg.get('connectorMode', 'both') in ('server','both'):
                settings=listener_config(cfg,{})
                if server_tls(settings):tls_context(settings,server=True)
                return {'ok':True,'message':f'HTTP server configuration validated for {settings.get("host", "localhost")}:{settings.get("port",8080)}; authentication is enforced per request'}
            output=await asyncio.to_thread(send_http,{'method':'GET','url':cfg.get('baseUrl') or cfg.get('url') or '/','raiseForStatus':False},cfg)
            return {'ok':output['statusCode']<500,'message':f'HTTP endpoint returned {output["statusCode"]}'}
        except Exception as error:return {'ok':False,'message':str(error)}
    if resource.type == 'sap':
        try: return await __import__('asyncio').to_thread(sap_adapter.test, cfg)
        except Exception as exc: return {'ok':False,'message':str(exc)}
    if resource.type in ('ems', 'jms'):
        try:
            required = {'JMS connection URL':cfg.get('serverUrl'), 'Username':cfg.get('username'), 'Password':cfg.get('password')}
            is_jndi = str(cfg.get('connectionFactoryType', 'Direct')).lower() == 'jndi'
            if is_jndi:
                required.update({'JNDI context factory':cfg.get('jndiContextFactory'), 'JNDI provider URL':cfg.get('jndiProviderUrl'), 'JNDI username':cfg.get('jndiUsername'), 'JNDI password':cfg.get('jndiPassword'), 'JNDI connection factory':cfg.get('connectionFactory')})
            missing = [name for name, value in required.items() if not str(value or '').strip()]
            if missing: return {'ok':False,'message':f"Required connection values are missing: {', '.join(missing)}"}
            output = await asyncio.to_thread(test_jms, cfg)
            output['message'] = f'{resource.type.upper()} native JMS connection succeeded'
            return output
        except JavaBridgeError as exc: return {'ok':False,'message':f'{resource.type.upper()} connection failed: {exc}'}
        except Exception as exc: return {'ok':False,'message':f'{resource.type.upper()} connection failed: {exc}'}
    if resource.type == 'kafka':
        try:
            from confluent_kafka.admin import AdminClient
            if not str(cfg.get('bootstrapServers') or '').strip(): return {'ok':False,'message':'Kafka bootstrap servers are required'}
            settings = {'bootstrap.servers':cfg['bootstrapServers'], 'client.id':cfg.get('clientId') or f'mina-{uuid4()}'}
            if cfg.get('securityProtocol'): settings['security.protocol'] = cfg['securityProtocol']
            sasl_mechanism = cfg.get('saslMechanism') or ('PLAIN' if str(cfg.get('authenticationType') or '').strip().lower() == 'api key / secret' else '')
            if sasl_mechanism: settings['sasl.mechanism'] = sasl_mechanism
            if cfg.get('username'): settings['sasl.username'] = cfg['username']
            if cfg.get('password'): settings['sasl.password'] = cfg['password']
            metadata = await __import__('asyncio').to_thread(AdminClient(settings).list_topics, None, float(cfg.get('requestTimeoutMilliseconds',30000))/1000)
            return {'ok':True,'message':f'Kafka connection succeeded; {len(metadata.brokers)} broker(s) and {len(metadata.topics)} topic(s) discovered'}
        except ImportError: return {'ok':False,'message':'External Kafka testing requires confluent-kafka'}
        except Exception as exc: return {'ok':False,'message':f'Kafka connection failed: {exc}'}
    if resource.type == 'pubsub':
        try:
            from google.cloud import pubsub_v1
            def test_pubsub():
                kwargs, project_id = pubsub_client_configuration(cfg)
                publisher = create_pubsub_client(pubsub_v1.PublisherClient, cfg)
                try:
                    timeout_seconds = max(1.0, float(cfg.get('connectionTimeoutSeconds') or 30))
                    # A list_topics iterator can wait for a second page or an
                    # IAM response after the underlying channel is usable. A
                    # connection test should first verify the actual gRPC
                    # channel with a hard deadline and avoid false timeouts.
                    channel = getattr(getattr(publisher, 'transport', None), '_grpc_channel', None)
                    if channel is not None:
                        try:
                            import grpc
                            ready_future = getattr(channel, 'channel_ready_future', None)
                            if callable(ready_future):
                                ready_future().result(timeout=timeout_seconds)
                            else:
                                grpc.channel_ready_future(channel).result(timeout=timeout_seconds)
                        except Exception as exc:
                            if exc.__class__.__name__ in ('FutureTimeoutError', 'TimeoutError'):
                                raise TimeoutError(f'Pub/Sub gRPC channel was not ready within {timeout_seconds:g} seconds') from exc
                            raise
                    else:
                        # Compatibility fallback for older client releases.
                        iterator = publisher.list_topics(request={'project':f"projects/{project_id}", 'page_size':1}, timeout=timeout_seconds)
                        next(iter(iterator), None)
                finally: publisher.transport.close()
                return pubsub_credential_summary(cfg)
            timeout = min(60.0, max(3.0, float(cfg.get('connectionTimeoutSeconds') or 30)))
            identity = await asyncio.wait_for(asyncio.to_thread(test_pubsub), timeout=timeout + 1)
            principal = f" as {identity['clientEmail']}" if identity.get('clientEmail') else ''
            return {'ok':True,'message':f"Google Pub/Sub connection succeeded for project {identity['projectId']}{principal}"}
        except asyncio.TimeoutError: return {'ok':False,'message':'Google Pub/Sub connection test timed out. Verify credentials, endpoint, proxy, and firewall settings.'}
        except ImportError: return {'ok':False,'message':'External Google Pub/Sub testing requires google-cloud-pubsub'}
        except Exception as exc: return {'ok':False,'message':f'Google Pub/Sub connection failed: {exc}'}
    host = cfg.get('host') or cfg.get('bootstrapServers','').split(',')[0].split(':')[0] or cfg.get('emulatorHost','').split(':')[0]
    port = cfg.get('port') or (cfg.get('bootstrapServers','').split(',')[0].split(':')[1] if ':' in cfg.get('bootstrapServers','') else None) or (cfg.get('emulatorHost','').split(':')[1] if ':' in cfg.get('emulatorHost','') else None)
    if host and port:
        await __import__('asyncio').to_thread(lambda: socket.create_connection((host, int(port)), timeout=float(cfg.get('timeout',5))).close())
        return {'ok':True,'message':f'Connected to {host}:{port}'}
    return {'ok':False,'message':'Save the required host/URL fields before testing'}

@app.post('/api/sap/idocs')
def sap_idocs(payload: dict):
    try:
        resource = SharedResource.model_validate(payload.get('resource') or {})
        if resource.type != 'sap': raise ValueError('An SAP ECC shared connection is required')
        idoc_type = str(payload.get('idocType') or '').strip()
        if idoc_type:
            return {'idoc': sap_adapter.idoc_metadata(resource.config, idoc_type, str(payload.get('extensionType') or ''), str(payload.get('release') or ''))}
        return {'idocs': sap_adapter.list_idocs(resource.config, str(payload.get('search') or ''), int(payload.get('limit', 250)))}
    except Exception as exc: raise HTTPException(400, f'Unable to fetch SAP IDoc metadata: {exc}')

@app.post('/api/snowflake/entities')
async def snowflake_entities(payload: dict):
    try:
        resource = SharedResource.model_validate(payload.get('resource') or {})
        if resource.type != 'snowflake': raise ValueError('A Snowflake JDBC shared connection is required')
        entity = str(payload.get('entity') or '').strip()
        if entity:
            metadata = await __import__('asyncio').to_thread(snowflake_adapter.entity_metadata, resource.config, str(payload.get('database') or resource.config.get('database') or ''), str(payload.get('schema') or resource.config.get('schema') or 'PUBLIC'), entity)
            return {'entity': metadata}
        entities = await __import__('asyncio').to_thread(snowflake_adapter.list_entities, resource.config, str(payload.get('database') or ''), str(payload.get('schema') or ''), str(payload.get('pattern') or ''))
        return {'entities': entities}
    except Exception as exc: raise HTTPException(400, f'Unable to retrieve Snowflake metadata: {exc}')

@app.post('/api/jdbc/metadata')
async def jdbc_metadata(payload: dict):
    try:
        resource = SharedResource.model_validate(payload.get('resource') or {})
        if resource.type != 'jdbc': raise ValueError('A JDBC shared connection is required')
        return await __import__('asyncio').to_thread(jdbc_adapter.metadata, resource.config)
    except Exception as exc: raise HTTPException(400, f'Unable to retrieve JDBC metadata: {exc}')

@app.post('/api/jdbc/test-query')
async def jdbc_test_query(payload: dict):
    try:
        resource = SharedResource.model_validate(payload.get('resource') or {})
        if resource.type != 'jdbc': raise ValueError('A JDBC shared connection is required')
        config = dict(payload.get('config') or {}); config['operation'] = payload.get('operation') or config.get('operation') or 'query'
        return await __import__('asyncio').to_thread(jdbc_adapter.execute, resource.config, config)
    except Exception as exc: raise HTTPException(400, f'JDBC test failed: {exc}')

@app.post('/api/mapper/suggest')
def mapper_suggest(payload: dict):
    return {'recommendations': recommend(payload.get('sourceSchema',{}), payload.get('targetSchema',{}), float(payload.get('threshold',70))/100, payload.get('weights'))}

@app.post('/api/mapper/test')
def mapper_test(payload: dict):
    try:
        mappings = payload.get('mappings', []) or []
        def test_path(value: str) -> str:
            path = value[2:-1] if value.startswith('${') and value.endswith('}') else value
            if path.startswith('activities.') and '.output.' in path:
                return path.split('.output.', 1)[1]
            if path.endswith('.output') and path.startswith('activities.'):
                return ''
            if path.startswith('input.'):
                return path[6:]
            if path.startswith('last.'):
                return path[5:]
            # Studio activity-name expressions omit the internal activity ID
            # and output envelope: ${IDoc-Parser.IDOC.EDI_DC40.DOCNUM}.
            if '.' in path and not path.startswith(('properties.', 'vars.', 'context.', 'tasks.')):
                return path.split('.', 1)[1]
            return '' if path in ('input', 'last') else path
        normalized = []
        for mapping in mappings:
            rule = dict(mapping)
            for key in ('source', 'select', 'otherwise'):
                value = rule.get(key)
                if not isinstance(value, str):
                    continue
                rule[key] = rewrite_references(value, test_path)
            if isinstance(rule.get('condition'), str):
                rule['condition'] = rewrite_references(rule['condition'], test_path)
            if isinstance(rule.get('whens'), list):
                rule['whens'] = [{
                    **branch,
                    'condition': rewrite_references(str(branch.get('condition') or ''), test_path),
                    'source': rewrite_references(branch['source'], test_path) if isinstance(branch.get('source'), str) else branch.get('source'),
                } for branch in rule['whens']]
            normalized.append(rule)
        options = {**(payload.get('options') or {}), 'validateOutput': False}
        if payload.get('targetSchema'): options = {**options, 'targetSchema': payload.get('targetSchema')}
        if payload.get('targetSchemaText'): options = {**options, 'targetSchemaText': payload.get('targetSchemaText')}
        # Mapper expressions use the same aliases as the runtime.  In
        # particular, the function palette creates expressions such as
        # ``render-xml(${last})``.  The test endpoint previously passed the
        # sample document directly, so ``last`` was missing and render-xml
        # received None, resulting in ``<root />`` even though the function
        # was otherwise working correctly.
        test_input = payload.get('input', {})
        test_document = {
            **(test_input if isinstance(test_input, dict) else {}),
            'last': test_input,
            'input': test_input,
        }
        output = execute_mapping(test_document, normalized, options)
        schema = payload.get('targetSchema') or payload.get('targetSchemaText')
        errors = validate_output(output, schema) if schema and (payload.get('options') or {}).get('validateOutput', True) else []
        active = [rule for rule in normalized if rule.get('enabled', True)]
        mapped_targets = sorted({str(rule.get('target')) for rule in active if rule.get('target')})
        # Preserve the runtime value and return a separate readable preview.
        output_format = 'json'
        output_text = json.dumps(output, indent=2, ensure_ascii=False)
        if isinstance(output, str):
            output_text = output
            output_format = 'xml' if output.lstrip().startswith('<') else 'text'
        elif isinstance(schema, str) and '<' in schema and 'schema' in schema:
            from .mapper import _render_xml
            from xml.etree import ElementTree as ET
            contract = ET.fromstring(schema)
            declarations = [element for element in contract if element.tag.rsplit('}', 1)[-1] == 'element']
            root_name = declarations[0].get('name', 'root') if declarations else 'root'
            value = output.get(root_name, output) if isinstance(output, dict) else output
            rendered = ET.fromstring(_render_xml(value, root_name))
            namespace = contract.get('targetNamespace')
            if namespace:
                rendered.tag = '{' + namespace + '}' + rendered.tag
                if contract.get('elementFormDefault') == 'qualified':
                    for element in list(rendered.iter())[1:]:
                        element.tag = '{' + namespace + '}' + element.tag
                ET.register_namespace('', namespace)
            ET.indent(rendered, space='  ')
            output_text = ET.tostring(rendered, encoding='unicode')
            output_format = 'xml'
        return {'output': output, 'outputText': output_text, 'outputFormat': output_format, 'valid': not errors, 'validationErrors': errors, 'mappingCount': len(active), 'mappedTargets': mapped_targets, 'diagnostics': {'mappedTargetCount': len(mapped_targets), 'loopCount': len([rule for rule in active if rule.get('operator') in ('for-each', 'for-each-group')]), 'conditionalCount': len([rule for rule in active if rule.get('operator') in ('if', 'when-otherwise', 'choose')])}}
    except Exception as exc: raise HTTPException(400, f'Mapping failed: {exc}')

@app.post('/api/mapper/suite')
def mapper_suite(payload: dict):
    from .transformation import run_cases
    try: return run_cases(payload.get('config') or {}, payload.get('cases'))
    except (ValueError, TypeError, KeyError) as error: raise HTTPException(400, str(error))


@app.post('/api/mapper/schema-impact')
def mapper_schema_impact(payload: dict):
    from .transformation import schema_impact
    try: return schema_impact(payload.get('previous'), payload.get('current'), payload.get('mappings'))
    except (ValueError, TypeError, KeyError) as error: raise HTTPException(400, str(error))


@app.post('/api/mapper/template')
def mapper_template(payload: dict):
    from .transformation import template, read_template
    try:
        if payload.get('asset'): return {'config': read_template(payload['asset']), 'name': payload['asset']['name'], 'version': payload['asset']['version']}
        return template(payload.get('config') or {}, payload.get('name'), payload.get('version'))
    except (ValueError, TypeError, KeyError) as error: raise HTTPException(400, str(error))


@app.post('/api/dataweave/test')
def dataweave_test(payload: dict):
    try:
        return execute_dataweave(
            str(payload.get('script') or ''), payload=payload.get('input'),
            attributes=payload.get('attributes') or {}, variables=payload.get('variables') or {},
            input_mime_type=str(payload.get('inputMimeType') or ''),
        )
    except DataWeaveError as exc:
        raise HTTPException(400, f'DataWeave validation failed: {exc}')

@app.post('/api/dataweave/generate')
def dataweave_generate(payload: dict):
    """Generate a reviewable starter script from mapper recommendations."""
    source, target = payload.get('sourceSchema') or {}, payload.get('targetSchema') or {}
    recommendations = recommend(source, target, float(payload.get('threshold', 70)) / 100, payload.get('weights'))
    tree: dict = {}
    for item in recommendations:
        target_path, source_path = str(item.get('target') or ''), str(item.get('selected') or '')
        if not target_path or not source_path: continue
        current = tree
        for part in target_path.split('.'): current = current.setdefault(part, {})
        current['__mapping__'] = item
    def key(value: str): return value if re.fullmatch(r'[A-Za-z_$][\w$-]*', value) else json.dumps(value)
    def selector(base: str, path: str):
        value = base
        for part in path.split('.') if path else []:
            value += f'.{part}' if re.fullmatch(r'[A-Za-z_$][\w$-]*', part) else f'[{json.dumps(part)}]'
        return value
    def render(nodes: dict, indent=0, source_repeat='', target_prefix=''):
        lines = []
        for name, child in nodes.items():
            if name == '__mapping__': continue
            target_path = f'{target_prefix}.{name}'.strip('.')
            mapping = child.get('__mapping__')
            children = {item_name:item for item_name,item in child.items() if item_name != '__mapping__'}
            if children:
                repeated = next((item for item in recommendations if item.get('targetRepeatPath') == target_path and item.get('selected')), None)
                if repeated and repeated.get('sourceRepeatPath'):
                    nested = render(children, indent + 2, str(repeated['sourceRepeatPath']), target_path)
                    value = f"{selector('payload', str(repeated['sourceRepeatPath']))} map (item) -> {{\n{nested}\n{' ' * (indent + 2)}}}"
                else: value = "{\n" + render(children, indent + 2, source_repeat, target_path) + "\n" + ' ' * (indent + 2) + "}"
            elif mapping:
                selected = str(mapping.get('selected') or '')
                relative = selected[len(source_repeat):].lstrip('.') if source_repeat and selected.startswith(source_repeat) else ''
                value = selector('item', relative) if relative else selector('payload', selected)
            else: value = 'null'
            lines.append(' ' * (indent + 2) + f'{key(name)}: {value}')
        return ',\n'.join(lines)
    body = '{\n' + (render(tree) if tree else '  result: payload') + '\n}'
    return {
        'script': '%dw 2.0\noutput application/json\n---\n' + body,
        'recommendations': recommendations,
        'reviewRequired': True,
    }

@app.post('/api/conditions/evaluate')
def evaluate_condition(payload: dict):
    expression, supplied = str(payload.get('expression','')), payload.get('context') or {}
    context = {
        'last': supplied.get('last', {}), 'input': supplied.get('input', {}),
        'properties': supplied.get('properties', {}), 'vars': supplied.get('vars', {}),
    }
    try: return {'result': bool(runtime.condition(expression, context)), 'expression': expression}
    except Exception as exc: raise HTTPException(400, f'Condition evaluation failed: {exc}')

@app.post('/api/projects/{project_id}/debug')
async def start_debug(project_id: str, http_request: Request, request: DebugRequest):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    task_id = request.task_id or item.active_task_id
    properties = {prop.key: prop.value for prop in item.properties.get(request.environment, [])}
    try:
        view = debugger.start(item, task_id, request.input, {resource.id:resource for resource in item.resources}, properties, request.breakpoints, request.environment, request.breakpoint_conditions, request.watches, request.pause_on_error)
        if request.test_mode:
            test_state = debugger.sessions[view['sessionId']]
            test_state.update(listenerMode=False, status='paused', pauseReason='activity-testing')
            test_state['logs'] = [entry for entry in test_state['logs'] if entry.get('kind') != 'listener']
            test_state['frames'][-1]['context']['logs'] = test_state['logs']
        task = next(value for value in item.tasks if value.id == task_id)
        diagnostics = _startup_diagnostics(item, task, {resource.id: resource for resource in item.resources}, properties, request.environment, 'DEBUG')
        endpoints = _listener_endpoints(item, task, request.environment, str(http_request.base_url).rstrip('/'))
        events = effective_event_activities(task.activities, task.transitions)
        event = events[0] if len(events) == 1 else None
        if event and _is_continuous_event(event) and not request.test_mode:
            endpoints = [_event_subscription(item, task, event, request.environment)]
        state = debugger.sessions[view['sessionId']]
        runtime_states.setdefault(project_id, {})['environment'] = request.environment
        state['endpoints'] = endpoints
        state['logs'][:] = diagnostics + _lifecycle_logs(item, endpoints) + state['logs']
        append_project_logs(project_id, item.name, state['logs'], _project_log_directory(item, request.environment))
        state['persistedLogCount'] = len(state['logs'])
        if event and _is_continuous_event(event) and not request.test_mode:
            _start_continuous_listener(item, task, event, request.environment, view['sessionId'])
        elif not request.breakpoints and not request.test_mode:
            # Run without breakpoints in the background. This lets the Studio
            # poll the debug session and paint each activity/parallel branch
            # while it executes instead of receiving only the final snapshot.
            session_id = view['sessionId']
            state['status'] = 'running'

            async def finish_debug_session():
                try:
                    await debugger.action(session_id, 'continue')
                finally:
                    current = debugger.sessions.get(session_id)
                    if current:
                        cursor = int(current.get('persistedLogCount', 0))
                        append_project_logs(current['project'].id, current['project'].name, current['logs'][cursor:], _project_log_directory(current['project'], current.get('environment', 'local')))
                        current['persistedLogCount'] = len(current['logs'])
                    debug_runs.pop(session_id, None)

            debug_runs[session_id] = asyncio.create_task(finish_debug_session())
        return debugger.view(state)
    except ValueError as exc: raise HTTPException(400, str(exc))

@app.post('/api/debug/{session_id}/action')
async def debug_action(session_id: str, request: DebugAction):
    try:
        if request.action == 'stop':
            return await _stop_debug_session(session_id)
        view = await debugger.action(session_id, request.action, request.model_dump(exclude={'action'}, exclude_unset=True))
        state = debugger.sessions[session_id]
        project = state['project']
        pending = state.get('pendingSapDelivery')
        if pending and state.get('status') in ('listening', 'failed', 'stopped'):
            if not pending.get('transport', {}).get('completed'):
                sap_adapter.acknowledge_idoc(pending['listenerKey'], pending['deliveryId'], state.get('status') == 'listening')
            state.pop('pendingSapDelivery', None)
        cursor = int(state.get('persistedLogCount', 0))
        append_project_logs(project.id, project.name, state['logs'][cursor:], _project_log_directory(project, state.get('environment', 'local')))
        state['persistedLogCount'] = len(state['logs'])
        return view
    except ValueError as exc: raise HTTPException(404 if str(exc) == 'Debug session not found' else 400, str(exc))

@app.get('/api/debug/{session_id}')
def debug_state(session_id: str):
    state = debugger.sessions.get(session_id)
    if not state: raise HTTPException(404, 'Debug session not found')
    return debugger.view(state)

HTTP_LISTENER_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'TRACE', 'CONNECT']

def _configured_http_methods(activity) -> set[str]:
    configured = activity.config.get('methods', activity.config.get('method', ''))
    if isinstance(configured, list):
        values = configured
    else:
        values = str(configured).split(',')
    return {str(value).strip().upper() for value in values if str(value).strip()}

@app.api_route('/api/listeners/{project_id}/{listener_path:path}', methods=HTTP_LISTENER_METHODS)
async def invoke_listener(project_id: str, listener_path: str, request: Request, environment: str = 'local'):
    item = get_project(project_id)
    if not item: raise HTTPException(404, 'Project not found')
    request_path = '/' + listener_path
    starter_tasks = [task for task in item.tasks if task.kind == 'starter']
    candidates = [(task, activity) for task in starter_tasks for activity in task.activities if activity.type in ('http_listener', 'rest', 'soap') and activity.config.get('operation') in (None, 'listen', 'receiver', 'service')]
    properties=_environment_values(item,environment)
    def configured_path(activity):
        from .http_server import listener_config
        connection=_resolved_resource_config(item,activity,properties)
        configured=runtime.resolve(activity.config,{'properties':properties,'input':{},'last':{},'vars':{},'context':{}})
        return listener_config(connection,configured)['path']
    def match_path(template: str):
        from .http_server import route_pattern
        pattern,names=route_pattern(str(template))
        match=pattern.match(request_path)
        return dict(zip(names,match.groups())) if match else None
    matched = next(((task, activity, match_path(configured_path(activity))) for task, activity in candidates if match_path(configured_path(activity)) is not None and (request.method.upper() in _configured_http_methods(activity) or (activity.type == 'soap' and request.method == 'GET' and 'wsdl' in request.query_params))), None)
    task, listener, path_parameters = matched if matched else (None, None, {})
    if not listener: raise HTTPException(404, f'No listener configured for {request.method} {request_path}')
    properties = {prop.key: prop.value for prop in item.properties.get(environment, [])}
    listener_cfg = _resolved_resource_config(item, listener, properties)
    from .http_transport import HTTPFault, authorize, number, boolean
    listener_cfg = {**listener_cfg, '_httpScope':item.id, **runtime.resolve(listener.config, {'properties': properties, 'input': {}, 'last': {}, 'vars': {}, 'context': {}})}
    if listener.type != 'soap':
        from .http_server import ListenerApp, listener_config
        try:cfg=listener_config(listener_cfg,runtime.resolve(listener.config,{'properties':properties,'input':{},'last':{},'vars':{},'context':{}}))
        except HTTPFault as error:return JSONResponse({'detail':str(error)},status_code=error.status)
        async def handle_preview(metadata,payload):
            resources={resource.id:resource for resource in item.resources}
            result=await runtime.run(task,payload,resources,properties,listener.id,item)
            append_project_logs(project_id,item.name,result.logs,_project_log_directory(item,environment))
            combined_logs=list(runtime_states.get(project_id,{}).get('logs',[]))+result.logs
            _publish_runtime_state(project_id,status='listening' if result.status=='completed' else 'failed',logs=combined_logs[-500:],result=result,environment=environment)
            if result.status!='completed':raise RuntimeError('Integration execution failed')
            return result.output
        preview=ListenerApp([(None,cfg)],handle_preview,cfg,warm_workers=False)
        scope={**request.scope,'path':request_path,'raw_path':request_path.encode()}
        messages=[]
        async def collect(message):messages.append(message)
        try:await preview(scope,request.receive,collect)
        finally:preview.executor.shutdown(wait=False,cancel_futures=True)
        start=next(message for message in messages if message['type']=='http.response.start')
        body=b''.join(message.get('body',b'') for message in messages if message['type']=='http.response.body')
        return Response(body,status_code=start['status'],headers={key.decode('latin1'):value.decode('latin1') for key,value in start['headers']})
    raw_chunks=[];raw_size=0
    async for chunk in request.stream():
        raw_size+=len(chunk)
        if raw_size>number(listener_cfg,'maxRequestBodyBytes',64*1024**2,1):return JSONResponse({'detail':'HTTP request body limit exceeded'},status_code=413)
        raw_chunks.append(chunk)
    raw=b''.join(raw_chunks)
    try:
        claims=await asyncio.to_thread(authorize,listener_cfg,request.method,request_path+('?' + request.url.query if request.url.query else ''),dict(request.headers),raw,False)
    except HTTPFault as error:
        return JSONResponse({'detail':str(error)},status_code=error.status,headers={'WWW-Authenticate':'Basic realm="MINA"' if str(listener_cfg.get('authentication')).lower() in ('basic','ldap') else 'Bearer'})
    if listener.type == 'soap' and request.method == 'GET' and 'wsdl' in request.query_params:
        wsdl = listener.config.get('wsdlContent', '')
        wsdl_path = listener.config.get('wsdl', '')
        if not wsdl and wsdl_path and Path(wsdl_path).is_file(): wsdl = Path(wsdl_path).read_text()
        if not wsdl: raise HTTPException(404, 'WSDL is not configured for this SOAP service')
        return Response(wsdl, media_type='text/xml')
    try: body = json.loads(raw) if raw else None
    except (ValueError, UnicodeDecodeError): body = raw.decode(errors='replace')
    payload = {'body': body, 'method': request.method, 'path': request_path, 'query': dict(request.query_params), 'headers': dict(request.headers), 'pathParameters': path_parameters, 'auth': claims}
    resources = {resource.id: resource for resource in item.resources}
    result = await runtime.run(task, payload, resources, properties, listener.id, item)
    deployment = runtime_states.get(project_id, {})
    combined_logs = list(deployment.get('logs', [])) + result.logs
    append_project_logs(project_id, item.name, result.logs, _project_log_directory(item, environment))
    _publish_runtime_state(project_id, status='listening' if result.status == 'completed' else 'failed', logs=combined_logs[-500:], result=result, environment=environment)
    if result.status == 'failed': return JSONResponse({'status': result.status, 'logs': result.logs}, status_code=500)
    output = result.output
    if output.get('__httpResponse'):
        body = output.get('body'); headers = output.get('headers', {}); status = output.get('statusCode', 200)
        return JSONResponse(body, status_code=status, headers=headers) if isinstance(body, (dict, list)) else Response(str(body or ''), status_code=status, headers=headers)
    return JSONResponse(output)

static_candidates = [
    Path(os.environ['MINA_STATIC_DIR']).expanduser() if os.environ.get('MINA_STATIC_DIR') else None,
    Path(getattr(sys, '_MEIPASS', '')) / 'frontend' / 'dist' if getattr(sys, '_MEIPASS', None) else None,
    Path(__file__).parents[2] / 'frontend' / 'dist',
]
static_dir = next((candidate for candidate in static_candidates if candidate and candidate.exists()), Path('__missing_frontend_dist__'))
if static_dir.exists(): app.mount('/', StaticFiles(directory=static_dir, html=True), name='studio')
