from __future__ import annotations
import ast, asyncio, base64, copy, csv, ftplib, gzip, hashlib, importlib.util, io, json, os, re, shlex, shutil, sqlite3, sys, tempfile, threading, traceback, uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
import httpx
from time import perf_counter
from concurrent.futures import ThreadPoolExecutor, Future as ConcurrentFuture
from .models import Activity, GroupDefinition, ProcessDefinition, Project, RunResult, find_subtask
from .mapper import INPUT_OCCURRENCES, activity_occurrence_rules, _function_arguments, apply_function, evaluate_condition, get_path, rewrite_references, validate_output, execute as execute_mapping, execute_async as execute_mapping_async
from .dataweave import DataWeaveError
from .transform_engine import execute_activity_async as execute_transform_activity
from .sap import sap_adapter
from .snowflake import snowflake_adapter
from .jdbc import jdbc_adapter
from .amqp import amqp_adapter
from .java_bridge import JavaBridgeError, execute_jms, close_jms_senders
from .mapping_literals import parse_literal
from .retry_policy import RetryPlan, outbound_activity
from .http_transport import request as http_request, merged as merge_http_config
from .message_state import operate as mediation_operation
from .google_pubsub import client_configuration as pubsub_client_configuration, create_client as create_pubsub_client, project_id as pubsub_project_id
from .time_utils import log_timestamp
from .data_formats import DataFormats
from .faults import MinaFault
from .flow_graph import parallel_plan, execute_parallel

class RuntimeErrorWithLogs(Exception): pass
_NO_EVENT_OUTPUT = object()

class WorkflowRuntime(DataFormats):
    def __init__(self):
        self.messages: dict[str, list[dict]] = {}
        self.acknowledgements: dict[str, dict] = {}
        self.shared_variables: dict[str, Any] = {}
        self.group_locks: dict[str, asyncio.Lock] = {}
        self._publisher_lock = threading.Lock()
        self._publishers: dict[str, object] = {}
        self._publisher_operation_locks: dict[str, threading.Lock] = {}
        self._initialized_transactional_publishers: set[str] = set()
        self._kafka_executor = None
        self._jms_executor = None
        self._jms_receivers_used = False
        self._jms_scope_id = uuid.uuid4().hex
        self._active_activity: dict[str, dict] = {}
        self._active_execution: dict[str, dict] = {}

    def active_activities(self, project_id: str) -> list[dict]:
        return [dict(activity) for activity in self._active_activity.values() if activity['projectId'] == project_id]

    def execution_snapshot(self, project_id: str) -> dict | None:
        executions = [value for value in self._active_execution.values() if value['projectId'] == project_id]
        if not executions: return None
        logs = [dict(entry) for execution in executions for entry in list(execution['logs'])[-1000:]]
        logs.sort(key=lambda entry: str(entry.get('time') or ''))
        return {'status':'running', 'logs':logs[-1000:],
                'activityOutputs':dict(executions[0]['activities']), 'taskOutputs':dict(executions[0]['tasks'])}

    def jms_application_scope(self, project_id: str) -> str:
        """Stable across jobs, isolated across applications and runtime instances."""
        return f'mina-run:{self._jms_scope_id}:{project_id}'

    def close_application_senders(self, project_id: str):
        from .http_transport import close_clients
        close_clients(project_id)
        if self._jms_executor is not None or self._jms_receivers_used:
            close_jms_senders(self.jms_application_scope(project_id), force=True)

    @staticmethod
    def _publisher_key(kind: str, config: dict) -> str:
        fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True, default=str).encode()).hexdigest()
        return f'{kind}:{fingerprint}'

    def _publisher(self, kind: str, config: dict, factory):
        """Reuse broker connections; never retain plaintext credentials in cache keys."""
        key = self._publisher_key(kind, config)
        with self._publisher_lock:
            client = self._publishers.get(key)
            if client is not None: return client, False
            # Unusual high-cardinality dynamic configurations do not grow the
            # process indefinitely; those extra clients remain one-shot.
            if len(self._publishers) >= 32: return factory(), True
            client = factory()
            self._publishers[key] = client
            return client, False

    def _publisher_operation_lock(self, kind: str, config: dict) -> tuple[str, threading.Lock]:
        key = self._publisher_key(kind, config)
        with self._publisher_lock:
            # Fixed stripes also serialize one-shot dynamic producers without
            # retaining every configuration fingerprint for the runtime lifetime.
            stripe = str(int(key.rsplit(':', 1)[1], 16) % 64)
            return key, self._publisher_operation_locks.setdefault(stripe, threading.Lock())

    def close_publishers(self):
        # Capability-pruned exports without JMS must not import its native bridge.
        if self._jms_executor is not None or self._jms_receivers_used:
            try: close_jms_senders(force=True)
            except Exception: pass  # Still release the independently owned clients.
        with self._publisher_lock:
            executor, self._kafka_executor = self._kafka_executor, None
            jms_executor, self._jms_executor = self._jms_executor, None
        if executor is not None:
            executor.shutdown(wait=True, cancel_futures=True)
        if jms_executor is not None:
            jms_executor.shutdown(wait=True, cancel_futures=True)
        with self._publisher_lock:
            clients = list(self._publishers.items())
            self._publishers.clear()
            self._publisher_operation_locks.clear()
            self._initialized_transactional_publishers.clear()
        for key, client in clients:
            try:
                if key.startswith('kafka:'): client.flush(3)
                else:
                    try: client.stop()
                    finally: client.transport.close()
            except Exception: pass

    async def _publish_kafka_isolated(self, publish):
        # Receivers/JCo/JDBC may occupy the default asyncio executor for seconds.
        # Keep short Kafka enqueue operations off that shared blocking-I/O queue.
        with self._publisher_lock:
            if self._kafka_executor is None:
                self._kafka_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix='mina-kafka')
            future = self._kafka_executor.submit(publish)
        return await asyncio.wrap_future(future)

    async def _publish_jms_isolated(self, config, destination, payload, options):
        """Keep sends off the shared executor occupied by blocking receivers.

        Bound concurrent JVM launches; preserve synchronous delivery confirmation
        and do not retry potentially delivered messages automatically.
        """
        queued = perf_counter()
        def publish():
            started = perf_counter()
            output = execute_jms(config, 'send', destination, payload, options)
            completed = perf_counter()
            return {**output, 'publishTiming': {
                'queueMs': round((started - queued) * 1000, 3),
                'bridgeMs': round((completed - started) * 1000, 3),
                'totalMs': round((completed - queued) * 1000, 3),
            }}
        with self._publisher_lock:
            if self._jms_executor is None:
                self._jms_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix='mina-jms-send')
            future = self._jms_executor.submit(publish)
        return await asyncio.wrap_future(future)

    def register_acknowledgement(self, technology: str, message_id: str, callback=None) -> str:
        ack_id = f'{technology}:{message_id}:{uuid.uuid4()}'
        self.acknowledgements[ack_id] = {'technology': technology, 'messageId': message_id, 'callback': callback, 'created': log_timestamp()}
        return ack_id

    async def confirm_messages(self, handles) -> dict:
        handles = handles if isinstance(handles, list) else [handles]
        confirmed, technologies = [], []
        for handle in [item for item in handles if item]:
            pending = self.acknowledgements.pop(str(handle), None)
            if not pending: raise RuntimeError(f'Acknowledgement handle {handle!r} was not found or was already confirmed')
            callback = pending.get('callback')
            if callback:
                result = callback()
                if asyncio.iscoroutine(result): await result
            confirmed.append(str(handle)); technologies.append(pending['technology'])
        return {'confirmed': True, 'count': len(confirmed), 'ackIds': confirmed, 'technologies': sorted(set(technologies))}

    def compile_groups(self, process: ProcessDefinition) -> dict[str, dict]:
        """Compile persisted group containers into executable graph boundaries."""
        groups = {group.id: group for group in process.groups}
        children = {group_id: [] for group_id in groups}
        for group in process.groups:
            if group.parent_group_id: children[group.parent_group_id].append(group.id)

        def descendants(group_id: str) -> set[str]:
            result = set(groups[group_id].member_activity_ids)
            for child_id in children[group_id]: result.update(descendants(child_id))
            return result

        plans: dict[str, dict] = {}
        for group in process.groups:
            config = group.config or {}
            if group.type == 'pick_first':
                raise MinaFault(f'Group {group.name}: Pick First is not runtime-qualified; concurrent branch cancellation and cleanup are not supported', fault_type='GROUP_UNSUPPORTED')
            if group.type in ('if', 'while') and not str(config.get('condition') or '').strip():
                raise MinaFault(f'Group {group.name} requires a boolean condition', fault_type='GROUP_VALIDATION')
            if group.type in ('iterate', 'for_each') and config.get('source') in (None, '') and config.get('collection') in (None, '') and not (group.type == 'for_each' and config.get('start') is not None and config.get('end') is not None):
                raise MinaFault(f'Group {group.name} requires a collection expression', fault_type='GROUP_VALIDATION')
            if group.type == 'repeat' and not str(config.get('condition') or '').strip() and config.get('count') is None and config.get('iterations') is None:
                raise MinaFault(f'Group {group.name} requires a Repeat Until True condition', fault_type='GROUP_VALIDATION')
            if group.type == 'repeat_on_error' and not str(config.get('stopCondition') or '').strip():
                raise MinaFault(f'Group {group.name} requires a Repeat-on-Error stop condition', fault_type='GROUP_VALIDATION')
            members = descendants(group.id)
            if not members: raise MinaFault(f'Group {group.name} is empty', fault_type='GROUP_VALIDATION')
            internal_incoming = {edge.target for edge in process.transitions if edge.source in members and edge.target in members}
            external_entries = {edge.target for edge in process.transitions if edge.source not in members and edge.target in members}
            entries = external_entries or (members - internal_incoming)
            exit_edges = [edge for edge in process.transitions if edge.source in members and edge.target not in members]
            for source_id in members:
                fanout = [edge for edge in process.transitions if edge.source == source_id and edge.target in members and edge.type == 'success']
                if len(fanout) > 1 and group.type != 'pick_first':
                    raise MinaFault(f'Group {group.name} contains a parallel fan-out; use separate top-level branches until grouped branch joining is qualified', fault_type='GROUP_UNSUPPORTED')
            exit_sources = {edge.source for edge in exit_edges}
            terminal = {activity.id for activity in process.activities if activity.id in members and not any(edge.source == activity.id and edge.target in members for edge in process.transitions)}
            exits = exit_sources or terminal
            if len(entries) != 1 and group.type != 'pick_first':
                raise MinaFault(f'Group {group.name} must have exactly one entry activity; found {len(entries)}', fault_type='GROUP_VALIDATION')
            if len(exits) != 1 and group.type != 'pick_first':
                raise MinaFault(f'Group {group.name} must have exactly one exit activity; found {len(exits)}', fault_type='GROUP_VALIDATION')
            plans[group.id] = {'group': group, 'members': members, 'entries': entries, 'entry': next(iter(entries)) if entries else None, 'exits': exits, 'exit': next(iter(exits)) if exits else None, 'exitEdges': exit_edges}
        return plans

    @staticmethod
    def _group_ancestors(group: GroupDefinition, plans: dict[str, dict]) -> list[str]:
        result, current = [], group
        while current:
            result.append(current.id)
            current = plans.get(current.parent_group_id, {}).get('group') if current.parent_group_id else None
        return list(reversed(result))

    @staticmethod
    def _set_group_variable(state: dict, ctx: dict, name: str, value) -> None:
        if not name: return
        previous = state.setdefault('previousVariables', {})
        if name not in previous: previous[name] = (name in ctx['vars'], ctx['vars'].get(name))
        ctx['vars'][name] = value

    @staticmethod
    def _restore_group_variables(state: dict, ctx: dict) -> None:
        for name, (existed, value) in state.get('previousVariables', {}).items():
            if existed: ctx['vars'][name] = value
            else: ctx['vars'].pop(name, None)

    @staticmethod
    def _publish_group_context(state: dict, group: GroupDefinition, ctx: dict, current_element=None) -> None:
        details = {'id': group.id, 'name': group.name, 'type': group.type, 'iteration': state.get('iteration', 0) + 1}
        if current_element is not None: details['currentElement'] = current_element
        ctx['context']['group'] = details

    async def _begin_group(self, plan: dict, ctx: dict) -> tuple[dict, bool]:
        # Keep condition expressions intact for the condition evaluator. Exact
        # value fields are resolved individually below.
        group, cfg = plan['group'], dict(plan['group'].config)
        state = {'id': group.id, 'iteration': 0, 'config': cfg}
        kind = group.type
        should_run = True
        if kind in ('if', 'while'):
            expression = str(cfg.get('condition') or '')
            if not expression: raise MinaFault(f'{group.name} requires a condition', fault_type='GROUP_VALIDATION')
            should_run = self.condition(expression, ctx)
            if kind == 'while':
                self._set_group_variable(state, ctx, str(cfg.get('indexVariable') or 'index'), 1)
                self._set_group_variable(state, ctx, 'currentIndex', 1)
        elif kind in ('for_each', 'iterate'):
            source_value = cfg.get('collection', cfg.get('source'))
            if kind == 'for_each' and source_value in (None, ''):
                start, end, increment = int(self.resolve(cfg.get('start', 1), ctx)), int(self.resolve(cfg.get('end', 1), ctx)), int(self.resolve(cfg.get('increment', 1), ctx) or 1)
                if increment == 0: raise MinaFault(f'{group.name} increment cannot be zero', fault_type='GROUP_VALIDATION')
                items = list(range(start, end + (1 if increment > 0 else -1), increment))
            else:
                source = self.resolve(source_value or [], ctx)
                items = list(source.values()) if isinstance(source, dict) else list(source or [])
            state['items'] = items; should_run = bool(items)
            if should_run:
                current_name = str(cfg.get('currentElementName') or cfg.get('itemVariable') or 'currentElement')
                self._set_group_variable(state, ctx, current_name, items[0])
                self._set_group_variable(state, ctx, 'currentElement', items[0])
                self._set_group_variable(state, ctx, str(cfg.get('indexVariable') or 'index'), 1)
                self._set_group_variable(state, ctx, 'currentIndex', 1)
                state['currentElementName'] = current_name
            if self.as_bool(cfg.get('accumulateOutput', False)):
                state['accumulatedOutput'] = []
                state['accumulatorVariable'] = str(cfg.get('accumulatorVariable') or f'{group.id}Results')
                ctx['vars'][state['accumulatorVariable']] = state['accumulatedOutput']
        elif kind == 'repeat':
            state['count'] = max(0, int(self.resolve(cfg.get('count', cfg.get('iterations', 1)), ctx) or 0)); should_run = True if cfg.get('condition') else state['count'] > 0
            self._set_group_variable(state, ctx, str(cfg.get('indexVariable') or 'index'), 1)
            self._set_group_variable(state, ctx, 'currentIndex', 1)
        elif kind == 'repeat_on_error':
            state['retriesRemaining'] = max(0, int(self.resolve(cfg.get('retryCount', cfg.get('retries', 3)), ctx) or 0))
            self._set_group_variable(state, ctx, str(cfg.get('indexVariable') or 'index'), 1)
            self._set_group_variable(state, ctx, 'currentIndex', 1)
        elif kind == 'critical_section':
            lock_name = str(self.resolve(cfg.get('lockName'), ctx) or f'{ctx.get("_process").id}:{group.id}')
            lock = self.group_locks.setdefault(lock_name, asyncio.Lock())
            await lock.acquire(); state['lock'] = lock; state['lockName'] = lock_name
        elif kind == 'transaction_jdbc':
            resource_id = str(self.resolve(cfg.get('resourceId'), ctx) or '')
            jdbc_members = [item for item in ctx.get('_process').activities if item.id in plan['members'] and item.type == 'jdbc']
            inferred = {str(self.resolve(item.config.get('resourceId'), ctx) or '') for item in jdbc_members} - {''}
            if not resource_id and len(inferred) == 1: resource_id = next(iter(inferred))
            if not resource_id or len(inferred - {resource_id}) > 0:
                raise MinaFault(f'{group.name} must use one JDBC shared connection', fault_type='JDBCTransactionException')
            resource = ctx['resources'].get(resource_id)
            if not resource or resource.type != 'jdbc': raise MinaFault(f'{group.name} requires a valid JDBC connection', fault_type='JDBCTransactionException')
            connection_config = self.resolve(resource.config, ctx)
            state['resourceId'] = resource_id
            state['connection'] = await asyncio.to_thread(jdbc_adapter.connect, connection_config)
            ctx.setdefault('jdbcTransactions', {})[resource_id] = state['connection']
        self._publish_group_context(state, group, ctx, state.get('items', [None])[0] if state.get('items') else None)
        self.log(ctx['logs'], 'DEBUG', f'Group entered: {group.name}', kind='group', groupId=group.id, groupType=group.type, iteration=0)
        return state, should_run

    async def _finish_group(self, state: dict, plan: dict, ctx: dict, success: bool) -> None:
        if plan['group'].type == 'transaction_jdbc':
            connection = state.get('connection')
            if connection:
                try: await asyncio.to_thread(connection.commit if success else connection.rollback)
                finally: await asyncio.to_thread(connection.close)
            ctx.setdefault('jdbcTransactions', {}).pop(state.get('resourceId'), None)
        if plan['group'].type == 'critical_section' and state.get('lock') and state['lock'].locked(): state['lock'].release()
        self._restore_group_variables(state, ctx)
        self.log(ctx['logs'], 'DEBUG', f'Group {"completed" if success else "failed"}: {plan["group"].name}', kind='group', groupId=plan['group'].id, groupType=plan['group'].type, iteration=state.get('iteration', 0))

    async def enter_group_boundaries(self, activity_id: str, ctx: dict, plans: dict[str, dict]) -> str | None:
        active = {state['id'] for state in ctx.setdefault('groupStack', [])}
        candidates = [plan for plan in plans.values() if activity_id in plan.get('entries', {plan.get('entry')}) and plan['group'].id not in active]
        candidates.sort(key=lambda plan: len(self._group_ancestors(plan['group'], plans)))
        for plan in candidates:
            if plan['group'].parent_group_id and plan['group'].parent_group_id not in {state['id'] for state in ctx['groupStack']}: continue
            state, should_run = await self._begin_group(plan, ctx)
            ctx['groupStack'].append(state)
            if not should_run:
                await self._finish_group(state, plan, ctx, True); ctx['groupStack'].pop()
                edges = plan['exitEdges']
                eligible = self.select_group_transitions(self.eligible_success_transitions(edges, ctx), ctx, plans)
                return eligible[0].target if eligible else None
        return activity_id

    async def leave_group_boundaries(self, source_id: str, target_id: str | None, ctx: dict, plans: dict[str, dict], success: bool = True) -> str | None:
        while ctx.get('groupStack'):
            state = ctx['groupStack'][-1]; plan = plans[state['id']]; group = plan['group']
            if target_id in plan['members']: break
            if success and (source_id == plan['exit'] or source_id in plan.get('exits', {plan.get('exit')})):
                cfg = state['config']; repeat = False
                if group.type in ('for_each', 'iterate') and 'accumulatedOutput' in state:
                    state['accumulatedOutput'].append(ctx.get('last'))
                    ctx['vars'][state['accumulatorVariable']] = list(state['accumulatedOutput'])
                if group.type == 'while': repeat = self.condition(str(cfg.get('condition') or ''), ctx)
                elif group.type == 'repeat': repeat = (not self.condition(str(cfg.get('condition')), ctx)) if cfg.get('condition') else state['iteration'] + 1 < state['count']
                elif group.type in ('for_each', 'iterate'):
                    repeat = state['iteration'] + 1 < len(state['items'])
                if repeat:
                    state['iteration'] += 1
                    if group.type in ('for_each', 'iterate'):
                        current_element = state['items'][state['iteration']]
                        self._set_group_variable(state, ctx, state.get('currentElementName') or str(cfg.get('itemVariable') or 'currentElement'), current_element)
                        self._set_group_variable(state, ctx, 'currentElement', current_element)
                    if group.type in ('for_each', 'iterate', 'repeat', 'while'):
                        self._set_group_variable(state, ctx, str(cfg.get('indexVariable') or 'index'), state['iteration'] + 1)
                        self._set_group_variable(state, ctx, 'currentIndex', state['iteration'] + 1)
                    maximum = max(1, int(self.resolve(cfg.get('maxIterations', 10000), ctx) or 10000))
                    if state['iteration'] >= maximum: raise MinaFault(f'{group.name} exceeded maxIterations={maximum}', fault_type='GROUP_ITERATION_LIMIT')
                    self._publish_group_context(state, group, ctx, state['items'][state['iteration']] if group.type in ('for_each', 'iterate') else None)
                    self.log(ctx['logs'], 'DEBUG', f'Group iteration: {group.name} #{state["iteration"] + 1}', kind='group', groupId=group.id, groupType=group.type, iteration=state['iteration'])
                    return plan['entry']
            await self._finish_group(state, plan, ctx, success); ctx['groupStack'].pop()
        return target_id

    async def retry_failed_group(self, ctx: dict, plans: dict[str, dict]) -> str | None:
        stack = ctx.get('groupStack', [])
        retry_index = next((index for index in range(len(stack) - 1, -1, -1) if plans[stack[index]['id']]['group'].type == 'repeat_on_error' and stack[index].get('retriesRemaining', 0) > 0), None)
        if retry_index is None: return None
        while len(stack) - 1 > retry_index:
            child = stack.pop(); await self._finish_group(child, plans[child['id']], ctx, False)
        state = stack[retry_index]; state['retriesRemaining'] -= 1; state['iteration'] += 1
        if state['config'].get('stopCondition') and self.condition(str(state['config']['stopCondition']), ctx): return None
        self._set_group_variable(state, ctx, str(state['config'].get('indexVariable') or 'index'), state['iteration'] + 1)
        self._set_group_variable(state, ctx, 'currentIndex', state['iteration'] + 1)
        group = plans[state['id']]['group']
        self._publish_group_context(state, group, ctx)
        for activity_id in plans[state['id']]['members']:
            ctx.get('activities', {}).pop(activity_id, None)
            task_id = ctx.get('context', {}).get('taskId')
            if task_id: ctx.get('tasks', {}).get(task_id, {}).get('activities', {}).pop(activity_id, None)
        delay = float(self.resolve(state['config'].get('retryIntervalSeconds', state['config'].get('retryDelaySeconds', 0)), ctx) or 0)
        self.log(ctx['logs'], 'WARN', f'Group retry: {plans[state["id"]]["group"].name}; {state["retriesRemaining"]} retries remain', kind='group', groupId=state['id'], iteration=state['iteration'])
        if delay: await asyncio.sleep(delay)
        return plans[state['id']]['entry']

    async def run(self, process: ProcessDefinition, initial: dict, resources=None, properties=None, entry_activity_id=None, project: Project | None=None, execution_state: dict | None=None, event_output: Any = _NO_EVENT_OUTPUT, transport: dict | None = None, jms_sender_scope: str | None = None, stop_activity_id=None, branch_context=None, branch_output=None) -> RunResult:
        run_id, logs = str(uuid.uuid4()), []
        started = datetime.now(timezone.utc)
        correlation_id = str(initial.get('correlationId') or initial.get('correlation_id') or run_id) if isinstance(initial, dict) else run_id
        if branch_context is not None: correlation_id = branch_context['context']['correlationId']
        execution_state = execution_state or {'activities': {}, 'tasks': {}}
        activity_outputs = execution_state.setdefault('activities', {})
        task_outputs = execution_state.setdefault('tasks', {})
        task_state = task_outputs.setdefault(process.id, {'name': process.name, 'activities': {}})
        context = {
            'input': initial, 'vars': {}, 'last': initial, 'resources': resources or {},
            'properties': properties or {}, 'project': project, 'runtime': self, 'logs': logs,
            'activities': activity_outputs, 'tasks': task_outputs,
            'context': {'taskId': process.id, 'activityId': '', 'environment': getattr(project, 'active_environment', '') if project else '', 'correlationId': correlation_id, 'runId': run_id, 'executionId': run_id,
                        'jmsSenderScope': jms_sender_scope or self.jms_application_scope(project.id if project else process.id)},
            'transport': transport or {},
            '_process': process, 'groupStack': [], 'jdbcTransactions': {},
        }
        if branch_context is not None:
            context['input'] = copy.deepcopy(branch_context['input'])
            context['vars'] = copy.deepcopy(branch_context['vars'])
            context['context'].update(branch_context['context'])
        if project:
            self._active_execution[run_id] = {'projectId':project.id,'logs':logs,'activities':activity_outputs,'tasks':task_outputs}
        self.log(logs, 'INFO', f'Job started: {process.name}', kind='lifecycle', correlationId=correlation_id, runId=run_id, startedAt=log_timestamp(started))
        def finish(status: str, output: dict) -> RunResult:
            self._active_execution.pop(run_id, None)
            if branch_output is not None: branch_output['last'] = context['last']
            ended = datetime.now(timezone.utc); duration = round((ended - started).total_seconds() * 1000, 3)
            self.log(logs, 'INFO' if status == 'completed' else 'ERROR', f'Job {status}: {process.name} in {duration:.3f} ms', kind='lifecycle', correlationId=correlation_id, runId=run_id, endedAt=log_timestamp(ended), durationMs=duration)
            for entry in logs:
                entry.setdefault('correlationId', correlation_id); entry.setdefault('runId', run_id)
            return RunResult(run_id=run_id, correlation_id=correlation_id, started_at=log_timestamp(started), ended_at=log_timestamp(ended), duration_ms=duration, status=status, output=output, logs=logs, activity_outputs=activity_outputs, task_outputs=task_outputs)
        activity_by_id = {a.id: a for a in process.activities}
        outgoing_by_source = {}
        for transition in process.transitions:
            outgoing_by_source.setdefault(transition.source, []).append(transition)
        try: group_plans = self.compile_groups(process)
        except Exception as exc:
            self.log(logs, 'ERROR', str(exc)); return finish('failed', {})
        incoming = {t.target for t in process.transitions}
        starts = [activity_by_id[entry_activity_id]] if entry_activity_id in activity_by_id else ([a for a in process.activities if a.type == 'start'] or [a for a in process.activities if a.id not in incoming and a.type != 'catch'])
        if len(starts) != 1:
            self.log(logs, 'ERROR', 'Process must have exactly one Start activity')
            return finish('failed', {})
        current = starts[0]
        triggered_event_pending = event_output is not _NO_EVENT_OUTPUT and current.id == entry_activity_id
        try:
            step_count = 0
            while True:
                if current.id == stop_activity_id: break
                step_count += 1
                if step_count > max(100000, len(process.activities) * 10000):
                    raise MinaFault('Execution step limit exceeded; check group loop conditions', fault_type='GROUP_ITERATION_LIMIT')
                entered = await self.enter_group_boundaries(current.id, context, group_plans)
                if entered is None: break
                if entered != current.id:
                    current = activity_by_id[entered]; continue
                activity_started = perf_counter()
                operation = str(current.config.get('operation') or current.type)
                self.log(logs, 'INFO', f'Activity started: {process.name} / {current.name}', kind='activity', taskId=process.id, runtimeActivityId=current.id, activityName=current.name, activityType=current.type, operation=operation)
                context['context']['activityId'] = current.id
                activity_input = context['last']
                error = None
                if project:
                    self._active_activity[run_id] = {
                        'projectId': project.id, 'taskId': process.id, 'taskName': process.name,
                        'activityId': current.id, 'activityName': current.name, 'startedAt': log_timestamp(),
                    }
                try:
                    if triggered_event_pending:
                        context['last'] = event_output
                        activity_input = event_output
                        triggered_event_pending = False
                        self.log(logs, 'INFO', f'Event delivered: {process.name} / {current.name}', kind='event', taskId=process.id, runtimeActivityId=current.id, activityName=current.name, activityType=current.type, operation=operation)
                    else:
                        context['last'] = await self.execute_with_policy(current, context)
                    self.record_activity_output(current, context['last'], context, activity_input)
                except Exception as exc: error = exc
                finally: self._active_activity.pop(run_id, None)
                activity_duration = round((perf_counter() - activity_started) * 1000, 3)
                if error:
                    self.log(logs, 'ERROR', f'Activity failed: {process.name} / {current.name} in {activity_duration:.3f} ms: {error}', kind='activity', taskId=process.id, runtimeActivityId=current.id, activityName=current.name, activityType=current.type, operation=operation, durationMs=activity_duration)
                else:
                    self.log(logs, 'INFO', f'Activity completed: {process.name} / {current.name} in {activity_duration:.3f} ms', kind='activity', taskId=process.id, runtimeActivityId=current.id, activityName=current.name, activityType=current.type, operation=operation, durationMs=activity_duration)
                outgoing = outgoing_by_source.get(current.id, [])
                if current.type in ('end', 'http_response') and not error: break
                if error:
                    chosen = next((t for t in outgoing if t.type == 'error'), None)
                    fault = self.fault_payload(error, current.id)
                    context['last'] = fault; context['context']['error'] = fault; context['vars']['error'] = fault
                    if not chosen:
                        retry_target = await self.retry_failed_group(context, group_plans)
                        if retry_target:
                            current = activity_by_id[retry_target]
                            continue
                        while context.get('groupStack'):
                            failed_state = context['groupStack'].pop()
                            await self._finish_group(failed_state, group_plans[failed_state['id']], context, False)
                        used = set(context['context'].setdefault('handledCatchIds', []))
                        catches = [activity for activity in process.activities if activity.type == 'catch' and activity.id not in used]
                        caught = next((activity for activity in catches if self.as_bool(activity.config.get('catchAll', True)) or (activity.config.get('errorType') and activity.config.get('errorType') == fault['type']) or (activity.config.get('errorCode') and str(activity.config.get('errorCode')) == fault['code'])), None)
                        if not caught: raise error
                        context['context']['handledCatchIds'].append(caught.id)
                        self.log(logs, 'WARN', f'{caught.name} caught {fault["type"]}: {fault["message"]}', caught.id, kind='exception', fault=fault)
                        current = caught
                        continue
                else:
                    chosen_edges = self.select_group_transitions(self.eligible_success_transitions(outgoing, context), context, group_plans)
                if error:
                    chosen_edges = [chosen] if chosen else []
                if not chosen_edges:
                    target_id = await self.leave_group_boundaries(current.id, None, context, group_plans, success=not error)
                    if target_id:
                        current = activity_by_id[target_id]; continue
                    if context.get('groupStack'): raise RuntimeErrorWithLogs(f'{current.name} has no matching outgoing transition')
                    break
                for edge in chosen_edges:
                    self.log(logs, 'DEBUG', f'Transition selected: {current.name} -> {activity_by_id[edge.target].name} ({edge.type})', kind='trace', runtimeActivityId=current.id, transitionId=edge.id, parallel=len(chosen_edges) > 1)
                if len(chosen_edges) == 1:
                    target_id = await self.leave_group_boundaries(current.id, chosen_edges[0].target, context, group_plans, success=not error)
                    if target_id is None: break
                    current = activity_by_id[target_id]
                else:
                    # A task may have multiple eligible success edges.  They are
                    # a fan-out, not an ordered if/else chain. Run every branch
                    # and share execution state so all outputs remain mappable.
                    branch_initial = context['last']
                    plan = parallel_plan(
                        [(edge.source, edge.target, edge.type) for edge in process.transitions],
                        [edge.target for edge in chosen_edges],
                        [node.id for node in process.activities if node.type in ('end', 'http_response')],
                        boundary=stop_activity_id, fork=current.id)
                    async def run_branch(target, stop, value):
                        branch_value = {}
                        result = await self.run(process, value, resources=resources, properties=properties,
                                 entry_activity_id=target, project=project,
                                 execution_state=execution_state, transport=transport,
                                 jms_sender_scope=context['context']['jmsSenderScope'],
                                 stop_activity_id=stop, branch_context=context,
                                 branch_output=branch_value)
                        logs.extend(result.logs)
                        if result.status != 'completed': raise RuntimeErrorWithLogs(f'Parallel branch {target} failed from {current.name}')
                        return branch_value['last']
                    values = await execute_parallel(plan, run_branch, branch_initial, stop_activity_id)
                    join = plan['join']
                    context['last'] = values[-1] if values else context['last']
                    final_output = context['last'] if isinstance(context['last'], dict) else {'result': context['last']}
                    if join is not None:
                        self.log(logs, 'DEBUG', f'Parallel branches joined before {activity_by_id[join].name}', kind='parallel', runtimeActivityId=join)
                        current = activity_by_id[join]
                        continue
                    task_state['output'] = final_output
                    return finish('completed', final_output)
            final_output = context['last'] if isinstance(context['last'], dict) else {'result': context['last']}
            task_state['output'] = final_output
            return finish('completed', final_output)
        except asyncio.CancelledError:
            self._active_execution.pop(run_id, None)
            # Cancellation must unwind JDBC transaction groups and critical
            # sections just like a failed execution. Without this path a
            # Debug Stop could leave a connection or lock alive on Windows.
            while context.get('groupStack'):
                state = context['groupStack'].pop()
                try: await self._finish_group(state, group_plans[state['id']], context, False)
                except Exception: pass
            raise
        except Exception as exc:
            while context.get('groupStack'):
                state = context['groupStack'].pop()
                try: await self._finish_group(state, group_plans[state['id']], context, False)
                except Exception: pass
            self.log(logs, 'ERROR', str(exc), current.id)
            task_state['error'] = {'message': str(exc), 'activityId': current.id}
            return finish('failed', {})

    def eligible_success_transitions(self, outgoing, context: dict):
        """Return every success edge eligible after an activity completes.

        The old implementation used ``next`` and therefore silently discarded
        every second success edge. Conditional edges retain their precedence;
        when one or more conditions match, all matching conditions are fanned
        out. Otherwise all normal success edges (or all success_no_match edges)
        are returned.
        """
        def matches(edge):
            if edge.bw_xpath is not None:
                from .mapper_xml import bw_transition_condition
                return bw_transition_condition(edge.condition, edge.bw_xpath, lambda path: get_path(context, path),
                                               context.get('properties', {}))
            return self.condition(edge.condition, context)

        conditional = [edge for edge in outgoing if edge.type == 'success_condition' and matches(edge)]
        # Older project files omitted the type on ordinary success edges;
        # preserve their historical behavior as executable success paths.
        success = [edge for edge in outgoing if edge.type in ('success', None)]
        # A matching condition is not an exclusive if/else switch.  Normal
        # success edges are also executable branches, so retain them whenever
        # they coexist with matching conditional edges. This prevents a
        # conditional branch from silently suppressing a parallel publisher,
        # logger, or audit path.
        if conditional or success:
            return [*conditional, *success]
        return [edge for edge in outgoing if edge.type == 'success_no_match']

    @staticmethod
    def select_group_transitions(edges, context: dict, plans: dict[str, dict]):
        """Apply Pick First semantics before the generic parallel fan-out.

        Pick First is a first-match branch construct: once execution reaches a
        branch in the group, only that eligible branch continues. Ordinary
        success fan-out remains unchanged for every other group type.
        """
        if len(edges) <= 1:
            return edges
        active = next((state for state in reversed(context.get('groupStack', []))
                       if getattr(plans.get(state.get('id'), {}).get('group'), 'type', None) == 'pick_first'), None)
        if active:
            return edges[:1]
        process = context.get('_process')
        if not process:
            return edges
        pick_first_members = set().union(*(plan['members'] for plan in plans.values() if plan['group'].type == 'pick_first'))
        candidates = [edge for edge in edges if edge.target in pick_first_members]
        return edges[:1] if candidates else edges

    @staticmethod
    def record_activity_output(activity: Activity, result, ctx: dict, input_value: Any = _NO_EVENT_OUTPUT):
        """Retain every executed activity result for downstream mappings and debugging."""
        record = {'activityId': activity.id, 'name': activity.name, 'type': activity.type, 'output': copy.deepcopy(result)}
        input_value = ctx.get('_resolvedActivityInputs', {}).pop(activity.id, input_value)
        if input_value is not _NO_EVENT_OUTPUT:
            record['input'] = copy.deepcopy(input_value)
        if activity.type in ('xml', 'flat') and activity.config.get('operation') == 'parse' and isinstance(result, dict) and result.get('xml'):
            record['displayOutput'] = result['xml']
        record.update(ctx.pop('_activityMetadata', {}))
        ctx.setdefault('activities', {})[activity.id] = record
        task_id = ctx.get('context', {}).get('taskId')
        if task_id:
            task = ctx.setdefault('tasks', {}).setdefault(task_id, {'activities': {}})
            task.setdefault('activities', {})[activity.id] = record

    @staticmethod
    def fault_payload(error: Exception, activity_id: str) -> dict:
        stack_trace = ''.join(traceback.format_exception(type(error), error, error.__traceback__))
        return {'type': getattr(error, 'fault_type', error.__class__.__name__), 'code': str(getattr(error, 'code', '') or ''), 'message': str(error), 'stackTrace': stack_trace, 'activityId': activity_id, 'details': getattr(error, 'details', {}) or {}, 'cause': getattr(error, 'cause', None)}

    def log(self, logs, level, message, activity_id=None, **details):
        logs.append({'time': log_timestamp(), 'level': level, 'message': message, 'activityId': activity_id, **details})

    @staticmethod
    def _cron_field_matches(expression: str, value: int, minimum: int, maximum: int) -> bool:
        def item_matches(item: str) -> bool:
            base, _, step_text = item.partition('/')
            step = int(step_text or 1)
            if step < 1: raise ValueError('Cron step must be greater than zero')
            if base == '*': start, end = minimum, maximum
            elif '-' in base: start, end = (int(part) for part in base.split('-', 1))
            else: start = end = int(base)
            if start < minimum or end > maximum or start > end: raise ValueError(f'Cron value {item!r} is outside {minimum}-{maximum}')
            return start <= value <= end and (value - start) % step == 0
        return any(item_matches(item.strip()) for item in expression.split(',') if item.strip())

    @classmethod
    def _next_cron_time(cls, expression: str, now: datetime) -> datetime:
        parts = expression.split()
        if len(parts) != 5: raise MinaFault('Cron expression requires five fields: minute hour day month weekday', fault_type='SCHEDULER')
        candidate = now.replace(second=0, microsecond=0) + timedelta(minutes=1)
        for _ in range(527040):
            weekday = (candidate.weekday() + 1) % 7
            try:
                if (cls._cron_field_matches(parts[0], candidate.minute, 0, 59) and cls._cron_field_matches(parts[1], candidate.hour, 0, 23) and cls._cron_field_matches(parts[2], candidate.day, 1, 31) and cls._cron_field_matches(parts[3], candidate.month, 1, 12) and cls._cron_field_matches(parts[4], weekday, 0, 6)):
                    return candidate
            except ValueError as error:
                raise MinaFault(str(error), fault_type='SCHEDULER') from error
            candidate += timedelta(minutes=1)
        raise MinaFault('Cron expression did not produce an execution time within one year', fault_type='SCHEDULER')

    async def execute_with_policy(self, activity: Activity, ctx: dict):
        policy = self.resolve(activity.config.get('errorPolicy', {}), ctx)
        advanced = self.resolve({
            **{key.removeprefix('advanced.'): value for key, value in ctx.get('properties', {}).items() if key.startswith('advanced.retry')},
            'logPayload': '${properties.advanced.logPayload}',
            'retryEnabled': '${properties.advanced.retryEnabled}',
            'retryCount': '${properties.advanced.retryCount}',
            'retryIntervalSeconds': '${properties.advanced.retryIntervalSeconds}',
            **activity.config.get('advanced', {})
        }, ctx)
        log_payload = self.as_bool(advanced.get('logPayload', False))
        retry = RetryPlan(self.is_outbound(activity), advanced, policy)
        started = perf_counter()
        if log_payload:
            self.log(ctx.setdefault('logs', []), 'INFO', f'{activity.name} input payload: {self.payload_text(ctx.get("last"))}', activity.id)
        for attempt in range(retry.count + 1):
            try:
                result = await self.execute(activity, ctx)
                if activity.config.get('outputName'): ctx['vars'][activity.config['outputName']] = result
                if log_payload:
                    self.log(ctx.setdefault('logs', []), 'INFO', f'{activity.name} output payload: {self.payload_text(result)}', activity.id)
                return result
            except Exception as exc:
                retry_delay = retry.delay(attempt, exc, perf_counter() - started)
                if retry_delay is not None:
                    self.log(ctx.setdefault('logs', []), 'WARN', f'{activity.name} failed; retry {attempt + 1} of {retry.count} in {retry_delay:g} seconds: {exc}', activity.id)
                    if retry_delay: await asyncio.sleep(retry_delay)
                    continue
                fault = {'type': getattr(exc, 'fault_type', exc.__class__.__name__), 'description': str(exc), 'activityId': activity.id}
                if self.as_bool(policy.get('includeInput', True)): fault['input'] = ctx.get('last')
                if policy.get('outputVariable'): ctx.setdefault('vars', {})[policy['outputVariable']] = fault
                if policy.get('action') == 'continue': return fault
                if policy.get('action') == 'ignore': return ctx.get('last')
                raise

    @staticmethod
    def as_bool(value, default=False):
        if value is None:
            return default
        return value if isinstance(value, bool) else str(value).strip().lower() in ('true','1','yes','on')

    @staticmethod
    def payload_text(value):
        # IDoc listener/parser results carry the canonical wire representation
        # in IDocXML (or payload). Do not turn that XML into a JSON object just
        # because the surrounding application log is JSON-lines formatted.
        if isinstance(value, dict):
            for key in ('IDocXML', 'xmlString', 'xml', 'payload'):
                candidate = value.get(key)
                if isinstance(candidate, str) and candidate.lstrip().startswith('<'):
                    return candidate
        if isinstance(value, str) and value.lstrip().startswith('<'):
            return value
        try: return json.dumps(value, ensure_ascii=False, default=str)
        except (TypeError, ValueError): return str(value)

    @staticmethod
    def is_outbound(activity: Activity) -> bool:
        return outbound_activity(activity.type, activity.config.get('operation', ''))

    def resolve_activity_config(self, activity: Activity, ctx: dict):
        # Resolve environment, input, variable, and previous-output expressions in every activity field.
        literal_keys = {'script', 'libraries', 'outputs', 'sourceSchema', 'mappings', 'inputMappings', 'targetSchema', 'targetSchemaText', 'sourceSchemaText', 'schemaText', 'interfaceSchemaText', 'lookupTables', 'testCases', 'templateHistory', 'customFunctions', 'contractBaseline', 'xmlSource', 'xmlStylesheet', 'xmlNamespaces', 'xmlVariables', 'sourceTypeOverrides', 'sourceCoercions'}
        cfg = self.resolve({key: value for key, value in activity.config.items() if key not in literal_keys}, ctx)
        cfg.update({key: value for key, value in activity.config.items() if key in literal_keys})
        if activity.type in ('mapper', 'transform', 'ai_transform') and cfg.get('targetSchemaId'):
            schema_id = cfg['targetSchemaId']
            asset = next((item for item in getattr(ctx.get('project'), 'schemas', ()) if schema_id in (item.id, item.name)), None)
            if not asset or not asset.content: raise MinaFault('Selected Mapper target schema was not found', fault_type='ValidationException')
            from .xsd_catalog import inherit_schema_selection
            cfg.update(targetSchema={}, targetSchemaText=inherit_schema_selection(asset.content,cfg.get("targetSchemaText")), xmlTargetSchemaPath=asset.source_path or asset.name)
        mapped_input = {}
        execution_scope = str(ctx.get('context', {}).get('executionId') or ctx.get('context', {}).get('debugSessionId') or '')
        if execution_scope: cfg['_executionScope'] = execution_scope
        mapped_input = self.map_input_values(activity.config.get('inputMappings', {}), ctx)
        mapped_paths = set(activity.config.get('inputMappings', {}))
        def merge_input(target, values, parent=''):
            for key, value in values.items():
                path = f'{parent}.{key}' if parent else key
                # A mapped object replaces that field, including a ${last}
                # default. Only intermediate tree nodes preserve unmapped defaults.
                if path not in mapped_paths and isinstance(value, dict) and isinstance(target.get(key), dict):
                    target[key] = dict(target[key])
                    merge_input(target[key], value, path)
                else: target[key] = copy.deepcopy(value)
        merge_input(cfg, mapped_input)
        if activity.type in ('start', 'end', 'json'): cfg['_mappedInput'] = mapped_input
        for key, value in ctx.get('_debugInputOverrides', {}).get(activity.id, {}).items():
            self.assign_path(cfg, key, value)
            self.assign_path(mapped_input, key, copy.deepcopy(value))
        if activity.config.get('inputMappings') or ctx.get('_debugInputOverrides', {}).get(activity.id):
            ctx.setdefault('_resolvedActivityInputs', {})[activity.id] = mapped_input
        if activity.type in ('ftp','sftp','http','http_listener','http_response','rest','soap','sap') and cfg.get('resourceId'):
            shared = ctx['resources'].get(cfg['resourceId'])
            if not shared: raise RuntimeError(f'{activity.name} requires a valid shared connection')
            cfg = merge_http_config(self.resolve(shared.config, ctx), cfg) if activity.type in ('http','rest','soap','http_listener') else {**self.resolve(shared.config, ctx), **cfg}
        return cfg

    async def execute(self, activity: Activity, ctx: dict):
        cfg = self.resolve_activity_config(activity, ctx)
        if activity.type == 'start':
            mapped = cfg['_mappedInput']
            return self.unwrap_boundary(mapped, 'payload', ctx['input'])
        if activity.type == 'end':
            mapped = cfg['_mappedInput']
            return self.unwrap_boundary(mapped, 'result', ctx['last'])
        if activity.type == 'timer':
            now = datetime.now(timezone.utc)
            environment = str(ctx.get('context', {}).get('environment') or '').lower()
            # The designer's Run once option is intended for local Run/Debug.
            # Debug sessions may execute against a named environment profile
            # (for example production), so identify Debug explicitly rather
            # than accidentally making it wait for the production schedule.
            is_debug = bool(ctx.get('context', {}).get('debugSessionId'))
            run_once = self.as_bool(cfg.get('runOnceOnLocalStart', True)) and (environment == 'local' or is_debug)
            mode = str(cfg.get('scheduleMode') or 'dateTime')
            if run_once:
                scheduled = now
                trigger_mode = 'local-run-once'
            elif mode == 'cron':
                scheduled = self._next_cron_time(str(cfg.get('cronExpression') or ''), now)
                trigger_mode = 'cron'
            else:
                raw = str(cfg.get('scheduledDateTime') or '').strip()
                if not raw: raise MinaFault('Scheduler requires a date/time or local Run once option', fault_type='SCHEDULER')
                try:
                    scheduled = datetime.fromisoformat(raw.replace('Z', '+00:00'))
                    if scheduled.tzinfo is None: scheduled = scheduled.astimezone()
                    scheduled = scheduled.astimezone(timezone.utc)
                except ValueError as error: raise MinaFault(f'Invalid scheduler date/time: {raw}', fault_type='SCHEDULER') from error
                trigger_mode = 'dateTime'
            delay = max(0.0, (scheduled - now).total_seconds())
            self.log(ctx['logs'], 'INFO', f'Scheduler armed for {scheduled.isoformat()}', activity.id, kind='scheduler', triggerMode=trigger_mode, waitSeconds=round(delay, 3))
            if delay: await asyncio.sleep(delay)
            fired = datetime.now(timezone.utc)
            return {'scheduledTime': scheduled.isoformat(), 'actualTime': fired.isoformat(), 'sequence': 1, 'triggerMode': trigger_mode, 'payload': ctx['last']}
        if activity.type == 'basic':
            operation = str(cfg.get('operation') or 'empty')
            if operation in {'deduplicate', 'message_receipt', 'replay_messages', 'aggregate_messages', 'split_records'}:
                return await asyncio.to_thread(mediation_operation, operation, cfg, cfg.get('payload', ctx['last']))
            if operation == 'empty': return ctx['last']
            if operation == 'assign':
                name, value = str(cfg.get('variable') or '').strip(), cfg.get('value', ctx['last'])
                if not name: raise RuntimeError('Assign Variable requires a process variable name')
                ctx['vars'][name] = value; return {'name': name, 'value': value}
            if operation == 'checkpoint':
                checkpoint_id, created = str(uuid.uuid4()), log_timestamp()
                checkpoint = {'checkpointId': checkpoint_id, 'name': str(cfg.get('checkpointName') or activity.name), 'timestamp': created, 'activityId': activity.id}
                if self.as_bool(cfg.get('includeProcessState', True)):
                    checkpoint['state'] = {'last': ctx.get('last'), 'vars': dict(ctx.get('vars', {})), 'context': dict(ctx.get('context', {}))}
                ctx.setdefault('checkpoints', []).append(checkpoint)
                self.log(ctx['logs'], 'INFO', f"Checkpoint created: {checkpoint['name']}", activity.id, kind='checkpoint', checkpointId=checkpoint_id)
                return {key: value for key, value in checkpoint.items() if key != 'state'}
            if operation == 'sleep':
                duration = float(cfg.get('duration') or 0); unit = str(cfg.get('unit') or 'milliseconds').lower()
                seconds = duration * (60 if unit == 'minutes' else 1 if unit == 'seconds' else .001)
                await asyncio.sleep(max(0, seconds)); return {'sleptMilliseconds': round(seconds * 1000), 'payload': ctx['last']}
            if operation == 'get_context': return dict(ctx.get('context', {}))
            if operation == 'set_context':
                values = cfg.get('values') or {}
                if not isinstance(values, dict): raise RuntimeError('Set Process Context requires an object')
                ctx['context'].update(values); return {'context': dict(ctx['context'])}
            if operation == 'get_shared_variable':
                name = str(cfg.get('name') or '').strip(); return {'name': name, 'value': self.shared_variables.get(name, cfg.get('default'))}
            if operation == 'set_shared_variable':
                name, value = str(cfg.get('name') or '').strip(), cfg.get('value', ctx['last'])
                if not name: raise RuntimeError('Set Shared Variable requires a name')
                self.shared_variables[name] = value; return {'name': name, 'value': value}
            if operation == 'external_command':
                command = str(cfg.get('command') or cfg.get('commandToExecute') or '').strip()
                if not command: raise MinaFault('External Command requires a command to execute', fault_type='InvalidInputException')
                arguments = shlex.split(command, posix=os.name != 'nt')
                if os.name == 'nt': arguments = [item[1:-1] if len(item) > 1 and item[0] == item[-1] and item[0] in ('"', "'") else item for item in arguments]
                if not arguments: raise MinaFault('External Command is empty', fault_type='InvalidInputException')
                environment = cfg.get('environment') or {}
                if isinstance(environment, str):
                    environment = dict(item.split('=', 1) for item in environment.split(',') if '=' in item)
                process_env = ({str(key): str(value) for key, value in environment.items()} if cfg.get('replaceEnvironment') else {**os.environ, **{str(key): str(value) for key, value in environment.items()}})
                try:
                    process = await asyncio.create_subprocess_exec(*arguments, cwd=cfg.get('workingDirectory') or None, env=process_env, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                    stdout, stderr = await asyncio.wait_for(process.communicate(str(cfg.get('input') or '').encode()), timeout=float(cfg.get('timeoutSeconds') or 300))
                except asyncio.CancelledError:
                    if 'process' in locals() and process.returncode is None:
                        process.terminate()
                        try: await asyncio.wait_for(process.wait(), timeout=1)
                        except asyncio.TimeoutError:
                            process.kill(); await process.wait()
                    raise
                except asyncio.TimeoutError as exc:
                    process.kill(); await process.wait(); raise MinaFault('External command exceeded its timeout', fault_type='CommandExecutionError') from exc
                except (OSError, ValueError) as exc: raise MinaFault(str(exc), fault_type='CommandExecutionError') from exc
                output, error = stdout.decode(cfg.get('encoding') or 'utf-8', errors='replace'), stderr.decode(cfg.get('encoding') or 'utf-8', errors='replace')
                output_file = str(cfg.get('outputFile') or cfg.get('outputFilename') or '').strip()
                if output_file:
                    try: Path(output_file).write_text(output + error, encoding=cfg.get('encoding') or 'utf-8')
                    except OSError as exc: raise MinaFault(str(exc), fault_type='FileIOError') from exc
                split = str(cfg.get('outputLineSplitting') or 'None')
                if split == 'AtOperatingSystemLineEnd': output, error = output.splitlines(), error.splitlines()
                elif split == 'AtSpecifiedToken':
                    token = str(cfg.get('splitToken') or '')
                    if not token: raise MinaFault('A split token is required', fault_type='InvalidInputException')
                    output, error = output.split(token), error.split(token)
                return {'returnCode': process.returncode, 'output': output if cfg.get('provideCommandOutput', True) else None, 'error': error if cfg.get('provideCommandOutput', True) else None, 'outputFile': output_file or None}
            raise RuntimeError(f'Unsupported Basic/General operation {operation}')
        if activity.type == 'catch': return ctx.get('context', {}).get('error') or ctx['last']
        if activity.type == 'throw':
            details = cfg.get('details', {})
            if isinstance(details, str) and details.strip():
                try: details = json.loads(details)
                except ValueError: details = {'text': details}
            if cfg.get('stackTrace'):
                details = {**(details if isinstance(details, dict) else {'value': details}), 'stackTrace': cfg.get('stackTrace')}
            raise MinaFault(str(cfg.get('message') or 'Business fault'), fault_type=str(cfg.get('errorType') or cfg.get('type') or 'UserDefinedException'), code=str(cfg.get('code') or ''), details=details)
        if activity.type == 'rethrow':
            fault = ctx.get('context', {}).get('error')
            if not fault: raise MinaFault('Rethrow requires an active caught exception', fault_type='RethrowException')
            raise MinaFault(fault.get('message', 'Rethrown exception'), fault_type=fault.get('type', 'RethrowException'), code=fault.get('code', ''), details=fault.get('details', {}), cause=fault)
        if activity.type in ('http_listener',) or (activity.type == 'rest' and cfg.get('operation') == 'receiver') or (activity.type == 'soap' and cfg.get('operation') == 'service'):
            return ctx['last']
        if activity.type == 'http_response':
            # Configuration and Input mappings are already resolved. Literal API
            # examples may contain ${...} text and must not be evaluated twice.
            from .http_messages import response_message
            return {'__httpResponse': True, **response_message(cfg,ctx.get('last'))}
        if activity.type == 'log':
            level = str(cfg.get('level') or 'INFO').upper()
            if level not in ('DEBUG', 'INFO', 'WARN', 'ERROR'): level = 'INFO'
            message = cfg.get('message')
            if message in (None, ''): message = f'{activity.name} payload'
            if not isinstance(message, str): message = self.payload_text(message)
            payload = cfg.get('payload', ctx['last'])
            # Treat an untouched empty payload editor as "current activity
            # payload". This keeps a Log activity useful after an inbound
            # listener/parser without requiring a redundant mapping, while
            # still honoring an explicit payload mapping.
            if payload in (None, '') and 'payload' not in activity.config.get('inputMappings', {}):
                payload = ctx['last']
            # Existing projects commonly mapped a parser branch such as
            # `${activities.<id>.output.SAPIDoc.ARTMAS05}`. That branch is the
            # JSON view of the IDoc, while the parser also publishes IDocXML
            # as the canonical XML view. Preserve the old mapping and log the
            # requested IDoc in the configured output format.
            payload_mapping = activity.config.get('inputMappings', {}).get('payload')
            if isinstance(payload_mapping, str) and '.output.' in payload_mapping and isinstance(payload, dict):
                match = re.search(r'\$\{activities\.([^\.}]+)\.output(?:\.|\})', payload_mapping)
                source_record = ctx.get('activities', {}).get(match.group(1)) if match else None
                source_output = source_record.get('output') if isinstance(source_record, dict) else None
                if isinstance(source_output, dict) and str(source_output.get('format', '')).upper() == 'XML' and source_output.get('IDocXML'):
                    payload = source_output['IDocXML']
            include_payload = self.as_bool(cfg.get('includePayload', False)) or 'payload' in activity.config.get('inputMappings', {})
            event = {'level': level, 'message': message, 'activityId': activity.id, 'activityName': activity.name}
            if include_payload:
                event['payload'] = payload
                event['payloadFormat'] = 'XML' if isinstance(payload, str) and payload.lstrip().startswith('<') else 'JSON' if isinstance(payload, (dict, list)) else 'TEXT'
            self.log(ctx.setdefault('logs', []), level, message, activity.id, activityName=activity.name, **({'payload': payload, 'payloadFormat': event['payloadFormat']} if include_payload else {}))
            ctx['_activityMetadata'] = {'logEvent': event}
            return ctx['last']
        if activity.type == 'confirm':
            # SAP IDoc listeners carry their transaction handle out-of-band in
            # the workflow transport.  An explicit Confirm activity can close
            # that tRFC immediately, allowing SAP to deliver the next IDoc
            # while downstream activities continue.  This is deliberately
            # opt-in: failures after this point cannot roll the IDoc back.
            transport = ctx.get('transport') or {}
            sap_delivery_id = transport.get('deliveryId')
            sap_listener_key = transport.get('listenerKey')
            if sap_delivery_id and sap_listener_key and not transport.get('completed'):
                sap_adapter.acknowledge_idoc(sap_listener_key, sap_delivery_id, True)
                transport['completed'] = True
                transport['earlyConfirmed'] = True
                return {'confirmed': True, 'count': 1, 'ackIds': [str(sap_delivery_id)], 'technologies': ['SAP'], 'early': True}
            previous = ctx['last'] if isinstance(ctx['last'], dict) else {}
            handles = cfg.get('ackIds') or cfg.get('ackId') or previous.get('ackIds') or previous.get('ackId') or previous.get('AckID')
            if not handles:
                if self.as_bool(cfg.get('failIfMissing', True)):
                    raise RuntimeError('Confirm Message requires an acknowledgement handle from a client/manual receiver')
                return {'confirmed': False, 'count': 0, 'ackIds': [], 'technologies': []}
            return await self.confirm_messages(handles)
        if activity.type in ('mapper', 'transform', 'ai_transform'):
            if self.as_bool(cfg.get('streamEnabled', False)):
                plan = await execute_transform_activity(cfg, ctx.get('last'), ctx.get('attributes'), ctx.get('vars'), getattr(ctx.get('project'), 'schemas', ()), kind='mapper', mapping_context={key: ctx.get(key, {}) for key in ('properties', 'activities', 'context', 'tasks', 'attributes')})
                return plan['output']
            if cfg.get('xmlStylesheet') or cfg.get('generatedXmlBinding') or cfg.get('sourceCoercions'):
                cfg['xmlSchemaDocuments'] = {**(activity.config.get('xmlSchemaDocuments') or {}),
                    **{asset.source_path or asset.name: asset.content for asset in getattr(ctx.get('project'), 'schemas', [])
                       if (asset.source_path or asset.name).lower().endswith('.xsd')}}
            source = {
                **(ctx['last'] if isinstance(ctx.get('last'), dict) else {}),
                'last': ctx.get('last'), 'input': ctx.get('input'),
                'properties': ctx.get('properties', {}), 'vars': ctx.get('vars', {}),
                'context': ctx.get('context', {}), 'activities': ctx.get('activities', {}),
            }
            rules = []
            for rule in activity.config.get('mappings', []) or []:
                normalized = {**rule}
                for key in ('source', 'select'):
                    value = normalized.get(key)
                    if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
                        normalized[key] = value[2:-1]
                if isinstance(normalized.get('condition'), str):
                    normalized['condition'] = rewrite_references(normalized['condition'], lambda value: value[2:-1])
                if isinstance(normalized.get('whens'), list):
                    normalized['whens'] = [{
                        **branch,
                        'condition': rewrite_references(str(branch.get('condition') or ''), lambda value: value[2:-1]),
                        'source': branch['source'][2:-1] if isinstance(branch.get('source'), str) and branch['source'].startswith('${') and branch['source'].endswith('}') else branch.get('source'),
                    } for branch in normalized['whens']]
                rules.append(normalized)
            functions = list({item['name']: item for item in [*cfg.get('customFunctions', []), *[item.model_dump() for item in getattr(ctx.get('project'), 'custom_functions', [])]]}.values())
            return await execute_mapping_async(source, rules, {**cfg, 'customFunctions': functions})
        if activity.type == 'dataweave':
            try:
                plan = await execute_transform_activity(cfg, ctx.get('last'), ctx.get('attributes'), ctx.get('vars'), getattr(ctx.get('project'), 'schemas', ()))
                if plan['attributesChanged']: ctx['attributes'] = plan['attributes']
                ctx.setdefault('vars', {}).update(plan['variables'])
                return plan['output']
            except DataWeaveError as exc:
                raise MinaFault(str(exc), fault_type=getattr(exc, 'fault_type', 'DATAWEAVE_SYNTAX'), cause=exc.__class__.__name__) from exc
        if activity.type == 'sap':
            resource = ctx['resources'].get(cfg.get('resourceId'))
            if not resource or resource.type != 'sap': raise RuntimeError('SAP activity requires an SAP ECC shared connection')
            sap_cfg = {**self.resolve(resource.config, ctx), **cfg}
            # SAP's TID manager is a separate shared resource in the reference
            # plug-in. Resolve it here so the listener uses the configured
            # durable store instead of silently falling back to a process-local
            # file. Keep the fallback for older projects that never selected a
            # TID resource.
            operation = cfg.get('operation', 'invoke_rfc_bapi')
            if operation == 'idoc_listener':
                tid_resource_id = cfg.get('tidManagerId')
                tid_resource = ctx['resources'].get(tid_resource_id) if tid_resource_id else None
                if tid_resource and tid_resource.type == 'sap_tid':
                    tid_cfg = self.resolve(tid_resource.config, ctx)
                    if str(tid_cfg.get('mode') or 'active').lower() not in ('none', 'disabled', 'off', 'false', '0'):
                        configured_store = tid_cfg.get('storageFile') or tid_cfg.get('tidStorePath') or tid_cfg.get('url')
                        if configured_store:
                            sap_cfg['tidStorePath'] = configured_store
                    else:
                        sap_cfg['tidManagement'] = 'disabled'
            selected_idoc = next((item for item in sap_cfg.get('idocCatalog', []) if item.get('idocType') == sap_cfg.get('idocType')), None) or sap_cfg.get('selectedIdoc')
            if selected_idoc:
                sap_cfg = {**sap_cfg, 'selectedIdoc': selected_idoc, 'idocType': sap_cfg.get('idocType') or selected_idoc.get('idocType'), 'extensionType': sap_cfg.get('extensionType') or selected_idoc.get('extensionType',''), 'release': sap_cfg.get('release') or selected_idoc.get('release',''), 'idocSchema': selected_idoc.get('schema')}
            payload = cfg.get('payload', ctx['last'])
            if operation in ('idoc_listener', 'rfc_bapi_listener'):
                source = str(sap_cfg.get('messagingSource') or 'NoMessaging').strip().lower().replace(' ', '')
                if operation == 'idoc_listener' and source not in ('', 'nomessaging', 'direct', 'sapjcorfc/idoc_inbound_asynchronous'):
                    technology = {'ems':'ems', 'jms':'jms', 'kafka':'kafka'}.get(source)
                    if not technology:
                        raise RuntimeError(f'Unsupported SAP IDoc messaging source {sap_cfg.get("messagingSource")!r}')
                    broker_cfg = {
                        **sap_cfg,
                        'resourceId': sap_cfg.get('messagingResourceId'),
                        'operation': 'queue_receiver' if technology == 'ems' else 'receive_message' if technology == 'jms' else 'receive',
                        'destination': sap_cfg.get('messagingDestination') or sap_cfg.get('destination') or sap_cfg.get('topic'),
                        'topic': sap_cfg.get('messagingDestination') or sap_cfg.get('topic'),
                        'maxMessages': 1,
                    }
                    received = await self.messaging(technology, broker_cfg, ctx)
                    messages = received.get('messages') if isinstance(received, dict) else []
                    first = messages[0] if isinstance(messages, list) and messages else {}
                    broker_payload = received.get('body') if technology in ('ems', 'jms') else first.get('data')
                    properties = received.get('properties', {}) if isinstance(received, dict) else {}
                    sap_idoc = properties.get('SAPIDoc', {}) if isinstance(properties, dict) else {}
                    return {**received, 'payload': broker_payload, 'SAPIDoc': sap_adapter._normalize_idoc_arrays(sap_idoc, sap_cfg), 'messagingSource': technology.upper()}
                return await sap_adapter.receive_idoc(sap_cfg)
            if operation == 'reply_rfc_bapi' and sap_adapter._mode(sap_cfg) != 'mock':
                delivery = ctx.get('transport') or {}
                delivery_id, listener_key = delivery.get('deliveryId'), delivery.get('listenerKey')
                if not delivery_id or not listener_key:
                    raise RuntimeError('Reply from RFC/BAPI must run in the flow started by an RFC/BAPI Listener request')
                response = payload if isinstance(payload, dict) else {'RESULT': payload}
                sap_adapter.acknowledge_idoc(listener_key, delivery_id, True, response)
                delivery['completed'] = True
                return {'replied': True, 'functionName': delivery.get('functionName'), 'response': response}
            return await asyncio.to_thread(sap_adapter.execute, operation, sap_cfg, payload)
        if activity.type == 'http' or activity.type == 'rest' and cfg.get('operation') == 'invoke':
            cfg['_httpScope'] = getattr(ctx.get('project'), 'id', None) or str(id(self))
            response = await asyncio.to_thread(http_request, cfg)
            if cfg.get('operation') in ('sse_read', 'websocket_exchange', 'write_precondition'):
                return response
            return response['body'] if activity.type == 'http' and cfg.get('responseMode', 'payload') == 'payload' and not (cfg.get('RestInputRequest') is not None or cfg.get('requestModel') == 'tree') else response
        if activity.type == 'soap' and cfg.get('operation') == 'request_reply':
            envelope = cfg.get('envelope') or ctx['last']
            if not isinstance(envelope, (str, bytes)): envelope = self.render_xml(envelope, cfg.get('rootElement', 'Request'))
            request_cfg = {**cfg, 'method': 'POST', 'body': envelope, 'bodyType': 'text', 'headers': {'Content-Type': cfg.get('contentType', 'text/xml; charset=utf-8'), **cfg.get('headers', {})}}
            if cfg.get('soapAction'): request_cfg['headers']['SOAPAction'] = cfg['soapAction']
            request_cfg['_httpScope'] = getattr(ctx.get('project'), 'id', None) or str(id(self))
            return await asyncio.to_thread(http_request, request_cfg)
        if activity.type == 'file':
            from .file_operations import file_activity, run_io
            return await run_io(file_activity, cfg.get('operation','read'), cfg, ctx['last'])
        if activity.type == 'jdbc':
            resource = ctx['resources'].get(cfg.get('resourceId'))
            if not resource or resource.type != 'jdbc': raise MinaFault('JDBC activity requires a valid shared JDBC connection', fault_type='JDBCConnectionNotFoundException')
            transaction = ctx.get('jdbcTransactions', {}).get(cfg.get('resourceId'))
            try: return await asyncio.to_thread(jdbc_adapter.execute, self.resolve(resource.config, ctx), cfg, transaction, transaction is None)
            except Exception as exc: raise MinaFault(str(exc), fault_type=getattr(exc, 'fault_type', 'JDBCSQLException')) from exc
        if activity.type == 'snowflake':
            resource = ctx['resources'].get(cfg.get('resourceId'))
            if not resource or resource.type != 'snowflake': raise MinaFault('Snowflake activity requires a valid Snowflake JDBC shared connection', fault_type='SNOWFLAKE_CONNECTION')
            try: return await asyncio.to_thread(snowflake_adapter.execute, self.resolve(resource.config, ctx), cfg, ctx.get('last'))
            except Exception as exc: raise MinaFault(str(exc), fault_type='SNOWFLAKE_DATABASE_JDBC', code=str(getattr(exc, 'code', '') or '500009')) from exc
        if activity.type == 'amqp':
            resource = ctx['resources'].get(cfg.get('resourceId'))
            if not resource or resource.type != 'amqp': raise MinaFault('AMQP activity requires a valid AMQP shared connection', fault_type='AMQPConnectionException')
            rcfg, operation = self.resolve(resource.config, ctx), str(cfg.get('operation') or 'get')
            destination = str(cfg.get('queueName') or cfg.get('topicName') or cfg.get('entityName') or rcfg.get('entityName') or 'default')
            if rcfg.get('mode') == 'memory':
                key = f'amqp:{destination}'
                if operation == 'send':
                    message_id = str(cfg.get('messageID') or uuid.uuid4()); body = cfg.get('body', cfg.get('message', ctx['last']))
                    self.messages.setdefault(key, []).append({'messageId': message_id, 'body': body, 'UserProperties': cfg.get('userProperties') or {}, 'MessageProperties': {'deliveryMode': cfg.get('deliveryMode', 'Persistent') == 'Persistent', 'messageID': message_id, 'expiration': cfg.get('expiration', 0), 'priority': cfg.get('priority', 4), 'type': cfg.get('type'), 'contentType': cfg.get('contentType'), 'correlationID': cfg.get('correlationID')}})
                    return {'sendResult': True, 'MessageId': message_id}
                if operation in ('get', 'receive'):
                    items = self.messages.setdefault(key, []); message = items.pop(0) if items else None
                    if not message: return {'received': False, 'body': None, 'UserProperties': {}, 'MessageProperties': {}}
                    if str(cfg.get('acknowledgeMode') or 'Auto') != 'Auto':
                        token = self.register_acknowledgement('amqp', message['messageId']); self.acknowledgements[token]['message'] = message; self.acknowledgements[token]['destination'] = key
                        message['settlementToken'] = token; message['ackId'] = token
                    return {'received': True, **message}
                if operation == 'dead_letter':
                    token = str(cfg.get('settlementToken') or ''); pending = self.acknowledgements.pop(token, None)
                    if not pending: raise MinaFault('Settlement token was not found or expired', fault_type='AMQPPluginException')
                    dead_key = f"{pending.get('destination', key)}:$deadletter"; self.messages.setdefault(dead_key, []).append({**pending.get('message', {}), 'deadLetterReason': cfg.get('deadLetterReason'), 'deadLetterErrorDescription': cfg.get('deadLetterErrorDescription')})
                    return {'status': 'Success', 'settlementToken': token, 'messageId': pending.get('messageId')}
            try:
                if operation == 'send': return await asyncio.to_thread(amqp_adapter.send, rcfg, cfg)
                if operation in ('get', 'receive'):
                    message, callback = await asyncio.to_thread(amqp_adapter.get, rcfg, cfg)
                    if not message: return {'received': False, 'body': None, 'UserProperties': {}, 'MessageProperties': {}}
                    if callback:
                        token = self.register_acknowledgement('amqp', message.get('messageId', ''), callback); message['settlementToken'] = token; message['ackId'] = token
                    return {'received': True, **message}
                if operation == 'dead_letter':
                    token = str(cfg.get('settlementToken') or ''); pending = self.acknowledgements.pop(token, None)
                    if not pending: raise MinaFault('Settlement token was not found or expired', fault_type='AMQPPluginException')
                    result = pending.get('callback')(True) if pending.get('callback') else None
                    if asyncio.iscoroutine(result): await result
                    return {'status': 'Success', 'settlementToken': token, 'messageId': pending.get('messageId')}
            except MinaFault: raise
            except Exception as exc: raise MinaFault(str(exc), fault_type=getattr(exc, 'fault_type', 'AMQPPluginException')) from exc
        if activity.type == 'excel':
            try: return await asyncio.to_thread(self.read_excel, cfg)
            except Exception as exc: raise MinaFault(str(exc), fault_type='EXCEL_READ') from exc
        if activity.type in ('ftp','sftp'):
            from .file_operations import run_io
            return await run_io(self.ftp if activity.type=='ftp' else self.sftp, cfg, ctx)
        if activity.type in ('xml','json','flat'):
            ctx.setdefault('formatCursors', {})
            from .data_formats import run_format_async
            return await run_format_async(activity.type,cfg.get('operation','parse'),cfg,ctx)
        if activity.type == 'call_task':
            project = ctx.get('project')
            if not project: raise RuntimeError('Call Sub Task requires project execution context')
            dynamic_value = self.resolve(cfg.get('dynamicTaskId'), ctx) if cfg.get('dynamicTaskId') not in (None, '') else None
            task_id = str(dynamic_value).strip() if dynamic_value not in (None, '') else str(cfg.get('taskId') or '').strip()
            task = find_subtask(project.tasks, task_id)
            if not task or task.kind != 'subtask': raise RuntimeError(f'Sub Task {task_id!r} was not found')
            mapped_values = self.map_input_values(activity.config.get('inputMappings', {}), ctx)
            mapped = self.unwrap_boundary(mapped_values, 'payload', ctx['last'] if isinstance(ctx['last'], dict) else {'value':ctx['last']})
            execution_state = {'activities': ctx.setdefault('activities', {}), 'tasks': ctx.setdefault('tasks', {})}
            invocation = self.run(task, mapped, ctx['resources'], ctx['properties'], project=project, execution_state=execution_state,
                                  jms_sender_scope=ctx.get('context', {}).get('debugSessionId') or ctx.get('context', {}).get('jmsSenderScope'))
            if cfg.get('spawn'):
                asyncio.create_task(invocation)
                return {'spawned': True, 'taskId': task.id}
            result = await invocation
            ctx.setdefault('logs', []).extend(result.logs)
            if result.status == 'failed': raise RuntimeError(result.logs[-1]['message'] if result.logs else f'Sub Task {task.name} failed')
            return result.output
        if activity.type in ('ems', 'jms', 'kafka', 'pubsub'):
            return await self.messaging(activity.type, cfg, ctx)
        if activity.type == 'java': return await self.java_worker(cfg, ctx['last'])
        if activity.type == 'python': return await self.python_worker(cfg, ctx['last'])
        raise RuntimeError(f'Unsupported activity type {activity.type}')

    async def messaging(self, technology: str, cfg: dict, ctx: dict):
        resource = ctx['resources'].get(cfg.get('resourceId'))
        if not resource or resource.type != technology:
            raise RuntimeError(f'{technology.upper()} activity requires a shared {technology.upper()} connection')
        rcfg = self.resolve(resource.config, ctx)
        execution_scope = str(ctx.get('context', {}).get('executionId') or ctx.get('context', {}).get('debugSessionId') or '')
        if technology in ('ems', 'jms'):
            execution_scope = str(ctx.get('context', {}).get('debugSessionId') or ctx.get('context', {}).get('jmsSenderScope') or execution_scope)
        if execution_scope: rcfg['_executionScope'] = execution_scope
        operation = cfg.get('operation', 'publish')
        destination = cfg.get('destination') or cfg.get('queue') or cfg.get('topic') or cfg.get('subscription') or 'default'
        broker_key = f'{technology}:{resource.id}:{destination}'
        payload = self.resolve(cfg.get('data', cfg.get('message', '${last}')), ctx)
        def mapping(value):
            if isinstance(value, dict): return value
            if isinstance(value, str) and value.strip():
                try: return json.loads(value)
                except ValueError: return {}
            return {}
        def kafka_bytes(value, serializer: str):
            kind = str(serializer or 'String').lower()
            if value is None: return None
            if kind == 'json': return json.dumps(value, separators=(',', ':')).encode()
            if kind == 'byte array':
                if isinstance(value, bytes): return value
                try: return base64.b64decode(value, validate=True) if isinstance(value, str) else bytes(value)
                except (ValueError, TypeError): return str(value).encode()
            if kind == 'avro schema':
                raise MinaFault('Avro Schema serialization requires the configured Schema Registry runtime', fault_type='KafkaSchemaRegistryException')
            if isinstance(value, (dict, list)): return json.dumps(value, separators=(',', ':')).encode()
            return value if isinstance(value, bytes) else str(value).encode()
        def kafka_value(raw, deserializer: str):
            if raw is None: return None
            kind = str(deserializer or 'String').lower()
            if kind == 'byte array': return base64.b64encode(raw).decode()
            if kind == 'json': return json.loads(raw.decode())
            if kind == 'avro schema': raise MinaFault('Avro Schema deserialization requires the configured Schema Registry runtime', fault_type='KafkaSchemaRegistryException')
            return raw.decode(errors='replace')
        attributes = {str(key): str(value) for key, value in {**mapping(cfg.get('dynamicProperties')), **mapping(cfg.get('attributes')), **mapping(cfg.get('headers'))}.items()}
        timestamp = log_timestamp()
        envelope = {'id': str(uuid.uuid4()), 'data': payload, 'attributes': attributes, 'destination': destination, 'technology': technology, 'timestamp': timestamp, 'key': cfg.get('key'), 'correlationId': cfg.get('correlationId'), 'replyTo': cfg.get('replyTo'), 'type': cfg.get('type'), 'priority': int(cfg.get('priority', 4) or 4), 'deliveryMode': cfg.get('deliveryMode', 'Persistent'), 'expiration': int(cfg.get('expiration', 0) or 0)}
        receive_ops = {'receive', 'subscribe', 'pull', 'get', 'queue_receiver', 'topic_subscriber', 'get_queue_message', 'receive_message', 'wait_request'}
        client_ack = str(cfg.get('acknowledgeMode', '')).lower() in ('client', 'manual', 'explicit client', 'explicit client dups ok') or cfg.get('acknowledge') is False
        # Existing projects that explicitly selected the local broker retain
        # that behavior. New shared connections omit mode and use the real
        # configured provider.
        if rcfg.get('mode') == 'memory':
            queue = self.messages.setdefault(broker_key, [])
            if operation in receive_ops:
                maximum = int(cfg.get('maxMessages', 1))
                received, queue[:] = queue[:maximum], queue[maximum:]
                for item in received:
                    if client_ack: item['ackId'] = self.register_acknowledgement(technology, item['id'])
                if technology in ('ems', 'jms'):
                    first = received[0] if received else {}
                    return {'body': first.get('data'), 'headers': {'JMSMessageID': first.get('id'), 'JMSTimestamp': first.get('timestamp'), 'JMSCorrelationID': first.get('correlationId'), 'JMSReplyTo': first.get('replyTo'), 'JMSType': first.get('type'), 'JMSPriority': first.get('priority'), 'JMSDeliveryMode': first.get('deliveryMode'), 'JMSExpiration': first.get('expiration'), 'JMSRedelivered': False}, 'properties': first.get('attributes', {}), 'ackId': first.get('ackId'), 'messages': received, 'count': len(received)}
                if technology == 'pubsub':
                    first = received[0] if received else {}
                    return {'MessageID': first.get('id'), 'PublishTime': first.get('timestamp'), 'Data': first.get('data'), 'Attributes': first.get('attributes', {}), 'AckID': first.get('ackId'), 'ackId': first.get('ackId'), 'messages': received, 'count': len(received)}
                return {'messages': received, 'count': len(received), 'destination': destination, 'ackId': received[0].get('ackId') if received else None, 'ackIds': [item['ackId'] for item in received if item.get('ackId')]}
            queue.append(envelope)
            if technology == 'pubsub': return {'TopicName': destination, 'MessageID': envelope['id'], 'messageId': envelope['id'], 'published': True}
            if technology in ('ems', 'jms'): return {'messageId': envelope['id'], 'destination': destination, 'timestamp': envelope['timestamp'], 'published': True}
            envelope.update({'topic': destination, 'partition': int(cfg.get('partitionId', 0) or 0), 'offset': len(queue)-1})
            return {'messageId': envelope['id'], 'topic': destination, 'partition': envelope['partition'], 'offset': envelope['offset'], 'timestamp': envelope['timestamp'], 'published': True}
        if technology in ('ems', 'jms'):
            # Authentication requirements belong to the provider. Blank
            # credentials also support factory/JNDI defaults and anonymous QA
            # brokers; do not reject them differently from direct archives.
            if str(rcfg.get('connectionFactoryType', 'Direct')).lower() == 'jndi':
                required = {'JNDI provider URL':rcfg.get('jndiProviderUrl'), 'JNDI connection factory':rcfg.get('connectionFactory')}
                if technology == 'jms': required['JNDI context factory'] = rcfg.get('jndiContextFactory')
            else:
                required = {'JMS connection URL':rcfg.get('serverUrl')}
            missing = [name for name, value in required.items() if not str(value or '').strip()]
            if missing: raise MinaFault(f"Required connection values are missing: {', '.join(missing)}", fault_type='JMSConnectionException')
            options = {**cfg, 'topic': 'topic' in operation or operation in ('publish', 'topic_subscriber'), 'clientAcknowledge': client_ack, 'properties': attributes}
            try:
                if operation == 'request_reply':
                    output = await asyncio.to_thread(execute_jms, rcfg, 'request', str(destination), payload, options)
                    body = output.get('body')
                    try: body = json.loads(body) if isinstance(body, str) else body
                    except ValueError: pass
                    return {**output, 'body': body, 'count': 1 if output.get('received') else 0, 'destination': destination}
                if operation in receive_ops:
                    self._jms_receivers_used = True
                    output = await asyncio.to_thread(execute_jms, rcfg, 'receive', str(destination), None, options)
                    if not output.get('received'):
                        return {'body': None, 'headers': {}, 'properties': {}, 'ackId': None, 'messages': [], 'count': 0}
                    records, ack_ids = [], []
                    for native in output.get('messages') or [output]:
                        body = native.get('body')
                        try: body = json.loads(body) if isinstance(body, str) else body
                        except ValueError: pass
                        message_id = native.get('headers', {}).get('JMSMessageID') or str(uuid.uuid4())
                        # Preserve the existing native Get confirmation contract.
                        ack_id = self.register_acknowledgement(technology, message_id) if client_ack else None
                        if ack_id: ack_ids.append(ack_id)
                        records.append({'id':message_id, 'data':body, 'attributes':native.get('properties', {}), 'ackId':ack_id})
                    return {**output, 'body': records[0]['data'], 'ackId': ack_ids[0] if ack_ids else None,
                            'ackIds': ack_ids, 'messages': records, 'count': len(records)}
                output = await self._publish_jms_isolated(rcfg, str(destination), payload, options)
                return {**output, 'destination':destination, 'timestamp':timestamp, 'published':True}
            except JavaBridgeError as exc:
                raise MinaFault(str(exc), fault_type='JMSConnectionException') from exc
        if technology == 'kafka':
            try: from confluent_kafka import Consumer, Producer, TopicPartition
            except ImportError: raise RuntimeError('External Kafka mode requires confluent-kafka')
            common = {'bootstrap.servers': rcfg['bootstrapServers'], 'client.id': rcfg.get('clientId') or 'mina', 'request.timeout.ms': int(rcfg.get('requestTimeoutMilliseconds', 30000) or 30000), 'reconnect.backoff.ms': int(rcfg.get('reconnectBackoffMilliseconds', 50) or 50), 'retry.backoff.ms': int(rcfg.get('retryBackoffMilliseconds', 100) or 100), **mapping(rcfg.get('clientProperties'))}
            if rcfg.get('securityProtocol'): common['security.protocol'] = rcfg['securityProtocol']
            sasl_mechanism = rcfg.get('saslMechanism') or ('PLAIN' if str(rcfg.get('authenticationType') or '').strip().lower() == 'api key / secret' else '')
            if sasl_mechanism: common['sasl.mechanism'] = sasl_mechanism
            if rcfg.get('username'): common['sasl.username'] = rcfg['username']
            if rcfg.get('password'): common['sasl.password'] = rcfg['password']
            if rcfg.get('sslCaLocation'): common['ssl.ca.location'] = rcfg['sslCaLocation']
            if rcfg.get('sslCertificateLocation'): common['ssl.certificate.location'] = rcfg['sslCertificateLocation']
            if rcfg.get('sslKeyLocation'): common['ssl.key.location'] = rcfg['sslKeyLocation']
            if rcfg.get('sslKeyPassword'): common['ssl.key.password'] = rcfg['sslKeyPassword']
            if rcfg.get('principalName'): common['sasl.kerberos.principal'] = rcfg['principalName']
            if operation in receive_ops:
                consumer_cfg = {**common, 'group.id': cfg.get('groupId') or rcfg.get('groupId', 'mina'), 'auto.offset.reset': cfg.get('autoOffsetReset', cfg.get('offsetReset', 'earliest')), 'enable.auto.commit': bool(cfg.get('enableAutoCommit', not client_ack)), 'fetch.min.bytes': int(cfg.get('fetchMinBytes', 1) or 1), 'max.poll.records': int(cfg.get('maxPollRecords', cfg.get('maxMessages', 1)) or 1), 'session.timeout.ms': int(cfg.get('sessionTimeoutMs', 45000) or 45000), 'heartbeat.interval.ms': int(cfg.get('heartbeatIntervalMs', 3000) or 3000), **mapping(cfg.get('additionalProperties'))}
                # This producer-only setting otherwise logs a native warning
                # for every newly opened consumer during polling workloads.
                consumer_cfg.pop('request.timeout.ms', None)
                def receive_kafka():
                    consumer = Consumer(consumer_cfg); topics = [item.strip() for item in str(destination).split(';') if item.strip()]
                    handed_off = False
                    try:
                        if self.as_bool(cfg.get('assignCustomPartition', False)):
                            partitions = []
                            for token in re.split(r'[,;]', str(cfg.get('partitionIds') or cfg.get('partitionId') or '0')):
                                token = token.strip()
                                if not token: continue
                                if '-' in token:
                                    start, end = token.split('-', 1); partitions.extend(range(int(start), int(end) + 1))
                                else: partitions.append(int(token))
                            offset = int(cfg.get('customOffset')) if str(cfg.get('seekPosition', '')).lower() == 'custom' and cfg.get('customOffset') not in (None, '') else -2 if str(cfg.get('seekPosition', '')).lower() == 'beginning' else -1
                            consumer.assign([TopicPartition(topic, partition, offset) for topic in topics for partition in partitions])
                        else: consumer.subscribe(topics)
                        messages, native_messages = [], []
                        timeout = max(0.0, float(cfg.get('timeout', 1)))
                        deadline = perf_counter() + timeout
                        for index in range(max(1, min(10000, int(cfg.get('maxMessages', 1))))):
                            message = consumer.poll(max(0.0, deadline - perf_counter()) if index == 0 else 0)
                            if message is None: break
                            error = message.error()
                            if error:
                                error_type = getattr(importlib.import_module('confluent_kafka'), 'KafkaError', None)
                                if error_type is not None and error.code() == error_type._PARTITION_EOF: break
                                raise RuntimeError(str(error))
                            if message:
                                data = kafka_value(message.value(), cfg.get('valueDeserializer', 'String'))
                                key = kafka_value(message.key(), cfg.get('keyDeserializer', 'String')) if message.key() else None
                                item = {'id':f'{message.topic()}:{message.partition()}:{message.offset()}','data':data,'key':key,'topic':message.topic(),'partition':message.partition(),'offset':message.offset(),'timestamp':message.timestamp()[1],'headers':dict(message.headers() or [])}
                                messages.append(item); native_messages.append(message)
                        if client_ack:
                            pending = {'count': len(native_messages)}
                            def kafka_confirm(native_message):
                                consumer.commit(message=native_message, asynchronous=False)
                                pending['count'] -= 1
                                if pending['count'] <= 0: consumer.close()
                            for item, native_message in zip(messages, native_messages):
                                item['ackId'] = self.register_acknowledgement('kafka', item['id'], lambda m=native_message: kafka_confirm(m))
                            handed_off = bool(native_messages)
                        return {'messages': messages, 'count': len(messages), 'ackId': messages[0].get('ackId') if messages else None, 'ackIds':[item['ackId'] for item in messages if item.get('ackId')]}
                    finally:
                        if not handed_off: consumer.close()
                return await asyncio.to_thread(receive_kafka)
            raw = kafka_bytes(payload, cfg.get('valueSerializer', 'String'))
            key = kafka_bytes(cfg.get('key'), cfg.get('keySerializer', 'String'))
            producer_cfg = {**common, 'acks': str(cfg.get('acks','all')), 'compression.type': cfg.get('compressionType','none'), 'retries': int(cfg.get('retries',3) or 0), 'batch.size': int(cfg.get('batchSize',16384) or 16384), 'linger.ms': int(cfg.get('lingerMs',0) or 0), 'queue.buffering.max.kbytes': max(1, int(cfg.get('bufferMemory',33554432) or 33554432) // 1024), 'message.max.bytes': int(cfg.get('maxRequestSize',1048576) or 1048576), 'enable.idempotence': bool(cfg.get('enableIdempotence',False)), 'socket.keepalive.enable': True, **mapping(cfg.get('additionalProperties'))}
            if cfg.get('transactionalId'): producer_cfg['transactional.id'] = cfg['transactionalId']

            def publish_kafka():
                """Buffer normally; wait only when the activity requests confirmation.

                Kafka throughput collapses when every record turns into a synchronous
                broker round trip.  The persistent librdkafka producer already owns a
                background I/O thread and batching queue, so ordinary publishes return
                after enqueueing.  Transactions and explicit confirmation retain the
                previous delivery-report semantics.
                """
                worker_started = perf_counter()
                transactional = bool(cfg.get('transactionalId'))
                wait_for_delivery = transactional or self.as_bool(cfg.get('waitForDelivery', False))
                producer, one_shot = self._publisher('kafka', producer_cfg, lambda: Producer(producer_cfg))
                producer_ready = perf_counter()
                delivered = {}; completed = threading.Event()
                # Cached, non-transactional confirmations must not occupy a send
                # worker for the entire broker round trip. Four slow deliveries
                # used to prevent even buffered sends to healthy brokers.
                async_confirmation = wait_for_delivery and not transactional and not one_shot
                def delivery(error, message):
                    if error: delivered['error'] = str(error)
                    else: delivered.update({'partition':message.partition(),'offset':message.offset(),'timestamp':message.timestamp()[1]})
                    completed.set()
                def produce_record(wait: bool):
                    producer.poll(0)
                    try:
                        producer.produce(destination, raw, key=key, partition=int(cfg['partitionId']) if cfg.get('assignCustomPartition') else -1, headers=list(attributes.items()), callback=delivery)
                    except BufferError:
                        # Apply bounded backpressure only when the local producer
                        # queue is full; do not impose a broker round trip normally.
                        producer.poll(.01)
                        producer.produce(destination, raw, key=key, partition=int(cfg['partitionId']) if cfg.get('assignCustomPartition') else -1, headers=list(attributes.items()), callback=delivery)
                    if not wait:
                        producer.poll(0)
                        return
                    timeout = max(.001, float(cfg.get('publishTimeout') or rcfg.get('requestTimeoutMilliseconds', 30000) / 1000))
                    deadline = perf_counter() + timeout
                    while not completed.is_set() and perf_counter() < deadline:
                        producer.poll(min(.01, max(0, deadline - perf_counter())))
                    if not completed.is_set(): raise TimeoutError(f'Kafka publish timed out after {timeout:g} seconds waiting for broker acknowledgement')
                try:
                    if transactional:
                        cache_key, operation_lock = self._publisher_operation_lock('kafka', producer_cfg)
                        with operation_lock:
                            if one_shot or cache_key not in self._initialized_transactional_publishers:
                                producer.init_transactions()
                                if not one_shot: self._initialized_transactional_publishers.add(cache_key)
                            producer.begin_transaction()
                            try:
                                produce_record(True)
                                producer.commit_transaction()
                            except Exception:
                                producer.abort_transaction()
                                raise
                    else:
                        produce_record(wait_for_delivery and not async_confirmation)
                finally:
                    if one_shot: producer.flush(3)
                if delivered.get('error'): raise RuntimeError(delivered['error'])
                result = {**delivered, 'queued': True, 'deliveryConfirmed': completed.is_set() and not delivered.get('error'),
                        'publisherQueueMs': round((worker_started - publish_started) * 1000, 3),
                        'producerSetupMs': round((producer_ready - worker_started) * 1000, 3),
                        'sendAndWaitMs': round((perf_counter() - producer_ready) * 1000, 3)}
                pending = (producer, completed, delivered, producer_ready) if async_confirmation else None
                return result, pending

            publish_started = perf_counter()
            delivered, pending = await self._publish_kafka_isolated(publish_kafka)
            if pending is not None:
                producer, completed, report, producer_ready = pending
                timeout = max(.001, float(cfg.get('publishTimeout') or float(rcfg.get('requestTimeoutMilliseconds') or 30000) / 1000))
                deadline = perf_counter() + timeout
                while not completed.is_set():
                    if perf_counter() >= deadline:
                        raise TimeoutError(f'Kafka publish timed out after {timeout:g} seconds waiting for broker acknowledgement; delivery may still occur')
                    # A native bounded poll wakes as soon as an ACK arrives.
                    # Timer sleeps here impose the Windows timer quantum on
                    # every confirmed record in a serial generated worker.
                    # Limit each executor wait to 1 ms, rather than occupying
                    # a send worker for the whole broker timeout; unrelated
                    # buffered publishes must continue during slow ACKs.
                    await self._publish_kafka_isolated(
                        lambda: producer.poll(min(.001, max(0, deadline - perf_counter()))))
                if report.get('error'): raise RuntimeError(report['error'])
                delivered.update(report)
                delivered['deliveryConfirmed'] = True
                delivered['sendAndWaitMs'] = round((perf_counter() - producer_ready) * 1000, 3)
            return {**envelope, **delivered, 'messageId':envelope['id'], 'topic':destination, 'published':True,
                    'publishLatencyMs': round((perf_counter() - publish_started) * 1000, 3)}
        if technology == 'pubsub':
            try: from google.cloud import pubsub_v1
            except ImportError: raise RuntimeError('External Google Pub/Sub mode requires google-cloud-pubsub')
            project_id = pubsub_project_id({**rcfg, 'projectId': cfg.get('projectId') or rcfg.get('projectId')})
            if operation in receive_ops:
                def receive_pubsub():
                    subscriber = create_pubsub_client(pubsub_v1.SubscriberClient, {**rcfg, 'projectId': cfg.get('projectId') or rcfg.get('projectId')})
                    handed_off = False
                    try:
                        path = str(destination) if str(destination).startswith('projects/') else subscriber.subscription_path(project_id, destination)
                        response = subscriber.pull(request={'subscription': path, 'max_messages': max(1,min(1000,int(cfg.get('maxMessages', 1))))}, timeout=float(cfg.get('receiveTimeout', cfg.get('timeout', 10))))
                        messages, native_ack_ids = [], []
                        for item in response.received_messages:
                            record = {'id':item.message.message_id,'messageId':item.message.message_id,'data':item.message.data.decode(errors='replace'),'attributes':dict(item.message.attributes),'publishTime':item.message.publish_time.isoformat() if item.message.publish_time else None}
                            messages.append(record); native_ack_ids.append(item.ack_id)
                        if client_ack:
                            pending = {'count': len(native_ack_ids)}
                            def pubsub_confirm(native_ack_id):
                                subscriber.acknowledge(request={'subscription':path,'ack_ids':[native_ack_id]})
                                pending['count'] -= 1
                                if pending['count'] <= 0: subscriber.close()
                            for record, native_ack_id in zip(messages, native_ack_ids):
                                record['ackId'] = self.register_acknowledgement('pubsub', record['id'], lambda ack=native_ack_id: pubsub_confirm(ack))
                            handed_off = bool(native_ack_ids)
                        else:
                            if response.received_messages: subscriber.acknowledge(request={'subscription':path,'ack_ids':[item.ack_id for item in response.received_messages]})
                        first = messages[0] if messages else {}
                        return {'MessageID':first.get('messageId'),'PublishTime':first.get('publishTime'),'Data':first.get('data'),'Attributes':first.get('attributes',{}),'AckID':first.get('ackId'),'ackId':first.get('ackId'),'messages':messages,'count':len(messages)}
                    finally:
                        if not handed_off: subscriber.close()
                return await asyncio.to_thread(receive_pubsub)
            publish_timeout = max(1.0, float(cfg.get('publishTimeout', 60) or 60))
            # Execution bookkeeping changes on every job and must never be
            # part of the publisher fingerprint. Including it prevented gRPC
            # channel reuse and paid TLS/authentication startup on each send.
            publish_config = {key: value for key, value in rcfg.items() if not str(key).startswith('_')}
            batch_delay = cfg.get('batchDelayThresholdMilliseconds')
            if batch_delay in (None, ''): batch_delay = rcfg.get('batchDelayThresholdMilliseconds')
            if batch_delay in (None, ''): batch_delay = 10
            publish_config.update({
                'projectId': cfg.get('projectId') or rcfg.get('projectId'),
                'enableMessageOrdering': bool(cfg.get('orderingKey')),
                'batchMaxMessages': int(cfg.get('batchMaxMessages') or rcfg.get('batchMaxMessages') or 100),
                'batchMaxBytes': int(cfg.get('batchMaxBytes') or rcfg.get('batchMaxBytes') or 1048576),
                'batchDelayThresholdMilliseconds': float(batch_delay),
                'flowControlMaxMessages': int(cfg.get('flowControlMaxMessages') or rcfg.get('flowControlMaxMessages') or 1000),
                'flowControlMaxBytes': int(cfg.get('flowControlMaxBytes') or rcfg.get('flowControlMaxBytes') or 10485760),
            })
            raw = payload if isinstance(payload, bytes) else (payload.encode() if isinstance(payload, str) else json.dumps(payload).encode())

            def publish_pubsub():
                """Enqueue on the persistent batched publisher by default."""
                publisher, one_shot = self._publisher('pubsub', publish_config, lambda: create_pubsub_client(pubsub_v1.PublisherClient, publish_config))
                try:
                    path = str(destination) if str(destination).startswith('projects/') else publisher.topic_path(project_id, destination)
                    try:
                        from google.api_core.retry import Retry
                        publish_future = publisher.publish(
                            path, raw, ordering_key=str(cfg.get('orderingKey', '')),
                            retry=Retry(deadline=publish_timeout),
                            timeout=publish_timeout, **attributes,
                        )
                        wait_for_delivery = self.as_bool(cfg.get('waitForDelivery', False)) or one_shot
                        # Google SDK futures can notify asyncio directly; do not
                        # occupy shared executor threads for network ACK waits.
                        asynchronous = wait_for_delivery and not one_shot and isinstance(publish_future, ConcurrentFuture)
                        message_id = publish_future if asynchronous else publish_future.result(timeout=publish_timeout + 2) if wait_for_delivery else None
                        if not wait_for_delivery:
                            # Consume asynchronous errors so the Google future
                            # cannot emit an unobserved-exception warning. The
                            # activity intentionally reports queued, not acked.
                            if hasattr(publish_future, 'add_done_callback'):
                                publish_future.add_done_callback(lambda future: future.exception())
                    except TimeoutError as exc:
                        raise RuntimeError(f'Google Pub/Sub publish timed out after {publish_timeout:g} seconds. Verify the topic, IAM permission, endpoint, proxy, and firewall settings.') from exc
                    return path, message_id, wait_for_delivery
                finally:
                    if one_shot:
                        try: publisher.stop()
                        except Exception: pass
                        try: publisher.transport.close()
                        except Exception: pass

            publish_started = perf_counter()
            path, provider_message_id, delivery_confirmed = await asyncio.to_thread(publish_pubsub)
            if isinstance(provider_message_id, ConcurrentFuture):
                waiter = asyncio.wrap_future(provider_message_id)
                waiter.add_done_callback(lambda done: None if done.cancelled() else done.exception())
                try: provider_message_id = await asyncio.wait_for(asyncio.shield(waiter), publish_timeout + 2)
                except asyncio.TimeoutError as exc:
                    raise RuntimeError('Google Pub/Sub publish confirmation timed out; delivery may still occur') from exc
            message_id = provider_message_id or envelope['id']
            return {**envelope, 'TopicName': path, 'MessageID': message_id, 'messageId': message_id,
                    'providerMessageId': provider_message_id, 'published': True, 'queued': True,
                    'deliveryConfirmed': delivery_confirmed,
                    'publishLatencyMs': round((perf_counter() - publish_started) * 1000, 3)}
        raise RuntimeError(f'Unsupported messaging technology {technology}')

    @staticmethod
    def assign_path(target: dict, path: str, value):
        parts = [part for part in str(path).split('.') if part]
        if not parts: return
        current = target
        for part in parts[:-1]:
            child = current.get(part)
            if not isinstance(child, dict): child = {}; current[part] = child
            current = child
        current[parts[-1]] = value

    def map_input_values(self, mappings: dict, ctx: dict) -> dict:
        mappings = mappings or {}
        copies = activity_occurrence_rules(mappings)
        children_by_id = {}
        roots_by_parent = {}
        for rule in copies:
            if rule.get('duplicateOf'):
                roots_by_parent.setdefault(rule.get('parentOccurrenceId'), []).append(rule)
            else:
                children_by_id.setdefault(rule['occurrenceId'], []).append(rule)
        def loop(expression):
            return isinstance(expression, dict) and expression.get('$rule') in ('for-each', 'for-each-group')

        def structure(expression):
            return loop(expression) or isinstance(expression, dict) and expression.get('$rule') == 'copy-of'

        def scope_context(context, source, item, group):
            scoped = {**context, 'vars': {**context.get('vars', {}), 'current': item, 'currentGroup': group}}
            match = re.fullmatch(r'\$\{([^}]+)\}', str(source or ''))
            if not match: return scoped
            parts = match[1].split('.')
            if parts[0] not in ('input', 'last', 'vars', 'properties', 'activities', 'context', 'tasks', 'attributes'):
                parts = ['activities', parts[0], 'output', *parts[1:]]
            # Copy only dictionaries on the source path; never mutate process data.
            original, current = context, scoped
            for part in parts[:-1]:
                child = original.get(part, {}) if isinstance(original, dict) else {}
                current[part] = dict(child) if isinstance(child, dict) else {}
                current, original = current[part], child
            current[parts[-1]] = item
            return scoped

        def evaluate(entries, context, prefix='', owner=None):
            result = {}
            parents = [path for path, expression in entries.items() if structure(expression)]
            roots = [path for path in parents if not any(path.startswith(parent + '.') for parent in parents if parent != path)]
            def render(path, expression, children, scope):
                full = prefix + path + '.'
                if loop(expression) and (children or expression.get('mapChildren') or any(
                        rule['target'].startswith(full) for rule in roots_by_parent.get(scope, ()))):
                    source = expression.get('select') or expression.get('source')
                    values = self.resolve(source, context)
                    values = values if isinstance(values, list) else ([] if values in (None, '') else [values])
                    groups = [[item] for item in values]
                    if expression['$rule'] == 'for-each-group':
                        grouped = {}
                        for item in values:
                            key = item
                            for part in str(expression.get('groupBy') or '').split('.'):
                                if part: key = key.get(part) if isinstance(key, dict) else None
                            grouped.setdefault(json.dumps(key, sort_keys=True, default=str), []).append(item)
                        groups = list(grouped.values())
                    return True, [evaluate(children, scope_context(context, source, group[0], group), full, scope) for group in groups]
                return self.evaluate_mapping(expression, context)

            for path, expression in entries.items():
                if any(path.startswith(parent + '.') for parent in roots): continue
                children = {key[len(path) + 1:]: value for key, value in entries.items() if key.startswith(path + '.')} if loop(expression) else {}
                include, value = render(path, expression, children, owner)
                if include: self.assign_path(result, path, copy.deepcopy(value))
            for rule in roots_by_parent.get(owner, ()):
                if not rule.get('enabled', True) or not rule['target'].startswith(prefix) or not (rule.get('select') or rule.get('source')): continue
                path = rule['target'][len(prefix):]
                if not path or any(path.startswith(parent + '.') for parent in roots): continue
                full = rule['target'] + '.'
                children = {child['target'][len(full):]: {**child, '$rule':child.get('operator') or 'direct'}
                            for child in children_by_id.get(rule['occurrenceId'], ()) if child['target'].startswith(full) and child.get('enabled', True)}
                include, values = render(path, {**rule, '$rule':rule.get('operator') or 'for-each'}, children, rule['occurrenceId'])
                if not include or not values: continue
                previous = get_path(result, path)
                if isinstance(previous, dict) and previous and all(str(key).isdigit() for key in previous):
                    previous = [previous[key] for key in sorted(previous, key=int)]
                if not isinstance(previous, list): previous = [] if previous is None else [previous]
                self.assign_path(result, path, [*previous, *copy.deepcopy(values if isinstance(values, list) else [values])])
            return result
        return evaluate({path: value for path, value in mappings.items() if path != INPUT_OCCURRENCES}, ctx)

    def mapping_value(self, expression, ctx):
        literal, parsed = parse_literal(expression)
        return literal if parsed else self.resolve(expression, ctx)

    def evaluate_mapping(self, expression, ctx) -> tuple[bool, Any]:
        """Evaluate the structured mapping statements used by every activity Input tab."""
        if not isinstance(expression, dict) or '$rule' not in expression:
            literal, parsed = parse_literal(expression)
            if parsed: return True, literal
            return True, self.mapping_value(expression, ctx)
        rule = str(expression.get('$rule', '')).lower()
        source_expression = expression.get('select') or expression.get('source')
        if rule == 'if':
            if not self.condition(expression.get('condition', ''), ctx): return False, None
            return True, self.mapping_value(source_expression, ctx)
        if rule == 'when-otherwise':
            if self.condition(expression.get('condition', ''), ctx): return True, self.mapping_value(source_expression, ctx)
            return True, self.mapping_value(expression.get('otherwise'), ctx)
        if rule == 'choose':
            branches = expression.get('whens') or []
            if not branches and isinstance(expression.get('source'), str):
                try: branches = json.loads(expression['source'])
                except (TypeError, ValueError, json.JSONDecodeError): branches = []
            for branch in branches:
                if self.condition(branch.get('condition', ''), ctx): return True, self.mapping_value(branch.get('source'), ctx)
            return True, self.mapping_value(expression.get('otherwise'), ctx)
        source = self.mapping_value(source_expression, ctx)
        if rule in ('for-each', 'copy-of'):
            values = source if isinstance(source, list) else ([] if source in (None, '') else [source])
            return True, values
        if rule == 'for-each-group':
            values = source if isinstance(source, list) else ([] if source in (None, '') else [source])
            group_path = str(expression.get('groupBy') or '').strip('.')
            groups: dict[str, list[Any]] = {}
            for item in values:
                current = item
                for part in group_path.split('.') if group_path else []:
                    current = current.get(part) if isinstance(current, dict) else None
                groups.setdefault(str(current), []).append(item)
            return True, [{'key': key, 'items': items} for key, items in groups.items()]
        return True, source

    @staticmethod
    def unwrap_boundary(mapped: dict, wrapper: str, fallback):
        if not mapped: return fallback
        return mapped[wrapper] if set(mapped) == {wrapper} else mapped

    @staticmethod
    def split_function_args(raw: str) -> list[str]:
        return _function_arguments(raw)

    def evaluate_function_expression(self, expression: str, ctx: dict, variables: dict | None = None, depth: int = 0):
        if depth > 32: raise RuntimeError('Custom function recursion exceeded 32 calls')
        variables = variables or {}
        text = expression.strip()
        if text in variables: return variables[text]
        literal, parsed = parse_literal(text)
        if parsed: return literal
        if len(text) >= 2 and text[0] == text[-1] and text[0] in ('"', "'"):
            return ast.literal_eval(text)
        if re.fullmatch(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?', text): return float(text) if any(char in text for char in '.eE') else int(text)
        if text.lower() in ('true()', 'true'): return True
        if text.lower() in ('false()', 'false'): return False
        if text.lower() in ('null', '()'): return None
        call = re.fullmatch(r'([\w:-]+)\((.*)\)', text, re.S)
        if not call: return self.resolve(text, ctx)
        name = call.group(1); args = [self.evaluate_function_expression(item, ctx, variables, depth + 1) for item in self.split_function_args(call.group(2))]
        if name in ('xpath', 'xpath1', 'xpath2'):
            from .mapper_xml import parse_xml, xpath_value, xpath_context_source
            if not 1 <= len(args) <= 2: raise ValueError('xpath expects an expression and optional XML source')
            source = args[1] if len(args)>1 else xpath_context_source(ctx.get('last'))
            return xpath_value(parse_xml(source),args[0],'2.0' if name=='xpath2' else '1.0',{},properties=ctx.get('properties'))
        if name.startswith('custom:'):
            function_name = name.split(':', 1)[1]
            project = ctx.get('project')
            definition = next((item for item in (getattr(project, 'custom_functions', []) if project else []) if item.name == function_name), None)
            if not definition: raise RuntimeError(f'Custom function {function_name!r} was not found in this project')
            if len(args) != len(definition.parameters): raise RuntimeError(f'Custom function {function_name!r} expects {len(definition.parameters)} arguments, received {len(args)}')
            bindings = dict(zip(('$' + parameter for parameter in definition.parameters), args))
            return self.evaluate_function_expression(definition.expression, ctx, bindings, depth + 1)
        try: return apply_function(name, args[0] if args else None, args[1:])
        except (TypeError, ValueError, IndexError) as exc: raise RuntimeError(str(exc)) from exc

    def resolve(self, value, ctx):
        if isinstance(value, str) and value.startswith('${attributes') and value.endswith('}'):
            path = value[2:-1]
            if path == 'attributes' or path.startswith('attributes.'):
                current = ctx.get('attributes', {})
                for part in path.split('.')[1:]: current = current.get(part, '') if isinstance(current, dict) else ''
                return current
        if isinstance(value, dict): return {key: copy.deepcopy(item) if key in ('openApiDocument','openApiReferenceDocuments') and not (isinstance(item,str) and re.fullmatch(r'\$\{[^}]+\}',item)) else self.resolve(item, ctx) for key, item in value.items()}
        if isinstance(value, list): return [self.resolve(item, ctx) for item in value]
        if isinstance(value, str) and value.startswith('__mina_constant__:'):
            try: return json.loads(value.split(':', 1)[1])
            except (TypeError, ValueError, json.JSONDecodeError): return value
        if value == '${last}': return ctx['last']
        if value == '${input}': return ctx['input']
        if value == '${properties}': return ctx['properties']
        if value == '${vars}': return ctx['vars']
        if isinstance(value, str) and value.startswith('${last.') and value.endswith('}'):
            current = ctx['last']
            for part in value[7:-1].split('.'): current = current.get(part, '') if isinstance(current, dict) else ''
            return current
        if isinstance(value, str) and value.startswith('${input.'):
            current = ctx['input']
            for part in value[8:-1].split('.'): current = current.get(part, '') if isinstance(current, dict) else ''
            return current
        if isinstance(value, str) and value.startswith('${vars.'):
            current = ctx['vars']
            for part in value[7:-1].split('.'): current = current.get(part, '') if isinstance(current, dict) else ''
            return current
        if isinstance(value, str) and value.startswith('${properties.') and value.endswith('}'):
            return ctx['properties'].get(value[13:-1], '')
        if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
            path = value[2:-1].split('.')
            if path[0] in ('activities', 'tasks', 'context'):
                current = ctx.get(path[0], {})
                for part in path[1:]:
                    if isinstance(current, dict): current = current.get(part, '')
                    elif isinstance(current, list) and part.isdigit() and int(part) < len(current): current = current[int(part)]
                    else: return ''
                return current
            # Activity IDs are normalized display names, so mappings expose a
            # direct, readable output path: ${IDoc-Parser.SAPIDoc...}.
            record = ctx.get('activities', {}).get(path[0])
            if isinstance(record, dict):
                current = record.get('output', '')
                for part in path[1:]:
                    if isinstance(current, dict): current = current.get(part, '')
                    elif isinstance(current, list) and part.isdigit() and int(part) < len(current): current = current[int(part)]
                    else: return ''
                return current
        if isinstance(value, str) and re.fullmatch(r'[\w:-]+\(.*\)', value.strip(), re.S):
            return self.evaluate_function_expression(value, ctx)
        if isinstance(value, str) and '${properties.' in value:
            return re.sub(r'\$\{properties\.([^}]+)\}', lambda match: str(ctx['properties'].get(match.group(1), '')), value)
        if isinstance(value, str) and len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            try: return ast.literal_eval(value)
            except (SyntaxError, ValueError): return value[1:-1]
        return value

    def condition(self, expression, ctx):
        def operand(text):
            reference = re.fullmatch(r'\$\{([^}]+)\}', text)
            if reference:
                path = reference.group(1)
                if path.split('.')[0] in ('input', 'last', 'vars', 'properties', 'activities', 'tasks', 'context', 'attributes'):
                    return get_path(ctx, path)
            return self.evaluate_function_expression(text, ctx)
        return evaluate_condition(expression, operand)

    def jdbc(self, cfg, ctx):
        resource = ctx['resources'].get(cfg.get('resourceId'))
        if not resource: raise RuntimeError('JDBC activity requires a valid shared JDBC resource')
        rcfg, operation = self.resolve(resource.config, ctx), cfg.get('operation', 'query')
        if rcfg.get('driver', 'sqlite') != 'sqlite':
            raise RuntimeError(f"Driver {rcfg.get('driver')} requires its optional Python database adapter")
        conn = sqlite3.connect(self.resolve(rcfg.get('url', 'integration.db'), ctx)); conn.row_factory = sqlite3.Row
        try:
            parameters = {name: self.resolve(expression, ctx) for name, expression in cfg.get('parameters', {}).items()}
            sql = self.resolve(cfg.get('sql', ''), ctx)
            if operation == 'truncate':
                if sql.strip().lower().startswith('truncate '): sql = 'DELETE FROM ' + sql.strip().split()[-1]
            if operation == 'call': raise RuntimeError('Stored procedures are not supported by SQLite; select a server JDBC driver')
            cursor = conn.execute(sql, parameters)
            if operation in ('query', 'dynamic') and cursor.description:
                return {'rows': [dict(row) for row in cursor.fetchall()], 'rowCount': cursor.rowcount}
            conn.commit(); return {'rowCount': cursor.rowcount, 'lastInsertId': cursor.lastrowid}
        finally: conn.close()

    @staticmethod
    def read_excel(cfg: dict) -> dict:
        file_path = Path(str(cfg.get('filePath') or cfg.get('path') or ''))
        if not file_path.is_file(): raise FileNotFoundError(f'Excel workbook not found: {file_path}')
        def assign(target: dict, path: str, value):
            parts = [part.strip() for part in str(path).split('.') if part.strip()]
            current = target
            for part in parts[:-1]: current = current.setdefault(part, {})
            if parts: current[parts[-1]] = value
        if file_path.suffix.lower() == '.xls':
            try: import xlrd
            except ImportError as exc: raise RuntimeError('Legacy .xls workbooks require xlrd') from exc
            workbook = xlrd.open_workbook(file_path)
            requested = str(cfg.get('sheetName') or '').strip(); names = [requested] if requested else workbook.sheet_names()
            header_row = max(1, int(cfg.get('headerRow') or 1)) - 1; start_row = max(header_row + 1, int(cfg.get('startRow') or header_row + 2) - 1)
            maximum = max(0, int(cfg.get('maximumRows') or 0)); nested = bool(cfg.get('nestedHeaders', True)); sheets = []
            for name in names:
                sheet = workbook.sheet_by_name(name); headers = [str(sheet.cell_value(header_row, col)).strip() or f'column{col + 1}' for col in range(sheet.ncols)]; rows = []
                for row_index in range(start_row, sheet.nrows):
                    if maximum and len(rows) >= maximum: break
                    values = [sheet.cell_value(row_index, col) for col in range(sheet.ncols)]
                    if cfg.get('skipBlankRows', True) and all(value in (None, '') for value in values): continue
                    record = {}
                    for key, value in zip(headers, values): assign(record, key, value) if nested and '.' in key else record.__setitem__(key, value)
                    rows.append(record)
                sheets.append({'name': name, 'index': workbook.sheet_names().index(name), 'rowCount': len(rows), 'columnCount': len(headers), 'headers': headers, 'rows': rows})
            return {'workbook': {'fileName': file_path.name, 'sheetCount': len(sheets), 'sheets': sheets}, 'sheets': sheets}
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise RuntimeError('Excel activities require openpyxl') from exc
        workbook = load_workbook(file_path, read_only=True, data_only=bool(cfg.get('dataOnly', True)))
        try:
            requested = str(cfg.get('sheetName') or '').strip()
            names = [requested] if requested else list(workbook.sheetnames)
            header_row = max(1, int(cfg.get('headerRow') or 1)); start_row = max(header_row + 1, int(cfg.get('startRow') or header_row + 1))
            maximum = max(0, int(cfg.get('maximumRows') or 0)); nested = bool(cfg.get('nestedHeaders', True)); sheets = []
            for index, name in enumerate(names):
                if name not in workbook.sheetnames: raise ValueError(f'Worksheet {name!r} does not exist')
                sheet = workbook[name]
                headers = [str(cell.value).strip() if cell.value not in (None, '') else f'column{cell.column}' for cell in sheet[header_row]]
                rows = []
                for values in sheet.iter_rows(min_row=start_row, values_only=True):
                    if maximum and len(rows) >= maximum: break
                    if cfg.get('skipBlankRows', True) and all(value is None for value in values): continue
                    record = {}
                    for key, value in zip(headers, values):
                        if nested and '.' in key: assign(record, key, value)
                        else: record[key] = value
                    rows.append(record)
                sheets.append({'name': name, 'index': workbook.sheetnames.index(name), 'rowCount': len(rows), 'columnCount': len(headers), 'headers': headers, 'rows': rows})
            return {'workbook': {'fileName': file_path.name, 'sheetCount': len(sheets), 'sheets': sheets}, 'sheets': sheets}
        finally: workbook.close()

    def ftp(self, cfg, ctx, *, cancel=None):
        from .transfer import transfer
        return transfer('ftp', cfg.get('operation'), cfg, ctx.get('last'),cancel=cancel)

    def sftp(self, cfg, ctx, *, cancel=None):
        from .transfer import transfer
        return transfer('sftp', cfg.get('operation'), cfg, ctx.get('last'),cancel=cancel)


    async def java_worker(self, cfg, payload):
        command = cfg.get('command') or os.getenv('JAVA_WORKER_COMMAND')
        if command:
            proc = await asyncio.create_subprocess_shell(command, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try:
                out, err = await proc.communicate(json.dumps({'className': cfg.get('className'), 'method': cfg.get('method'), 'payload': payload}).encode())
            except asyncio.CancelledError:
                if proc.returncode is None:
                    proc.terminate()
                    try: await asyncio.wait_for(proc.wait(), timeout=1)
                    except asyncio.TimeoutError:
                        proc.kill(); await proc.wait()
                raise
            if proc.returncode: raise RuntimeError(err.decode() or 'Java worker failed')
            return json.loads(out.decode())
        class_name, method = str(cfg.get('className') or '').strip(), str(cfg.get('method') or '').strip()
        if not class_name or not method: raise RuntimeError('Java Invoke requires a class name and method')
        artifact = Path(str(cfg.get('artifactPath') or '')).expanduser()
        source = str(cfg.get('sourceCode') or '')
        parameters = cfg.get('parameters')
        if not isinstance(parameters, list): parameters = [cfg.get('payload', payload)]
        helper = '''import java.lang.reflect.*; public class MinaInvoker { public static void main(String[] a) throws Exception { Class<?> c=Class.forName(a[0]); Method found=null; for(Method m:c.getMethods()) if(m.getName().equals(a[1])&&m.getParameterCount()==a.length-2){found=m;break;} if(found==null) throw new NoSuchMethodException(a[0]+"."+a[1]); Object[] v=new Object[found.getParameterCount()]; Class<?>[] t=found.getParameterTypes(); for(int i=0;i<v.length;i++){String s=a[i+2]; v[i]=t[i]==String.class?s:t[i]==int.class||t[i]==Integer.class?Integer.valueOf(s):t[i]==long.class||t[i]==Long.class?Long.valueOf(s):t[i]==double.class||t[i]==Double.class?Double.valueOf(s):t[i]==boolean.class||t[i]==Boolean.class?Boolean.valueOf(s):s;} Object target=Modifier.isStatic(found.getModifiers())?null:c.getDeclaredConstructor().newInstance(); Object out=found.invoke(target,v); if(out!=null) System.out.print(out); }}'''
        with tempfile.TemporaryDirectory(prefix='mina-java-') as folder:
            root = Path(folder); (root / 'MinaInvoker.java').write_text(helper, encoding='utf-8')
            classpath = str(root)
            compile_inputs = [str(root / 'MinaInvoker.java')]
            if source:
                java_file = root / f'{class_name.rsplit(".", 1)[-1]}.java'; java_file.write_text(source, encoding='utf-8'); compile_inputs.append(str(java_file))
            elif artifact.exists() and artifact.suffix.lower() == '.java': compile_inputs.append(str(artifact)); classpath += os.pathsep + str(artifact.parent)
            elif artifact.exists() and artifact.suffix.lower() == '.jar': classpath += os.pathsep + str(artifact)
            elif artifact.exists() and artifact.suffix.lower() == '.class': classpath += os.pathsep + str(artifact.parent)
            elif not artifact.exists(): raise RuntimeError('Java Invoke requires an existing JAR/class/source artifact or inline source')
            compiler = await asyncio.create_subprocess_exec('javac', '-cp', classpath, '-d', str(root), *compile_inputs, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try: _, compile_error = await compiler.communicate()
            except asyncio.CancelledError:
                if compiler.returncode is None: compiler.kill(); await compiler.wait()
                raise
            if compiler.returncode: raise RuntimeError(f'Java compilation failed: {compile_error.decode().strip()}')
            args = [json.dumps(value, separators=(',', ':')) if isinstance(value, (dict, list)) else str(value) for value in parameters]
            process = await asyncio.create_subprocess_exec('java', '-cp', classpath, 'MinaInvoker', class_name, method, *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try: out, err = await asyncio.wait_for(process.communicate(), timeout=float(cfg.get('timeout') or 60))
            except asyncio.CancelledError:
                if process.returncode is None:
                    process.terminate()
                    try: await asyncio.wait_for(process.wait(), timeout=1)
                    except asyncio.TimeoutError:
                        process.kill(); await process.wait()
                raise
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                raise RuntimeError('Java method invocation timed out')
            if process.returncode: raise RuntimeError(err.decode().strip() or 'Java method invocation failed')
            value = out.decode().strip()
            try: value = json.loads(value)
            except ValueError: pass
            return {'methodReturnValue': value, 'className': class_name, 'method': method}

    async def python_worker(self, cfg, payload):
        def invoke():
            function_name = str(cfg.get('function') or '').strip()
            if not function_name: raise RuntimeError('Python Invoke requires a function name')
            source, artifact = str(cfg.get('sourceCode') or ''), Path(str(cfg.get('artifactPath') or '')).expanduser()
            module_name = str(cfg.get('moduleName') or artifact.stem or 'mina_inline')
            if source:
                namespace = {'__name__': module_name}; exec(compile(source, f'<{module_name}>', 'exec'), namespace); function = namespace.get(function_name)
            elif artifact.suffix.lower() == '.py' and artifact.exists():
                spec = importlib.util.spec_from_file_location(module_name, artifact)
                if not spec or not spec.loader: raise RuntimeError(f'Cannot load Python module {artifact}')
                module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); function = getattr(module, function_name, None)
            elif artifact.exists():
                sys.path.insert(0, str(artifact));
                try: module = __import__(module_name, fromlist=[function_name]); function = getattr(module, function_name, None)
                finally: sys.path.pop(0)
            else: raise RuntimeError('Python Invoke requires an existing .py/package artifact or inline source')
            if not callable(function): raise RuntimeError(f'Python function {module_name}.{function_name} was not found')
            parameters = cfg.get('parameters')
            if isinstance(parameters, list): result = function(*parameters)
            elif isinstance(parameters, dict): result = function(**parameters)
            else: result = function(cfg.get('payload', payload))
            return {'result': result, 'module': module_name, 'function': function_name}
        return await asyncio.wait_for(asyncio.to_thread(invoke), timeout=float(cfg.get('timeout') or 60))
