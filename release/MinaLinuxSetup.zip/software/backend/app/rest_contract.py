"""Local OpenAPI 3 / Swagger 2 operation contracts. Never fetch remote refs."""
from __future__ import annotations
import copy, json, re, urllib.parse
from .http_contracts import bundle_document, schema_errors

def operation_config(config, *, document=None):
    supplied=config.get('openApiDocument')
    if not supplied:return dict(config)
    supplied=document if document is not None else bundle_document(supplied,config)
    if not isinstance(supplied,dict) or not (str(supplied.get('openapi','')).startswith('3.') or supplied.get('swagger')=='2.0'):raise ValueError('Provide an OpenAPI 3 or Swagger 2 JSON document')
    selected=str(config.get('operationId') or '')
    if not selected:raise ValueError('OpenAPI operation ID is required')
    def dereference(value):
        seen=set()
        while isinstance(value,dict) and '$ref' in value:
            ref=value['$ref']
            if not isinstance(ref,str) or not ref.startswith('#/') or ref in seen:raise ValueError('Only acyclic local OpenAPI references are supported')
            seen.add(ref);value=supplied
            for part in ref[2:].split('/'):
                value=value[part.replace('~1','/').replace('~0','~')]
        return value
    matches=[]
    for path,definition in (supplied.get('paths') or {}).items():
        definition=dereference(definition)
        for method,operation in definition.items():
            if method.lower() in ('get','post','put','patch','delete','head','options','trace') and isinstance(operation,dict) and operation.get('operationId')==selected:matches.append((path,method.upper(),operation,definition))
    if len(matches)!=1:raise ValueError('OpenAPI operation ID must identify exactly one operation')
    path,method,operation,path_item=matches[0];cfg=dict(config)
    if config.get('operation') == 'receiver':
        requirements = operation.get('security', supplied.get('security', []))
        schemes = supplied.get('securityDefinitions') if supplied.get('swagger') == '2.0' else (supplied.get('components') or {}).get('securitySchemes')
        cfg['_restSecurity'] = security_requirements(requirements, schemes or {}, dereference)
    cfg['_restOperation']=copy.deepcopy(operation)
    cfg['_restOperation']['requestBody']=copy.deepcopy(dereference(operation.get('requestBody') or {}))
    cfg['_restOperation']['responses']={str(code):copy.deepcopy(dereference(value)) for code,value in (operation.get('responses') or {}).items()}
    cfg.update(method=method,methods=method,path=path)
    def wrapped(schema):
        result=copy.deepcopy(dereference(schema))
        if not isinstance(result,dict):return result
        def compatibility(node):
            if isinstance(node,list):return [compatibility(item) for item in node]
            if not isinstance(node,dict):return node
            node={key:compatibility(item) for key,item in node.items()}
            if node.get('nullable') and isinstance(node.get('type'),str):node['type']=[node['type'],'null']
            for exclusive,bound in [('exclusiveMinimum','minimum'),('exclusiveMaximum','maximum')]:
                if isinstance(node.get(exclusive),bool):
                    enabled=node.pop(exclusive)
                    if enabled and bound in node:node[exclusive]=node.pop(bound)
            return node
        result=compatibility(result)
        return {**result, 'components':compatibility(copy.deepcopy(supplied.get('components') or {})),'definitions':compatibility(copy.deepcopy(supplied.get('definitions') or {})),'x-mina-refs':compatibility(copy.deepcopy(supplied.get('x-mina-refs') or {}))}
    def media(content,preferred=''):
        if not content:return '',None
        name=preferred if preferred in content else next((key for key in content if 'json' in key),next(iter(content)))
        return name,wrapped(dereference(content[name]).get('schema',{}))
    request=dereference(operation.get('requestBody') or {})
    headers=cfg.get('headers') or {}
    preferred=cfg.get('contentType') or (next((value for key,value in headers.items() if key.lower()=='content-type'),'') if isinstance(headers,dict) else '')
    preferred=str(preferred).split(';',1)[0].strip().lower()
    content_type,schema=media(request.get('content') or {},preferred)
    cfg['_restRequestSchemas']={name:wrapped(dereference(definition).get('schema',{})) for name,definition in (request.get('content') or {}).items()}
    multipart = dereference((request.get('content') or {}).get('multipart/form-data', {}))
    cfg['_restMultipartEncoding'] = {
        name: {**settings, 'headers': {
            header: {**dereference(definition), 'schema': wrapped(dereference(definition).get('schema') or {})}
            for header, definition in (settings.get('headers') or {}).items()
        }}
        for name, settings in (multipart.get('encoding') or {}).items()
    }
    cfg['_explicitRequestSchema']=config.get('_explicitRequestSchema',config.get('requestSchema') not in (None,''))
    # An operation parameter overrides the path-level parameter of the same name/location.
    parameters=list({(p.get('in'),p.get('name')):p for p in (dereference(value) for value in [*(path_item.get('parameters') or []),*(operation.get('parameters') or [])])}.values())
    parameters=[{**p,'schema':wrapped(p.get('schema') or {key:value for key,value in p.items() if key in ('type','items','enum','minimum','maximum','pattern','minLength','maxLength')})} for p in parameters]
    if supplied.get('swagger')=='2.0':
        parameters=[{**p,'collectionFormat':p.get('collectionFormat','csv'),'explode':p.get('collectionFormat')=='multi'} if (p.get('schema') or {}).get('type')=='array' else p for p in parameters]
    body=next((value for value in parameters if value.get('in')=='body'),None)
    if body:content_type=(operation.get('consumes') or supplied.get('consumes') or ['application/json'])[0];schema=wrapped(body.get('schema') or {})
    if content_type:cfg['contentType']=content_type
    if schema is not None and cfg.get('requestSchema') in (None,''):cfg['requestSchema']=schema
    cfg['_requiredBody']=bool(request.get('required') or body and body.get('required'))
    cfg['_restParameters']=[value for value in parameters if value.get('in') in ('path','query','header','cookie','formData')]
    responses={};response_content={}
    for code,response in (operation.get('responses') or {}).items():
        response=dereference(response)
        response_content[str(code).upper() if str(code)!='default' else 'default']={name:wrapped(dereference(definition).get('schema',{})) for name,definition in (response.get('content') or {}).items()}
        response_type,response_schema=media(response.get('content') or {})
        if response.get('schema'):response_schema=wrapped(response['schema']);response_type=(operation.get('produces') or supplied.get('produces') or ['application/json'])[0]
        if response_schema is not None:responses[str(code).upper() if str(code)!='default' else 'default']=response_schema
        if response_type and str(code).startswith('2'):cfg.setdefault('responseType',response_type);cfg.setdefault('accept',response_type)
    cfg['_restResponseSchemas']=responses
    cfg['_restResponseContentSchemas']=response_content
    codes=[str(code) for code in (operation.get('responses') or {}) if str(code).startswith('2')]
    if cfg.get('successStatusCodes') in (None, ''):
        cfg['successStatusCodes']=','.join(codes) if codes and all(key.isdigit() for key in codes) else '200-299'
    servers=operation.get('servers') or path_item.get('servers') or supplied.get('servers') or []
    if servers:
        server=servers[0];url=str(server.get('url') or '')
        for key,value in (server.get('variables') or {}).items():url=url.replace('{'+key+'}',str(value.get('default') or ''))
    else:url=((supplied.get('schemes') or ['https'])[0]+'://'+str(supplied.get('host') or '')+str(supplied.get('basePath') or '')) if supplied.get('host') else ''
    if cfg.get('callbackDelivery'):
        target = str(cfg.get('callbackUrl') or '')
        parsed = urllib.parse.urlsplit(target)
        origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, '', '', ''))
        allowed = str(cfg.get('callbackAllowedOrigins') or '').replace(',', ' ').split()
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment or origin not in allowed:
            raise ValueError('Callback URL must use an explicitly allowed HTTPS origin')
        cfg.update(url=target, basePath='', defaultConfidentiality=True, followRedirects=False)
    elif cfg.get('operation')!='receiver':
        base=str(cfg.get('baseUrl') or url)
        if not base:raise ValueError('OpenAPI invocation requires a server URL or HTTP connection base URL')
        cfg['url']=base.rstrip('/')+path;cfg['basePath']=''
    elif url and not cfg.get('basePath'):cfg['basePath']=urllib.parse.urlsplit(url).path
    return cfg

def _primitive(value, schema):
    kind=schema.get('type')
    if value is None:return None
    if kind=='integer':
        if isinstance(value,bool) or not __import__('re').fullmatch(r'-?\d+',str(value)):raise ValueError()
        return int(value)
    if kind=='number':
        import math
        converted=float(value)
        if isinstance(value,bool) or not math.isfinite(converted):raise ValueError()
        return converted
    if kind=='boolean':
        if str(value).lower() not in ('true','false'):raise ValueError()
        return str(value).lower()=='true'
    return value

def form_properties(cfg, content_type):
    from .http_contracts import request_schema
    root=request_schema(cfg,content_type)
    if not isinstance(root,dict):return {}
    def resolve(schema):
        seen=set()
        while isinstance(schema,dict) and str(schema.get('$ref','')).startswith('#/'):
            reference=schema['$ref']
            if reference in seen:break
            seen.add(reference);schema=root
            for part in reference[2:].split('/'):schema=schema[part.replace('~1','/').replace('~0','~')]
        return schema if isinstance(schema,dict) else {}
    return {name: {**resolve(schema), 'items': resolve(resolve(schema).get('items', {}))}
            for name, schema in resolve(root).get('properties', {}).items()}


def typed_form_body(cfg,body,content_type):
    """Decode primitive form fields using their contract types before validation."""
    if str(content_type).split(';',1)[0].lower()!='application/x-www-form-urlencoded' or not isinstance(body,dict):return body
    result=dict(body)
    for name,schema in form_properties(cfg, content_type).items():
        if name not in result:continue
        value=result[name]
        if schema.get('type')=='array':result[name]=[_primitive(item,schema['items']) for item in (value if isinstance(value,list) else [value])]
        elif schema.get('type') in ('integer','number','boolean','string'):
            if isinstance(value,list):raise ValueError('Scalar form field is repeated')
            result[name]=_primitive(value,schema)
    return result


def multipart_contract(cfg, media):
    return media == 'multipart/form-data' and media in cfg.get('_restRequestSchemas', {})


def multipart_form_bytes(cfg, body, limit):
    import base64
    import httpx
    if not isinstance(body, dict):
        raise ValueError('Multipart request body must be an object')
    fields = form_properties(cfg, 'multipart/form-data')
    encoding = cfg.get('_restMultipartEncoding') or {}
    mapped_headers = cfg.get('multipartPartHeaders') or {}
    if not isinstance(mapped_headers, dict) or set(mapped_headers) - set(body):
        raise ValueError('Multipart part headers must be keyed by mapped form properties')
    parts = []
    size = 0
    for name, values in body.items():
        field = fields.get(name, {})
        if field.get('type') == 'array' or isinstance(values, list):
            field, values = field.get('items', {}), values
        else:
            values = [values]
        settings = encoding.get(name, {})
        for value in values:
            binary = field.get('format') == 'binary'
            default = 'application/octet-stream' if binary else 'application/json' if isinstance(value, (dict,list)) else 'text/plain'
            media = str(settings.get('contentType') or default).split(',', 1)[0].strip()
            if '\r' in media or '\n' in media:
                raise ValueError('Invalid multipart part content type')
            if binary:
                content = base64.b64decode(value, validate=True)
            elif media.split(';',1)[0].endswith(('/json','+json')):
                content = json.dumps(value, ensure_ascii=False, allow_nan=False).encode()
            else:
                content = ('true' if value is True else 'false' if value is False else str(value)).encode()
            size += len(content)
            if size > limit or len(parts) >= 256:
                raise ValueError('Multipart request exceeds configured limits')
            supplied = mapped_headers.get(name, {})
            if not isinstance(supplied, dict):
                raise ValueError('Multipart part headers must be an object')
            extra_headers = validate_part_headers(settings, supplied, apply_defaults=True)
            parts.append((name, (name if binary else None, content, media, extra_headers)))
    if not parts:
        raise ValueError('Multipart request must contain at least one part')
    request = httpx.Request('POST', 'http://localhost', files=parts)
    return request.read(), request.headers['content-type']


def validate_part_headers(settings, supplied, *, apply_defaults=False):
    definitions = {name.lower(): (name, definition) for name, definition in (settings.get('headers') or {}).items()}
    protected = {'content-type', 'content-disposition', 'content-transfer-encoding',
                 'connection', 'transfer-encoding', 'content-length'}
    values = {name.lower(): value for name, value in supplied.items()}
    if apply_defaults and (values.keys() - definitions.keys() or protected & values.keys()):
        raise ValueError('Map only declared, non-reserved multipart part headers')
    output = {}
    for key, (name, definition) in definitions.items():
        if key in protected:
            continue
        schema = definition.get('schema') or {}
        value = values.get(key, schema.get('default') if apply_defaults else None)
        if value is None:
            if definition.get('required'):
                raise ValueError(f'Multipart part header {name} is required')
            continue
        if isinstance(value, list) or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name):
            raise ValueError('Invalid multipart part header')
        text = 'true' if value is True else 'false' if value is False else str(value)
        if not text.isascii() or '\r' in text or '\n' in text:
            raise ValueError('Invalid multipart part header value')
        if schema_errors(_primitive(text, schema), schema):
            raise ValueError(f'Multipart part header {name} violates its schema')
        output[name] = text
    return output


def decode_multipart_form(cfg, message):
    import base64
    from .http_contracts import media_schema, parse_json
    fields = form_properties(cfg, 'multipart/form-data')
    encoding = cfg.get('_restMultipartEncoding') or {}
    output = {}
    parts = list(message.iter_parts())
    if not parts:
        raise ValueError('Multipart request must contain at least one part')
    for part in parts:
        name = part.get_param('name', header='content-disposition')
        if part.get_content_disposition() != 'form-data' or not name or part.is_multipart():
            raise ValueError('Invalid multipart form part')
        field = fields.get(name, {})
        repeated = field.get('type') == 'array'
        field = field.get('items', {}) if repeated else field
        content_type = part.get_content_type()
        configured = str(encoding.get(name, {}).get('contentType') or '')
        if configured and media_schema({media.strip(): None for media in configured.split(',')}, content_type)[0] is None:
            raise ValueError('Unexpected multipart part content type')
        definitions = encoding.get(name, {}).get('headers') or {}
        part_headers = {}
        for header in definitions:
            values = part.get_all(header, [])
            if len(values) > 1:
                raise ValueError('Duplicate multipart part header')
            if values:
                part_headers[header] = str(values[0])
        validate_part_headers(encoding.get(name, {}), part_headers)
        content = part.get_payload(decode=True) or b''
        if field.get('format') == 'binary':
            value = base64.b64encode(content).decode()
        else:
            value = content.decode(part.get_content_charset() or 'utf-8')
            value = parse_json(value) if content_type.endswith(('/json','+json')) else _primitive(value, field)
        if repeated:
            output.setdefault(name, []).append(value)
        elif name in output:
            raise ValueError('Scalar multipart field is repeated')
        else:
            output[name] = value
    return output

def parameter_value(parameter, values):
    name=parameter.get('name');schema=parameter.get('schema') or parameter;kind=schema.get('type');location=parameter.get('in')
    name=str(name).lower() if location=='header' else name
    value=values.get(name)
    style=parameter.get('style') or ('form' if location in ('query','cookie') else 'simple')
    explode=parameter.get('explode',style=='form')
    if style=='deepObject' and kind=='object':
        value={key[len(name)+1:-1]:item for key,item in values.items() if key.startswith(name+'[') and key.endswith(']')} or None
    elif kind=='object' and explode and style=='form':
        value={key:values[key] for key in schema.get('properties',{}) if key in values} or value
    if value is None:return None
    if kind=='array':
        delimiter={'spaceDelimited':' ','pipeDelimited':'|','label':'.' if explode else ','}.get(style,{'ssv':' ','pipes':'|','tsv':'\t'}.get(parameter.get('collectionFormat'),','))
        if not isinstance(value,list):
            if style=='matrix':
                value=[item.split('=',1)[-1] for item in str(value).lstrip(';').split(';')] if explode else str(value).split('=',1)[-1].split(',')
            elif style=='form' and explode and parameter.get('collectionFormat','multi')=='multi':value=[value]
            else:value=str(value).lstrip('.').split(delimiter)
        return [_primitive(item,schema.get('items') or {}) for item in value]
    if kind=='object':
        if not isinstance(value,dict):
            if style=='matrix':items=str(value).lstrip(';').split(';')
            else:items=str(value).lstrip('.').split('.' if style=='label' and explode else ',')
            if explode:value=dict(item.split('=',1) for item in items)
            else:value=dict(zip(items[::2],items[1::2],strict=True))
        return {key:_primitive(item,(schema.get('properties') or {}).get(key,{})) for key,item in value.items()}
    if isinstance(value,list):raise ValueError('Scalar parameter is repeated')
    if style=='label':value=str(value).lstrip('.')
    if style=='matrix':value=str(value).split('=',1)[-1]
    return _primitive(value,schema)

def listener_parameters(cfg, path_names):
    """Merge listener declarations with the selected operation's contract."""
    declared = cfg.get('requestParameters', [])
    if not isinstance(declared, list) or len(declared) > 100:
        raise ValueError('Configure up to 100 request parameter declarations')
    parameters = [item for item in cfg.get('_restParameters') or [] if not item.get('_minaDeclared')]

    def key(location, name):
        return location, name.lower() if location == 'header' else name

    seen = {key(parameter['in'], parameter['name']) for parameter in parameters}
    for row in declared:
        if not isinstance(row, dict):
            raise ValueError('Each request parameter must be an object')
        location, name, kind = row.get('in'), str(row.get('name') or '').strip(), row.get('type')
        if location not in ('path', 'query', 'header') or kind not in ('string', 'integer', 'number', 'boolean'):
            raise ValueError('Select a supported request parameter location and type')
        if (location == 'path' and name not in path_names) or not re.fullmatch(r'[A-Za-z0-9_-]+', name):
            raise ValueError(f'Invalid {location} parameter name: {name or "(blank)"}')
        identity = key(location, name)
        if identity in seen:
            raise ValueError(f'{location} parameter {name} is already declared')
        if identity in {('header', 'accept'), ('header', 'content-type'), ('header', 'authorization')}:
            raise ValueError(f'Configure {name} through media types or authentication')
        seen.add(identity)
        parameters.append({'name': name, 'in': location, 'schema': {'type': kind}, '_minaDeclared': True,
                           'required': location == 'path' or row.get('required') is True})
    return parameters


def security_requirements(requirements, schemes, dereference):
    if not isinstance(requirements, list):
        raise ValueError('OpenAPI security must be an array')
    alternatives = []
    for requirement in requirements:
        if not isinstance(requirement, dict):
            raise ValueError('OpenAPI security entries must be objects')
        alternative = []
        for name, scopes in requirement.items():
            if name not in schemes or not isinstance(scopes, list) or any(not isinstance(scope, str) for scope in scopes):
                raise ValueError(f'Invalid OpenAPI security requirement: {name}')
            scheme = dereference(schemes[name])
            if not isinstance(scheme, dict):
                raise ValueError(f'Invalid OpenAPI security scheme: {name}')
            kind = scheme.get('type')
            if kind == 'http':
                kind = str(scheme.get('scheme') or '').lower()
            alternative.append((name, kind, scopes, scheme))
        alternatives.append(alternative)
    return alternatives


def compatible_security(cfg):
    """Select alternatives that the configured listener can enforce."""
    mode = str(cfg.get('authentication') or 'none').lower()
    supported = {
        'basic': {'basic', 'ldap'},
        'bearer': {'bearer', 'jwt', 'oauth2'},
        'oauth2': {'oauth2', 'jwt'},
        'openIdConnect': {'oauth2', 'jwt'},
        'mutualTLS': {'certificate'},
    }
    tls = cfg.get('clientAuthentication') == 'required'
    secrets = cfg.get('openApiApiKeySecrets') or {}
    if isinstance(secrets, str):
        try:
            secrets = json.loads(secrets)
        except ValueError:
            raise ValueError('OpenAPI API key secrets must be a JSON object') from None
    if not isinstance(secrets, dict) or any(not isinstance(value, str) or not value for value in secrets.values()):
        raise ValueError('OpenAPI API key secrets must map scheme names to nonempty strings')
    cfg['_restApiKeySecrets'] = secrets
    compatible = []
    for alternative in cfg.get('_restSecurity', []):
        credentials = [(kind, scopes) for _, kind, scopes, _ in alternative if kind not in ('mutualTLS', 'apiKey')]
        certificate = any(kind == 'mutualTLS' for _, kind, _, _ in alternative)
        if certificate and not tls:
            continue
        if any(scopes for _, kind, scopes, _ in alternative if kind in ('mutualTLS', 'apiKey')):
            continue
        keys = [(name, scheme.get('in'), scheme.get('name')) for name, kind, _, scheme in alternative if kind == 'apiKey']
        if any(name not in secrets or location not in ('header', 'query', 'cookie')
               or not isinstance(field, str) or not field for name, location, field in keys):
            continue
        if len(credentials) > 1:
            continue
        if not credentials:
            compatible.append((certificate, [], keys))
            continue
        kind, scopes = credentials[0]
        if mode in supported.get(kind, ()) and (not scopes or mode in ('oauth2', 'jwt')):
            compatible.append((certificate, scopes, keys))
    if cfg.get('_restSecurity') and not compatible:
        raise ValueError('HTTP connection cannot enforce any declared OpenAPI security alternative')
    return compatible


def authorize_contract(cfg, headers, query, claims, verified_mtls):
    import hmac
    from http.cookies import SimpleCookie

    alternatives = cfg.get('_restSecurityAlternatives') or []
    if not alternatives:
        return
    scope_claim = claims.get('scope', claims.get('scp', ''))
    granted = scope_claim.split() if isinstance(scope_claim, str) else scope_claim if isinstance(scope_claim, list) and all(isinstance(value, str) for value in scope_claim) else []
    cookies = SimpleCookie()
    cookies.load(str(headers.get('cookie') or ''))
    values = {'header': headers, 'query': query, 'cookie': {name: cookie.value for name, cookie in cookies.items()}}
    secrets = cfg['_restApiKeySecrets']
    def matches(name, location, field):
        value = values[location].get(field.lower() if location == 'header' else field)
        return isinstance(value, str) and hmac.compare_digest(value.encode(), secrets[name].encode())
    for certificate, required, keys in alternatives:
        if (not certificate or verified_mtls) and set(required).issubset(granted) and all(matches(*key) for key in keys):
            return
    from .http_transport import HTTPFault
    raise HTTPFault('OpenAPI security requirements were not met', 'HTTP_SECURITY', 403)


def validate_parameters(cfg,parameters,query,headers,body,decoded=None):
    """Validate presence and primitive wire types before invoking a workflow/API."""
    from http.cookies import SimpleCookie
    errors=[];headers={str(key).lower():value for key,value in headers.items()}
    cookies=SimpleCookie();cookies.load('; '.join(headers.get('cookie',[])) if isinstance(headers.get('cookie'),list) else str(headers.get('cookie') or ''))
    cookie_values={key:item.value for key,item in cookies.items()}
    for parameter in cfg.get('_restParameters') or []:
        name=parameter.get('name');location=parameter.get('in');values=parameters if location=='path' else query if location=='query' else cookie_values if location=='cookie' else (body if isinstance(body,dict) else {}) if location=='formData' else headers
        try:value=parameter_value(parameter,values)
        except (ValueError,TypeError):errors.append(f'{location} parameter {name} has an invalid value');continue
        if value is None:
            if parameter.get('required') or location=='path':errors.append(f'{location} parameter {name} is required')
            continue
        if schema_errors(value,parameter.get('schema') or parameter):
            errors.append(f'{location} parameter {name} violates its schema')
        elif decoded is not None and parameter.get('_minaDeclared'):
            decoded[location][name.lower() if location == 'header' else name] = value
    if cfg.get('_requiredBody') and body is None:errors.append('Request body is required')
    return errors

def serialize_parameter(parameter,value):
    """OpenAPI form/simple/label/matrix and Swagger collection serialization."""
    location=parameter.get('in');name=parameter.get('name');style=parameter.get('style') or ('form' if location in ('query','cookie') else 'simple')
    explode=parameter.get('explode',style=='form');kind=(parameter.get('schema') or parameter).get('type')
    primitive=lambda item:'true' if item is True else 'false' if item is False else str(item)
    if isinstance(value,dict):
        if style=='deepObject':return {f'{name}[{key}]':primitive(item) for key,item in value.items()}
        if style=='form' and explode:return {key:primitive(item) for key,item in value.items()}
        separator=';' if style=='matrix' and explode else '.' if style=='label' and explode else ','
        result=separator.join(f'{key}={primitive(item)}' if explode else f'{key},{primitive(item)}' for key,item in value.items())
    elif isinstance(value,list):
        if style=='form' and explode and parameter.get('collectionFormat','multi')=='multi':return value
        separator={'spaceDelimited':' ','pipeDelimited':'|','label':'.' if explode else ','}.get(style,{'ssv':' ','pipes':'|','tsv':'\t'}.get(parameter.get('collectionFormat'),','))
        result=separator.join(map(primitive,value))
        if style=='matrix' and explode:result=';'.join(f'{name}={primitive(item)}' for item in value)
    else:result=primitive(value)
    if style=='label':return '.'+result
    if style=='matrix':return ';'+('' if explode and isinstance(value,dict) or explode and isinstance(value,list) else str(name)+'=')+result
    return result

def wire_parameters(cfg,location,values):
    result=dict(values)
    for parameter in cfg.get('_restParameters') or []:
        if parameter.get('in')!=location:continue
        name=str(parameter.get('name'));name=name.lower() if location=='header' else name
        if name not in values:continue
        encoded=serialize_parameter(parameter,values[name])
        if isinstance(encoded,dict):result.pop(name,None);result.update(encoded)
        else:result[name]=encoded
    return result


def reserved_query_keys(cfg, values):
    keys = set()
    for parameter in cfg.get('_restParameters', []):
        name = parameter.get('name')
        if parameter.get('in') == 'query' and parameter.get('allowReserved') is True and name in values:
            encoded = serialize_parameter(parameter, values[name])
            keys.update(encoded if isinstance(encoded, dict) else [name])
    return keys


def encode_reserved_query(pairs, reserved):
    def encode(value):
        # Retain valid percent escapes and query-safe reserved characters. Form
        # separators and the URI fragment delimiter must remain percent-encoded.
        return ''.join(part if re.fullmatch(r'%[0-9a-fA-F]{2}', part)
                       else urllib.parse.quote(part, safe=":/?[]@!$'()*,;")
                       for part in re.split(r'(%[0-9a-fA-F]{2})', value))
    return '&'.join(f'{urllib.parse.quote_plus(key)}={encode(value) if key in reserved else urllib.parse.quote_plus(value)}'
                    for key, value in pairs)
