"""Shared Python HTTP transport and authentication for Studio and both exports."""
from __future__ import annotations
import atexit, base64, hashlib, hmac, ipaddress, json, math, os, re, ssl, tempfile, threading, time, urllib.parse, uuid
from pathlib import Path
import httpx
from .rest_contract import encode_reserved_query, multipart_contract, multipart_form_bytes, operation_config, reserved_query_keys, validate_parameters, wire_parameters
from .http_messages import request_config, mime_body, response_tree, multi_values, object_value as message_object_value
from .http_contracts import schema_errors, response_schema,request_schema,media_schema,response_content,parse_json
from .http_policy import (cached_http_response, circuit_enter, circuit_result, invalidate_shared_cache, outbound_trace,
                          retry_delay, retryable, shared_cache_request, store_http_response)

class HTTPFault(ValueError):
    def __init__(self, message, fault_type='HTTP_SECURITY', status=401):
        super().__init__(message); self.fault_type=fault_type; self.status=status

def boolean(value, default=False):
    if value is None or value == '': return default
    return str(value).lower() in ('true','1','yes','on')

def number(cfg,key,default,minimum=0,maximum=1000000000):
    try: value=float(default if cfg.get(key) in (None,'') else cfg[key])
    except (ValueError,TypeError): raise HTTPFault(f'{key} must be a number','HTTP_CONFIGURATION',400)
    if not math.isfinite(value) or not minimum <= value <= maximum: raise HTTPFault(f'{key} must be between {minimum} and {maximum}','HTTP_CONFIGURATION',400)
    return value

def object_value(value,label):
    try:
        return message_object_value(value, label)
    except ValueError as error:
        raise HTTPFault(str(error), 'HTTP_CONFIGURATION', 400) from None

def merged(connection,activity):
    result={**(connection or {}),**(activity or {})}
    result['headers']={**object_value((connection or {}).get('headers'),'Default headers'),**object_value((activity or {}).get('headers'),'Headers')}
    result['query']={**object_value((connection or {}).get('query'),'Default query'),**object_value((activity or {}).get('query'),'Query')}
    return result

def _store(path,kind,password,alias=''):
    if not path: return b'',b'',b''
    raw=Path(path).expanduser().read_bytes()
    if kind.upper() in ('PKCS12','P12','PFX'):
        from cryptography.hazmat.primitives.serialization import pkcs12, Encoding, PrivateFormat, NoEncryption
        key,cert,chain=pkcs12.load_key_and_certificates(raw,password.encode() if password else None)
        return (cert.public_bytes(Encoding.PEM) if cert else b'')+b''.join(item.public_bytes(Encoding.PEM) for item in chain or []), key.private_bytes(Encoding.PEM,PrivateFormat.PKCS8,NoEncryption()) if key else b'', b''.join(item.public_bytes(Encoding.PEM) for item in ([cert] if cert else [])+list(chain or []))
    if kind.upper() == 'JKS':
        import shutil, subprocess
        executable=shutil.which('keytool')
        if not executable and os.environ.get('JAVA_HOME'):
            candidate=Path(os.environ['JAVA_HOME'])/'bin'/('keytool.exe' if os.name=='nt' else 'keytool')
            if candidate.is_file():executable=str(candidate)
        if not executable:raise HTTPFault('JKS stores require Java keytool or convert the store to PKCS12','HTTP_CONFIGURATION',400)
        with tempfile.TemporaryDirectory(prefix='mina-jks-') as directory:
            target=Path(directory)/'converted.p12';destination_password=uuid.uuid4().hex
            arguments=[executable,'-importkeystore','-srckeystore',str(Path(path).expanduser()),'-srcstoretype','JKS','-srcstorepass:env','MINA_SOURCE_STORE_PASS','-destkeystore',str(target),'-deststoretype','PKCS12','-deststorepass:env','MINA_DEST_STORE_PASS','-noprompt']
            if alias:arguments+=['-srcalias',alias]
            result=subprocess.run(arguments,env={**os.environ,'MINA_SOURCE_STORE_PASS':password,'MINA_DEST_STORE_PASS':destination_password},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
            if result.returncode:raise HTTPFault('JKS conversion failed; check store password and alias','HTTP_CONFIGURATION',400)
            return _store(target,'PKCS12',destination_password)
    if kind.upper() != 'PEM': raise HTTPFault('Store type must be PEM, PKCS12 or JKS','HTTP_CONFIGURATION',400)
    return raw,b'',raw

def certificate_files(folder):
    """Read ordinary certificate files; OpenSSL hash-directory names are unnecessary."""
    directory=Path(str(folder)).expanduser()
    try:
        if not directory.is_dir():raise ValueError()
        files=sorted((path for path in directory.iterdir() if path.is_file() and path.suffix.lower() in ('.pem','.crt','.cer','.der')),key=lambda path:path.name.lower())
        if not files:raise HTTPFault('Trusted certificate folder contains no PEM/CRT/CER/DER certificates','HTTP_CONFIGURATION',400)
        if len(files)>256:raise HTTPFault('Trusted certificate folder exceeds 256 certificate files','HTTP_CONFIGURATION',400)
        return files
    except HTTPFault:raise
    except (OSError,ValueError):raise HTTPFault('Trusted certificate folder does not exist or cannot be read','HTTP_CONFIGURATION',400) from None

def load_certificate_folder(ctx,folder):
    total=0
    for path in certificate_files(folder):
        try:
            with path.open('rb') as source:raw=source.read(8*1024**2+1)
            total+=len(raw)
            if len(raw)>8*1024**2 or total>32*1024**2:raise HTTPFault('Trusted certificate folder exceeds certificate size limits','HTTP_CONFIGURATION',400)
            if b'-----BEGIN' in raw:
                if b'PRIVATE KEY-----' in raw:raise ValueError()
                certificates=re.findall(rb'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',raw,re.S)
                if not certificates:raise ValueError()
                pem=b'\n'.join(certificates).decode('ascii')
            else:pem=ssl.DER_cert_to_PEM_cert(raw)
            ctx.load_verify_locations(cadata=pem)
        except HTTPFault:raise
        except (OSError,ValueError,ssl.SSLError):raise HTTPFault(f'Cannot load trusted certificate file: {path.name}','HTTP_CONFIGURATION',400) from None
    # Intermediates assist path building; a chain must still reach a trusted root.
    if hasattr(ssl,'VERIFY_X509_PARTIAL_CHAIN'):ctx.verify_flags &= ~ssl.VERIFY_X509_PARTIAL_CHAIN

def tls_context(cfg,server=False):
    verify=boolean(cfg.get('verifyTls'),True)
    if boolean(cfg.get('defaultConfidentiality')) and not verify:raise HTTPFault('Default confidentiality requires server certificate and hostname verification','HTTP_CONFIGURATION',400)
    ctx=ssl.create_default_context(ssl.Purpose.CLIENT_AUTH if server else ssl.Purpose.SERVER_AUTH)
    if not server and not verify: ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
    version=str(cfg.get('tlsVersion') or 'TLSv1.2')
    versions={'TLSv1.2':ssl.TLSVersion.TLSv1_2,'TLSv1.3':ssl.TLSVersion.TLSv1_3}
    if version not in versions: raise HTTPFault('Only TLSv1.2 and TLSv1.3 are supported','HTTP_CONFIGURATION',400)
    ctx.minimum_version=versions[version]
    if cfg.get('maximumTlsVersion'):
        ctx.maximum_version=versions[cfg['maximumTlsVersion']]
        if ctx.maximum_version<ctx.minimum_version: raise HTTPFault('Maximum TLS version precedes minimum','HTTP_CONFIGURATION',400)
    if cfg.get('cipherSuites'): ctx.set_ciphers(str(cfg['cipherSuites']))
    ca=cfg.get('trustStoreFile') or cfg.get('certificateAuthorityFile')
    if ca:
        _,_,trust=_store(ca,str(cfg.get('trustStoreType') or 'PEM'),str(cfg.get('trustStorePassword') or ''))
        if not trust: raise HTTPFault('Trust store contains no certificates','HTTP_CONFIGURATION',400)
        ctx.load_verify_locations(cadata=trust.decode())
    if cfg.get('trustedCertificateFolder'):load_certificate_folder(ctx,cfg['trustedCertificateFolder'])
    if cfg.get('crlFile'):
        ctx.load_verify_locations(cafile=str(cfg['crlFile']));ctx.verify_flags|=ssl.VERIFY_CRL_CHECK_CHAIN
    identity=cfg.get('identityStoreFile');cert=cfg.get('certificateFile') or cfg.get('clientCertificateFile');key=cfg.get('privateKeyFile') or cfg.get('clientKeyFile')
    if identity:
        cert_data,key_data,_=_store(identity,str(cfg.get('identityStoreType') or 'PKCS12'),str(cfg.get('identityStorePassword') or ''),str(cfg.get('keyAlias') or ''))
        if not cert_data or not key_data: raise HTTPFault('Identity store needs a private key and certificate','HTTP_CONFIGURATION',400)
        with tempfile.TemporaryDirectory(prefix='mina-tls-') as folder:
            cp=Path(folder)/'cert.pem';kp=Path(folder)/'key.pem';cp.write_bytes(cert_data);kp.write_bytes(key_data);os.chmod(kp,0o600);ctx.load_cert_chain(cp,kp)
    elif cert:
        ctx.load_cert_chain(str(cert),str(key) if key else None,cfg.get('privateKeyPassword') or cfg.get('clientKeyPassword') or None)
    elif server: raise HTTPFault('HTTPS server requires an identity store or certificate and private key','HTTP_CONFIGURATION',400)
    if server:
        mode=str(cfg.get('clientAuthentication') or 'none').lower()
        if mode not in ('none','optional','required'): raise HTTPFault('Invalid client certificate authentication mode','HTTP_CONFIGURATION',400)
        ctx.verify_mode={'none':ssl.CERT_NONE,'optional':ssl.CERT_OPTIONAL,'required':ssl.CERT_REQUIRED}[mode]
    return ctx

def validate_authentication(cfg,server=False):
    scheme=str(cfg.get('authentication') or 'None').lower()
    allowed={'none','basic','bearer','jwt','hmac','oauth2','certificate'}|({'ldap'} if server else {'digest','ntlm'})
    if scheme not in allowed:raise HTTPFault('Authentication is not supported for this connection role','HTTP_CONFIGURATION',400)
    def require(key,label):
        if not cfg.get(key):raise HTTPFault(label+' is required','HTTP_CONFIGURATION',400)
    if scheme in ('basic','digest','ntlm'):require('username','Username');require('password','Password')
    elif scheme=='bearer':require('bearerToken','Bearer token')
    elif scheme=='hmac':require('hmacSecret','HMAC secret')
    elif scheme=='jwt' and not (not server and cfg.get('jwtToken')):
        if server and cfg.get('jwtJwksUrl'):
            secure_url(str(cfg['jwtJwksUrl']),{**cfg,'confidentiality':True})
            if str(cfg.get('jwtAlgorithm') or 'HS256').startswith('HS'):raise HTTPFault('JWKS requires an asymmetric JWT algorithm','HTTP_CONFIGURATION',400)
        elif not _jwt_key(cfg,sign=not server):raise HTTPFault('JWT key is required','HTTP_CONFIGURATION',400)
    elif scheme=='oauth2':
        require('oauthClientId','OAuth client ID')
        client_auth = str(cfg.get('oauthClientAuthentication') or 'basic')
        if client_auth not in ('basic', 'body', 'private_key_jwt'):
            raise HTTPFault('Unsupported OAuth client authentication method','HTTP_CONFIGURATION',400)
        if client_auth == 'private_key_jwt':
            require('oauthClientPrivateKeyFile', 'OAuth client signing key')
            if str(cfg.get('oauthClientAssertionAlgorithm') or 'RS256') not in ('RS256', 'RS384', 'RS512', 'ES256', 'ES384', 'ES512'):
                raise HTTPFault('OAuth client assertions require a supported asymmetric algorithm','HTTP_CONFIGURATION',400)
        secure_url(str(cfg.get('oauthIntrospectionUrl' if server else 'oauthTokenUrl') or ''),{**cfg,'confidentiality':True})
    elif scheme=='ldap':
        require('ldapUrl','LDAP URL')
        if not cfg.get('ldapUserDnTemplate') and not cfg.get('ldapBaseDn'):raise HTTPFault('LDAP user DN template or search base is required','HTTP_CONFIGURATION',400)
        if not str(cfg['ldapUrl']).startswith('ldaps://') and not boolean(cfg.get('ldapStartTls'),True):raise HTTPFault('LDAP requires LDAPS or StartTLS','HTTP_CONFIGURATION',400)
    elif scheme=='certificate' and not server and not (cfg.get('identityStoreFile') or cfg.get('clientCertificateFile') or cfg.get('certificateFile')):raise HTTPFault('Client identity certificate is required','HTTP_CONFIGURATION',400)

def secure_url(url,cfg):
    parts=urllib.parse.urlsplit(url)
    if parts.scheme not in ('http','https') or not parts.hostname or parts.username or parts.password or parts.fragment: raise HTTPFault('HTTP URL must have a host, no embedded credentials or fragment','HTTP_CONFIGURATION',400)
    if (str(cfg.get('authentication') or '').lower()=='certificate' or boolean(cfg.get('defaultConfidentiality')) or boolean(cfg.get('confidentiality')) or boolean(cfg.get('tlsEnabled'))) and parts.scheme!='https': raise HTTPFault('Confidentiality requires HTTPS','HTTP_CONFIGURATION',400)
    return url

def _seconds(cfg,ms,seconds,default):
    value=number(cfg,ms,default*1000)/1000 if ms in cfg and cfg[ms] not in ('',None) else number(cfg,seconds,default)
    return value or None

_POOL={};_POOL_LOCK=threading.RLock();_TOKENS={};_TOKEN_SCOPES={};_NONCES={};_SECURITY_LOCK=threading.RLock()

def close_clients(scope=None):
    with _POOL_LOCK:
        keys=[key for key,client in _POOL.items() if scope is None or client._mina_scope==scope]
        clients=[_POOL.pop(key) for key in keys]
    first_error=None
    for client in clients:
        try:client.close()
        except Exception as error:
            if first_error is None:first_error=error
    with _SECURITY_LOCK:
        for key in list(_TOKENS):
            if scope is None or _TOKEN_SCOPES.get(key)==scope:_TOKENS.pop(key,None);_TOKEN_SCOPES.pop(key,None)
    if first_error is not None:raise first_error
atexit.register(close_clients)


def _release_route(client, route, gate, acquired=True):
    with client._mina_lock:
        if acquired:gate.release()
        users=client._mina_route_users
        users[route]-=1
        if not users[route]:
            del users[route]
            del client._mina_routes[route]


def _acquire_route(client, route, timeout):
    # Count both executing requests and waiters before releasing the map lock.
    # Idle destinations must not accumulate when URLs are supplied dynamically.
    with client._mina_lock:
        if not hasattr(client,'_mina_route_users'):client._mina_route_users={}
        gate=client._mina_routes.get(route)
        if gate is None:
            gate=threading.BoundedSemaphore(client._mina_route_limit)
            client._mina_routes[route]=gate
        client._mina_route_users[route]=client._mina_route_users.get(route,0)+1
    try:
        if not gate.acquire(timeout=timeout):raise HTTPFault('HTTP pool timeout','HTTP_TIMEOUT',504)
    except BaseException:
        _release_route(client,route,gate,False)
        raise
    return gate

_NETWORK=('defaultConfidentiality','confidentiality','tlsEnabled','verifyTls','tlsVersion','maximumTlsVersion','cipherSuites','certificateAuthorityFile','trustStoreFile','trustStoreType','trustStorePassword','identityStoreFile','identityStoreType','identityStorePassword','keyAlias','certificateFile','privateKeyFile','privateKeyPassword','clientCertificateFile','clientKeyFile','clientKeyPassword','crlFile','proxyHost','proxyPort','proxyUrl','proxyUsername','proxyPassword','httpVersion','maximumTotalConnections','maximumConnectionsPerHost','idleConnectionTimeoutMs','disableConnectionPooling','usePersistentConnections','authentication','username','password','bearerToken','oauthClientId','oauthClientSecret','oauthTokenUrl','oauthScope','oauthGrantType','oauthRefreshToken','oauthAuthorizationCode','oauthRedirectUri','jwtSecret','jwtToken','hmacSecret','hmacKeyId','enableCookies','resourceId','_httpScope','baseUrl','oauthCodeVerifier','oauthClientAuthentication','jwtPrivateKeyFile','jwtPublicKeyFile')
def _fingerprint(cfg):
    values={key:cfg.get(key) for key in _NETWORK}
    if str(cfg.get('httpVersion')) == '3':
        values.update({key:cfg.get(key) for key in ('_inboundHttp','maxRequestBodyBytes','maxResponseBodyBytes','activityTimeoutSeconds')})
    folder=cfg.get('trustedCertificateFolder');values['trustedCertificateFolder']=folder
    if folder:
        try:values['_certificateFiles']=[(str(path),path.stat().st_mtime_ns,path.stat().st_size) for path in certificate_files(folder)]
        except OSError:raise HTTPFault('Trusted certificate folder cannot be read','HTTP_CONFIGURATION',400) from None
    return hashlib.sha256(json.dumps(values,sort_keys=True,default=str).encode()).hexdigest()

def client_for(cfg):
    key=_fingerprint(cfg)
    with _POOL_LOCK:
        if key in _POOL:return _POOL[key]
        if len(_POOL)>=128: raise HTTPFault('HTTP shared client limit reached; close unused clients','HTTP_CONFIGURATION',400)
        total=int(number(cfg,'maximumTotalConnections',200,1,100000));per=int(number(cfg,'maximumConnectionsPerHost',20,1,total))
        persistent=boolean(cfg.get('usePersistentConnections'),True) and not boolean(cfg.get('disableConnectionPooling'))
        proxy=cfg.get('proxyUrl')
        if not proxy and cfg.get('proxyHost'):
            credentials=urllib.parse.quote(str(cfg.get('proxyUsername') or ''),safe='')+':'+urllib.parse.quote(str(cfg.get('proxyPassword') or ''),safe='')+'@' if cfg.get('proxyUsername') else ''
            proxy=f'http://{credentials}{cfg["proxyHost"]}:{int(number(cfg,"proxyPort",8080,1,65535))}'
        version=str(cfg.get('httpVersion') or '1.1')
        if version == '3' and cfg.get('_inboundHttp'):
            version = '2'  # Authentication and reference services still use the HTTPS client.
        if version not in ('1.1','2','3'): raise HTTPFault('Client HTTP version must be 1.1, 2 or 3','HTTP_CONFIGURATION',400)
        transport = None
        if version == '3':
            if proxy or not boolean(cfg.get('verifyTls'), True) or cfg.get('clientCertificateFile') or cfg.get('certificateFile') or cfg.get('identityStoreFile') or cfg.get('maximumTlsVersion') == 'TLSv1.2':
                raise HTTPFault('HTTP/3 requires direct HTTPS, verified TLS 1.3 and no client certificate','HTTP_CONFIGURATION',400)
            if cfg.get('crlFile') or cfg.get('cipherSuites'):
                raise HTTPFault('HTTP/3 does not support custom CRLs or cipher suites','HTTP_CONFIGURATION',400)
            try:
                import aioquic  # noqa: F401
            except ImportError:
                raise HTTPFault('Install aioquic to use HTTP/3','HTTP_CONFIGURATION',400) from None
            from .http3_client import HTTP3Transport
            transport = HTTP3Transport(tls_context(cfg), int(number(cfg,'maxRequestBodyBytes',64*1024**2,1)),
                                       int(number(cfg,'maxResponseBodyBytes',64*1024**2,1)), number(cfg,'activityTimeoutSeconds',180,1))
        import http.cookiejar
        class RejectCookies(http.cookiejar.DefaultCookiePolicy):
            def set_ok(self,cookie,request):return False
        cookies=None if boolean(cfg.get('enableCookies')) else http.cookiejar.CookieJar(policy=RejectCookies())
        client=httpx.Client(cookies=cookies,verify=tls_context(cfg),proxy=proxy or None,http2=version=='2',transport=transport,trust_env=False,limits=httpx.Limits(max_connections=total,max_keepalive_connections=total if persistent else 0,keepalive_expiry=number(cfg,'idleConnectionTimeoutMs',30000)/1000),timeout=30)
        client._mina_route_limit=per;client._mina_routes={};client._mina_lock=threading.Lock();client._mina_scope=cfg.get('_httpScope');_POOL[key]=client
        return client

def _jwt_key(cfg,sign=False):
    key=cfg.get('jwtPrivateKeyFile') if sign else cfg.get('jwtPublicKeyFile')
    return Path(key).read_text(encoding='utf-8') if key else str(cfg.get('jwtSecret') or '')

def jwt_token(cfg):
    if cfg.get('jwtToken'):return str(cfg['jwtToken'])
    import jwt
    algorithm=str(cfg.get('jwtAlgorithm') or 'HS256')
    if algorithm not in ('HS256','HS384','HS512','RS256','RS384','RS512','ES256','ES384'):raise HTTPFault('Unsupported JWT algorithm','HTTP_CONFIGURATION',400)
    key=_jwt_key(cfg,True)
    if not key:raise HTTPFault('JWT signing key is required','HTTP_CONFIGURATION',400)
    now=int(time.time());claims=object_value(cfg.get('jwtClaims'),'JWT claims');claims={**claims,'iat':now,'exp':now+int(number(cfg,'jwtLifetimeSeconds',300,1,86400))}
    if cfg.get('jwtIssuer'):claims['iss']=cfg['jwtIssuer']
    if cfg.get('jwtAudience'):claims['aud']=cfg['jwtAudience']
    return jwt.encode(claims,key,algorithm=algorithm)

def oauth_client_auth(cfg, endpoint, data):
    client_id = str(cfg.get('oauthClientId') or '')
    secret = str(cfg.get('oauthClientSecret') or '')
    method = cfg.get('oauthClientAuthentication') or 'basic'
    if method == 'basic':
        return (client_id, secret)
    if method == 'body':
        data.update(client_id=client_id, client_secret=secret)
        return None
    import jwt
    now = int(time.time())
    claims = {'iss':client_id, 'sub':client_id, 'aud':endpoint, 'iat':now, 'exp':now + 60, 'jti':uuid.uuid4().hex}
    key_id = cfg.get('oauthClientAssertionKeyId')
    try:
        assertion = jwt.encode(claims, Path(cfg['oauthClientPrivateKeyFile']).expanduser().read_bytes(),
                               algorithm=cfg.get('oauthClientAssertionAlgorithm') or 'RS256',
                               headers={'kid': str(key_id)} if key_id else None)
    except (OSError, KeyError, ValueError, jwt.PyJWTError):
        raise HTTPFault('Could not sign the OAuth client assertion','HTTP_CONFIGURATION',400) from None
    data.update(client_id=client_id, client_assertion=assertion,
                client_assertion_type='urn:ietf:params:oauth:client-assertion-type:jwt-bearer')
    return None


def _oauth(cfg,client):
    token_url=secure_url(str(cfg.get('oauthTokenUrl') or ''),{**cfg,'confidentiality':True})
    key=hashlib.sha256((_fingerprint(cfg)+json.dumps({k:cfg.get(k) for k in ('oauthTokenUrl','oauthClientId','oauthClientSecret','oauthScope','oauthGrantType','oauthRefreshToken','oauthAuthorizationCode','oauthRedirectUri','oauthClientPrivateKeyFile','oauthClientAssertionAlgorithm','oauthClientAssertionKeyId')},sort_keys=True)).encode()).hexdigest()
    # Lock prevents simultaneous refreshes and authorization-code re-use.
    with _SECURITY_LOCK:
        cached=_TOKENS.get(key)
        if cached and cached[1]>time.time()+5:return cached[0]
        grant=str(cfg.get('oauthGrantType') or 'client_credentials');data={'grant_type':grant}
        if cached and grant in ('authorization_code','refresh_token'):
            if not cached[2]:raise HTTPFault('OAuth token expired; reauthorize or supply a refresh token','HTTP_SECURITY',401)
            grant='refresh_token';data={'grant_type':grant,'refresh_token':cached[2]}
        if cfg.get('oauthScope'):data['scope']=cfg['oauthScope']
        if grant=='refresh_token':data.setdefault('refresh_token',cfg.get('oauthRefreshToken'))
        elif grant=='authorization_code':data.update(code=cfg.get('oauthAuthorizationCode'),redirect_uri=cfg.get('oauthRedirectUri'))
        elif grant!='client_credentials':raise HTTPFault('Unsupported OAuth grant','HTTP_CONFIGURATION',400)
        if cfg.get('oauthCodeVerifier'):data['code_verifier']=cfg['oauthCodeVerifier']
        cid=str(cfg.get('oauthClientId') or '')
        if not cid:raise HTTPFault('OAuth client ID is required','HTTP_CONFIGURATION',400)
        auth=oauth_client_auth(cfg, token_url, data)
        try:
            response=client.post(token_url,data=data,auth=auth,timeout=number(cfg,'oauthTimeoutSeconds',30,1,300),follow_redirects=False);response.raise_for_status();body=response.json()
            token=body['access_token'];expires=float(body.get('expires_in',60))
            if not token or str(body.get('token_type','Bearer')).lower()!='bearer' or not math.isfinite(expires) or expires<=0:raise ValueError()
        except Exception:raise HTTPFault('OAuth token exchange failed','HTTP_SECURITY',401) from None
        if len(_TOKENS)>=1024:_TOKENS.clear();_TOKEN_SCOPES.clear()
        _TOKEN_SCOPES[key]=cfg.get('_httpScope');_TOKENS[key]=(str(token),time.time()+expires,body.get('refresh_token') or (cached[2] if cached else cfg.get('oauthRefreshToken')));return str(token)

def hmac_signature(cfg,method,target,body,timestamp,nonce):
    algorithm=str(cfg.get('hmacAlgorithm') or 'SHA256').upper()
    if algorithm not in ('SHA256','SHA384','SHA512'):raise HTTPFault('Unsupported HMAC algorithm','HTTP_CONFIGURATION',400)
    secret=str(cfg.get('hmacSecret') or '')
    if not secret:raise HTTPFault('HMAC secret is required','HTTP_CONFIGURATION',400)
    canonical='\n'.join((method.upper(),target,str(timestamp),nonce,body.sha256 if hasattr(body,'sha256') else hashlib.sha256(body).hexdigest()))
    return base64.b64encode(hmac.new(secret.encode(),canonical.encode(),getattr(hashlib,algorithm.lower())).digest()).decode()

class NonPreemptiveBasic(httpx.Auth):
    requires_request_body=True
    def __init__(self,username,password):
        self.header='Basic '+base64.b64encode((username+':'+password).encode()).decode()
    def auth_flow(self,request):
        response=yield request
        if response.status_code==401 and 'basic' in response.headers.get('www-authenticate','').lower():
            request.headers['Authorization']=self.header
            yield request

def request(cfg,connection=None):
    cfg=merged(connection,cfg)
    try:cfg=request_config(cfg)
    except (ValueError,TypeError,KeyError) as error:raise HTTPFault(str(error),'HTTP_CONFIGURATION',400) from None
    operation = cfg.get('operation')
    if operation == 'write_precondition':
        from .http_policy import write_precondition
        return write_precondition(cfg)
    try:cfg=operation_config(cfg)
    except (ValueError,KeyError,TypeError) as error:raise HTTPFault('Invalid REST contract: '+str(error),'HTTP_CONFIGURATION',400) from None
    validate_authentication(cfg)
    if cfg.get('connectorMode')=='server':raise HTTPFault('Outbound call requires a client shared connection','HTTP_CONFIGURATION',400)
    if str(cfg.get('httpVersion')) == '3' and (cfg.get('streamRequest') or cfg.get('responseFile') or cfg.get('bodyType') == 'file' or operation in ('sse_read','websocket_exchange')):
        raise HTTPFault('HTTP/3 client currently supports buffered HTTP requests only','HTTP_CONFIGURATION',400)
    url=str(cfg.get('url') or cfg.get('path') or '')
    if not urllib.parse.urlsplit(url).scheme:
        effective_scheme='https' if boolean(cfg.get('defaultConfidentiality')) or boolean(cfg.get('confidentiality')) or boolean(cfg.get('tlsEnabled')) else cfg.get('scheme') or 'http'
        base=str(cfg.get('baseUrl') or f'{effective_scheme}://{cfg.get("host") or "localhost"}:{cfg.get("port") or (443 if effective_scheme=="https" else 80)}')
        url=base.rstrip('/')+'/'+('/'.join(part for part in (str(cfg.get('basePath') or '').strip('/'),url.lstrip('/')) if part))
    path_parameters = {name: value for name, value in object_value(cfg.get('pathParameters'), 'URI parameters').items()
                       if value is not None}
    parts = urllib.parse.urlsplit(url)
    path = parts.path
    for name, value in wire_parameters(cfg, 'path', path_parameters).items():
        style = next((p.get('style') for p in cfg.get('_restParameters', [])
                      if p.get('in') == 'path' and p.get('name') == name), None)
        path = path.replace('{' + name + '}', urllib.parse.quote(str(value), safe=';=,.' if style in ('matrix', 'label') else ''))
    if re.search(r'\{[^}]+\}', path):
        raise HTTPFault('Required URI parameter is missing', 'HTTP_CONFIGURATION', 400)
    if any(character in parts.netloc for character in '{}'):
        raise HTTPFault('URI parameters may only be used in the request path', 'HTTP_CONFIGURATION', 400)
    url = urllib.parse.urlunsplit(parts._replace(path=path))
    mapped_query = object_value(cfg.get('query'), 'Query parameters')
    url_query = multi_values(urllib.parse.parse_qsl(parts.query, keep_blank_values=True))
    if operation != 'websocket_exchange':
        secure_url(url,cfg)
    method='GET' if operation == 'sse_read' else str(cfg.get('method') or 'GET').upper()
    if method not in ('GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE'):raise HTTPFault('Unsupported HTTP method','HTTP_CONFIGURATION',400)
    headers={str(k).lower():([str(item) for item in v] if isinstance(v,list) else str(v)) for k,v in cfg['headers'].items()}
    if boolean(cfg.get('propagateTraceContext')) and 'traceparent' not in headers:
        outbound_trace(headers)
    if any('\r' in k+str(v) or '\n' in k+str(v) for k,v in headers.items()):raise HTTPFault('HTTP headers cannot contain newlines','HTTP_CONFIGURATION',400)
    if cfg.get('accept'):headers.setdefault('accept',str(cfg['accept']))
    if cfg.get('contentType'):headers.setdefault('content-type',str(cfg['contentType']))
    if operation == 'websocket_exchange':
        from .http_streams import websocket_exchange
        query = httpx.QueryParams(parts.query).merge(mapped_query)
        events = websocket_exchange(cfg, urllib.parse.urlunsplit(parts._replace(path=path, query=str(query))), headers)
        return {'events':events,'eventCount':len(events)}
    if operation == 'sse_read':
        headers['accept'] = 'text/event-stream'
        if cfg.get('lastEventId'):
            headers['last-event-id'] = str(cfg['lastEventId'])
    body=None if operation == 'sse_read' else cfg.get('body')
    mode=str(cfg.get('sendBodyMode') or 'ALWAYS').upper()
    if mode not in ('ALWAYS','AUTO','NEVER'):raise HTTPFault('Invalid send body mode','HTTP_CONFIGURATION',400)
    if mode=='NEVER' or mode=='AUTO' and method in ('GET','HEAD','OPTIONS'):body=None
    errors=validate_parameters(cfg,path_parameters,{**url_query, **mapped_query},headers,body)
    if errors:raise HTTPFault('; '.join(errors),'REST_VALIDATION',400)
    headers=wire_parameters(cfg,'header',headers)
    query_parameters = wire_parameters(cfg, 'query', mapped_query)
    query = httpx.QueryParams(parts.query).merge(query_parameters) if query_parameters else None
    reserved = reserved_query_keys(cfg, mapped_query)
    if reserved and query is not None:
        url = urllib.parse.urlunsplit(parts._replace(path=path, query=encode_reserved_query(query.multi_items(), reserved)))
        query = None
    request_type=str(headers.get('content-type') or '')
    if body is not None and cfg.get('_restRequestSchemas') and media_schema(cfg['_restRequestSchemas'],request_type)[0] is None:raise HTTPFault('Unsupported request content type','REST_UNSUPPORTED_MEDIA',415)
    schema=request_schema(cfg,request_type)
    if body is not None and boolean(cfg.get('validateRequest'),bool(cfg.get('openApiDocument'))) and schema is not None:
        if schema_errors(body,schema):raise HTTPFault('Request schema validation failed','REST_VALIDATION',400)
    media_type=request_type.split(';',1)[0].lower()
    inferred_type='form' if media_type=='application/x-www-form-urlencoded' else 'bytes' if isinstance(body,(bytes,bytearray,memoryview)) else 'text' if media_type.startswith('text/') or media_type.endswith(('/xml','+xml')) else 'json'
    body_type=str(cfg.get('bodyType') or inferred_type).lower()
    content_factory=None
    if '_mimeEnvelope' in cfg and boolean(cfg.get('streamRequest')):
        from .http_streams import multipart_stream
        content_factory,mime_type=multipart_stream(cfg['_mimeEnvelope'],int(number(cfg,'maxRequestBodyBytes',64*1024**2,1)),body,str(headers.get('content-type') or 'application/json'))
        raw=b'';headers['content-type']=mime_type
    elif '_mimeEnvelope' in cfg:
        try:raw,mime_type=mime_body(cfg['_mimeEnvelope'],int(number(cfg,'maxRequestBodyBytes',64*1024**2,1)),body,str(headers.get('content-type') or headers.get('Content-Type') or cfg.get('contentType') or 'application/json'))
        except (ValueError,TypeError,OSError) as error:raise HTTPFault(str(error),'HTTP_CONFIGURATION',400) from None
        headers={key:value for key,value in headers.items() if key.lower()!='content-type'};headers['content-type']=mime_type
    elif body is None:raw=b''
    elif multipart_contract(cfg, media_type) and body_type == 'json':
        try:
            raw, headers['content-type'] = multipart_form_bytes(cfg, body, int(number(cfg,'maxRequestBodyBytes',64*1024**2,1)))
        except (ValueError, TypeError) as error:
            raise HTTPFault(str(error),'REST_VALIDATION',400) from None
    elif body_type=='form':raw=urllib.parse.urlencode(object_value(body,'Form body'),doseq=True).encode();headers.setdefault('content-type','application/x-www-form-urlencoded')
    elif body_type=='file':
        source=Path(str(body))
        if source.stat().st_size>number(cfg,'maxRequestBodyBytes',64*1024**2,1):raise HTTPFault('HTTP request body limit exceeded','HTTP_BAD_REQUEST',413)
        from .http_streams import file_chunks
        content_factory=lambda:file_chunks(source,int(number(cfg,'maxRequestBodyBytes',64*1024**2,1)))
        raw=b''
    elif isinstance(body,(bytes,bytearray,memoryview)):raw=bytes(body)
    elif body_type=='json':
        try:raw=json.dumps(body,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
        except (ValueError,TypeError):raise HTTPFault('Request body is not valid JSON','HTTP_CONFIGURATION',400) from None
        headers.setdefault('content-type','application/json')
    else:raw=str(body).encode(str(cfg.get('encoding') or 'utf-8'))
    if len(raw)>number(cfg,'maxRequestBodyBytes',64*1024**2,1):raise HTTPFault('HTTP request body limit exceeded','HTTP_BAD_REQUEST',413)
    client=client_for(cfg);auth=None;scheme=str(cfg.get('authentication') or 'None').lower()
    if scheme in ('basic','digest'):
        if not cfg.get('username') or not cfg.get('password'):raise HTTPFault('Authentication credentials are required','HTTP_CONFIGURATION',400)
        auth=(NonPreemptiveBasic(str(cfg['username']),str(cfg['password'])) if boolean(cfg.get('nonPreemptiveAuthentication')) else httpx.BasicAuth(str(cfg['username']),str(cfg['password']))) if scheme=='basic' else httpx.DigestAuth(str(cfg['username']),str(cfg['password']))
    elif scheme in ('bearer','jwt','oauth2'):
        token=_oauth(cfg,client) if scheme=='oauth2' else jwt_token(cfg) if scheme=='jwt' else str(cfg.get('bearerToken') or '')
        if not token:raise HTTPFault('Bearer token is required','HTTP_CONFIGURATION',400)
        headers['authorization']='Bearer '+token
    elif scheme=='ntlm':
        from httpx_ntlm import HttpNtlmAuth
        auth=HttpNtlmAuth(str(cfg.get('username') or ''),str(cfg.get('password') or ''))
    elif scheme not in ('none','certificate','hmac'):raise HTTPFault('Unsupported outbound authentication','HTTP_CONFIGURATION',400)
    if content_factory and auth is not None and getattr(auth,'requires_request_body',False):raise HTTPFault('Streaming uploads require authentication that does not buffer the request body; use preemptive Basic, Bearer, OAuth2, JWT, HMAC or certificates','HTTP_CONFIGURATION',400)
    if scheme=='certificate' and not (cfg.get('identityStoreFile') or cfg.get('certificateFile') or cfg.get('clientCertificateFile')):raise HTTPFault('Certificate authentication requires an identity','HTTP_CONFIGURATION',400)
    timeout=httpx.Timeout(connect=_seconds(cfg,'connectionTimeoutMs','connectTimeoutSeconds',30),read=_seconds(cfg,'socketTimeoutMs','timeoutSeconds',60),write=_seconds(cfg,'writeTimeoutMs','writeTimeoutSeconds',60),pool=_seconds(cfg,'poolTimeoutMs','poolTimeoutSeconds',30))
    if cfg.get('timeout') not in (None,''):timeout=httpx.Timeout(number(cfg,'timeout',30) or None,connect=timeout.connect)
    activity_limit=number(cfg,'activityTimeoutSeconds',180,1)
    for phase in ('connect','read','write','pool'):
        value=getattr(timeout,phase)
        if value is None or value>activity_limit:setattr(timeout,phase,activity_limit)
    started=time.monotonic();maximum=int(number(cfg,'maxResponseBodyBytes',64*1024**2,1));retries=int(number(cfg,'retryCount',0,0,10))
    deadline=started+activity_limit
    # Per-route gates complement HTTPX's global connection limit.
    route=urllib.parse.urlsplit(url).netloc
    gate=_acquire_route(client,route,timeout.pool)
    circuit=None;failed=False
    try:
        circuit=circuit_enter(cfg,route)
        for attempt in range(retries+1):
            try:
                if time.monotonic()>=deadline:raise HTTPFault('HTTP activity timeout','HTTP_TIMEOUT',504)
                pairs=[(key,item) for key,value in headers.items() for item in (value if isinstance(value,list) else [value])]
                from .http_streams import ReplayStream
                content=ReplayStream(content_factory) if content_factory else raw if body is not None or '_mimeEnvelope' in cfg else None
                req=client.build_request(method,url,params=query,headers=pairs,content=content,timeout=timeout)
                if not boolean(cfg.get('enableCookies')) and not any(key.lower()=='cookie' for key in headers):req.headers.pop('cookie',None)
                if scheme=='hmac':
                    if boolean(cfg.get('followRedirects')):raise HTTPFault('Signed HMAC requests cannot follow redirects','HTTP_CONFIGURATION',400)
                    stamp=str(int(time.time()));nonce=uuid.uuid4().hex;signing_body=raw
                    if content_factory:
                        from .http_listener import HashedBody
                        digest=hashlib.sha256()
                        for chunk in content_factory():digest.update(chunk)
                        signing_body=HashedBody(digest.hexdigest())
                    req.headers['X-MINA-Timestamp']=stamp;req.headers['X-MINA-Nonce']=nonce;req.headers['X-MINA-Key-Id']=str(cfg.get('hmacKeyId') or 'default');req.headers['Authorization']='HMAC '+hmac_signature(cfg,method,req.url.raw_path.decode('ascii'),signing_body,stamp,nonce)
                if str(cfg.get('requestEntityProcessing') or 'BUFFERED').upper()=='CHUNKED' and str(cfg.get('httpVersion') or '1.1')=='1.1' and (body is not None or '_mimeEnvelope' in cfg):
                    req.headers.pop('content-length',None);req.headers['Transfer-Encoding']='chunked'
                temporary=None
                cache = None if operation == 'sse_read' else shared_cache_request(cfg, req)
                cached = cached_http_response(cache, req)
                if cached is None and boolean(cfg.get('sharedHttpCache')) and any(
                        directive.strip().lower() == 'only-if-cached' for directive in req.headers.get('cache-control','').split(',')):
                    raise HTTPFault('No fresh cached response is available','HTTP_CACHE_MISS',504)
                response=cached if cached is not None else client.send(req,auth=auth,follow_redirects=boolean(cfg.get('followRedirects')),stream=True)
                try:
                    if operation == 'sse_read':
                        from .http_streams import read_sse
                        if response.status_code != 200 or response.headers.get('content-type','').split(';',1)[0].strip().lower() != 'text/event-stream':
                            raise HTTPFault('Endpoint did not return a successful SSE stream','HTTP_BAD_RESPONSE',502)
                        events = read_sse(response, int(number(cfg,'maxEvents',1,1,1000)), maximum, deadline)
                        failed = False
                        return {'statusCode':200,'events':events,'eventCount':len(events)}
                    if method not in ('GET','HEAD','OPTIONS','TRACE') and response.status_code < 400:
                        invalidate_shared_cache(cfg, req)
                    if attempt<retries and retryable(cfg,method,headers,response.status_code):
                        delay=retry_delay(cfg,attempt,response)
                        response.close()
                        if time.monotonic()+delay>=deadline:raise HTTPFault('HTTP retry exceeds activity timeout','HTTP_TIMEOUT',504)
                        time.sleep(delay);continue
                    has_body=method!='HEAD' and response.status_code not in (204,205,304)
                    destination=cfg.get('responseFile') if has_body else None
                    temporary=None;sink=None
                    if destination:
                        if cfg.get('responseSchema') or cfg.get('_restResponseSchemas'):raise HTTPFault('File download mode cannot bypass configured response schemas','HTTP_CONFIGURATION',400)
                        target=Path(destination).expanduser()
                        if target.exists() and not boolean(cfg.get('overwriteResponseFile')):raise HTTPFault('Response file already exists','HTTP_CONFIGURATION',400)
                        handle=tempfile.NamedTemporaryFile(prefix='.mina-download-',dir=target.parent,delete=False);temporary=Path(handle.name);sink=handle
                    chunks=[];size=0
                    try:
                        for chunk in response.iter_bytes(chunk_size=int(number(cfg,'responseBufferSize',65536,1024,1024**2))) if has_body else ():
                            size+=len(chunk)
                            if size>maximum:raise HTTPFault('HTTP response body limit exceeded','HTTP_BAD_RESPONSE',502)
                            if time.monotonic()>deadline:raise HTTPFault('HTTP activity timeout','HTTP_TIMEOUT',504)
                            if sink:sink.write(chunk)
                            else:chunks.append(chunk)
                    except BaseException:
                        if sink:sink.close();temporary.unlink(missing_ok=True)
                        raise
                    finally:
                        if sink:sink.close()
                    data=b''.join(chunks);text=data.decode(response.encoding or 'utf-8',errors='replace')
                    response_type=response.headers.get('content-type','').split(';',1)[0].lower()
                    value=text
                    if str(cfg.get('responseBodyMode') or '')!='binary' and (not response_type or response_type.endswith(('/json','+json'))):
                        try:value=parse_json(text)
                        except ValueError:
                            if data and response_type:raise HTTPFault('Invalid JSON response body','HTTP_BAD_RESPONSE',502) from None
                    if str(cfg.get('responseBodyMode') or '')=='binary' or response.headers.get('content-type','').split(';')[0].lower()=='application/octet-stream':value=data
                    valid=str(cfg.get('successStatusCodes') or '200-299')
                    accepted=any(int(part.split('-')[0])<=response.status_code<=int(part.split('-')[-1]) for part in valid.replace(' ','').split(','))
                    schema=response_schema(cfg,response.status_code,response.headers.get('content-type',''))
                    if has_body and boolean(cfg.get('validateResponse'),bool(cfg.get('openApiDocument'))) and response_content(cfg,response.status_code) and media_schema(response_content(cfg,response.status_code),response_type)[0] is None:raise HTTPFault('Undeclared response content type','REST_VALIDATION',502)
                    if has_body and boolean(cfg.get('validateResponse'),bool(cfg.get('openApiDocument'))) and schema is not None and schema_errors(value,schema):raise HTTPFault('Response schema validation failed','REST_VALIDATION',502)
                    if boolean(cfg.get('raiseForStatus'),True) and not accepted:
                        if temporary:temporary.unlink(missing_ok=True)
                        raise HTTPFault(f'HTTP response status {response.status_code}','HTTP_CLIENT_ERROR' if response.status_code<500 else 'HTTP_SERVER_ERROR',response.status_code)
                    if temporary:
                        if boolean(cfg.get('overwriteResponseFile')):temporary.replace(target)
                        else:
                            try:os.link(temporary,target)
                            finally:temporary.unlink(missing_ok=True)
                        value={'fileName':str(target),'size':size}
                    result={'statusCode':response.status_code,'headers':{key:response.headers.get_list(key) if len(response.headers.get_list(key))>1 else val for key,val in response.headers.items()},'body':value,'elapsedMs':round((time.monotonic()-started)*1000),'httpVersion':response.http_version}
                    if not destination and (cfg.get('_structuredRequest') or cfg.get('requestModel')=='tree'):
                        try:tree=response_tree(response,data)
                        except (ValueError,LookupError) as error:raise HTTPFault(str(error),'HTTP_BAD_RESPONSE',502) from None
                        tree['body']=value;result['RestOutputResponse']=tree
                    failed=response.status_code>=500
                    if cached is None:
                        store_http_response(cache, response, data)
                    return result
                finally:
                    response.close()
                    if temporary:temporary.unlink(missing_ok=True)
            except (httpx.ConnectError,httpx.ConnectTimeout):
                if attempt>=retries:raise HTTPFault('HTTP connection failed','HTTP_CONNECTIVITY',502) from None
                delay=retry_delay(cfg,attempt)
                if time.monotonic()+delay>=deadline:raise HTTPFault('HTTP retry exceeds activity timeout','HTTP_TIMEOUT',504)
                time.sleep(delay)
            except httpx.TimeoutException:raise HTTPFault('HTTP request timed out','HTTP_TIMEOUT',504) from None
            except httpx.HTTPError:raise HTTPFault('HTTP transport failed','HTTP_CONNECTIVITY',502) from None
            finally:
                if 'content' in locals() and hasattr(content,'close'):content.close()
    except HTTPFault as error:
        failed=error.status>=500;raise
    finally:
        try:circuit_result(cfg,circuit,failed)
        finally:_release_route(client,route,gate)

def _basic(headers):
    try:
        kind,value=headers.get('authorization','').split(' ',1)
        if kind.lower()!='basic':raise ValueError()
        username,password=base64.b64decode(value,validate=True).decode().split(':',1)
        if not username or not password:raise ValueError()
        return username,password
    except Exception:raise HTTPFault('Authentication failed') from None

def ldap_authenticate(cfg,username,password):
    import ldap3
    if not username or not password:raise HTTPFault('Authentication failed')
    url=urllib.parse.urlsplit(str(cfg.get('ldapUrl') or ''))
    if url.scheme not in ('ldap','ldaps') or not url.hostname:raise HTTPFault('LDAP URL must use ldap or ldaps','HTTP_CONFIGURATION',400)
    if url.scheme=='ldap' and not boolean(cfg.get('ldapStartTls'),True):raise HTTPFault('LDAP requires LDAPS or StartTLS','HTTP_CONFIGURATION',400)
    tls=ldap3.Tls(validate=ssl.CERT_REQUIRED,ca_certs_file=cfg.get('ldapCaFile') or None,version=ssl.PROTOCOL_TLS_CLIENT)
    server=ldap3.Server(url.hostname,port=url.port or (636 if url.scheme=='ldaps' else 389),use_ssl=url.scheme=='ldaps',tls=tls,connect_timeout=number(cfg,'ldapTimeoutSeconds',10,1,60))
    connections=[]
    def connect(user,pwd):
        conn=ldap3.Connection(server,user=user,password=pwd,receive_timeout=int(number(cfg,'ldapTimeoutSeconds',10,1,60)),raise_exceptions=True);connections.append(conn);conn.open()
        if url.scheme=='ldap' and not conn.start_tls():raise HTTPFault('Authentication failed')
        if not conn.bind():raise HTTPFault('Authentication failed')
        return conn
    try:
        if cfg.get('ldapUserDnTemplate'):
            from ldap3.utils.dn import escape_rdn
            dn=str(cfg['ldapUserDnTemplate']).replace('{username}',escape_rdn(username))
        else:
            from ldap3.utils.conv import escape_filter_chars
            if not cfg.get('ldapBindDn') or not cfg.get('ldapBindPassword') or not cfg.get('ldapBaseDn'):raise HTTPFault('LDAP search requires bind DN, password and base DN','HTTP_CONFIGURATION',400)
            service=connect(cfg['ldapBindDn'],cfg['ldapBindPassword']);query=str(cfg.get('ldapSearchFilter') or '(uid={username})').replace('{username}',escape_filter_chars(username))
            service.search(cfg['ldapBaseDn'],query,attributes=['memberOf'],size_limit=2)
            if len(service.entries)!=1:raise HTTPFault('Authentication failed')
            dn=service.entries[0].entry_dn
            if cfg.get('ldapRequiredGroup') and str(cfg['ldapRequiredGroup']) not in list(service.entries[0].memberOf.values):raise HTTPFault('Authentication failed')
        user_connection=connect(dn,password)
        if cfg.get('ldapRequiredGroup') and cfg.get('ldapUserDnTemplate'):
            user_connection.search(dn,'(objectClass=*)',search_scope=ldap3.BASE,attributes=['memberOf'],size_limit=1)
            if len(user_connection.entries)!=1 or str(cfg['ldapRequiredGroup']) not in list(user_connection.entries[0].memberOf.values):raise HTTPFault('Authentication failed')
        return {'subject':username}
    except HTTPFault:raise
    except Exception:raise HTTPFault('Authentication failed') from None
    finally:
        for conn in connections:
            try:conn.unbind()
            except Exception:pass

def authorize(cfg,method,target,headers,body=b'',peer_verified=False):
    headers={str(k).lower():str(v) for k,v in headers.items()};scheme=str(cfg.get('authentication') or 'None').lower()
    if scheme=='none':return {}
    if scheme in ('basic','ldap'):
        user,pwd=_basic(headers)
        if scheme=='ldap':return ldap_authenticate(cfg,user,pwd)
        if not cfg.get('username') or not cfg.get('password') or not hmac.compare_digest(user,str(cfg['username'])) or not hmac.compare_digest(pwd,str(cfg['password'])):raise HTTPFault('Authentication failed')
        return {'subject':user}
    if scheme=='certificate':
        if not peer_verified:raise HTTPFault('Verified mutual TLS is required')
        return {'certificateVerified':True}
    authorization=headers.get('authorization','')
    if scheme=='bearer':
        token=str(cfg.get('bearerToken') or '')
        if not token or not hmac.compare_digest(authorization,'Bearer '+token):raise HTTPFault('Authentication failed')
        return {}
    if scheme=='jwt':
        import jwt
        if not authorization.startswith('Bearer ') or not authorization[7:]:raise HTTPFault('Authentication failed')
        alg=str(cfg.get('jwtAlgorithm') or 'HS256')
        if alg not in ('HS256','HS384','HS512','RS256','RS384','RS512','ES256','ES384'):raise HTTPFault('Unsupported JWT algorithm','HTTP_CONFIGURATION',400)
        if cfg.get('jwtJwksUrl'):
            from .http_policy import jwks_key
            key=jwks_key(cfg,authorization[7:])
        else:key=_jwt_key(cfg)
        if not key:raise HTTPFault('JWT verification key is required','HTTP_CONFIGURATION',400)
        try:return jwt.decode(authorization.removeprefix('Bearer '),key,algorithms=[alg],issuer=cfg.get('jwtIssuer') or None,audience=cfg.get('jwtAudience') or None,leeway=number(cfg,'jwtClockSkewSeconds',30,0,300),options={'require':['exp'],'verify_aud':bool(cfg.get('jwtAudience'))})
        except Exception:raise HTTPFault('Authentication failed') from None
    if scheme=='oauth2':
        endpoint=secure_url(str(cfg.get('oauthIntrospectionUrl') or ''),{**cfg,'confidentiality':True})
        if not authorization.startswith('Bearer ') or not authorization[7:]:raise HTTPFault('Authentication failed')
        try:
            data = {'token': authorization[7:]}
            auth = oauth_client_auth(cfg, endpoint, data)
            response=client_for(cfg).post(endpoint,data=data,auth=auth,timeout=number(cfg,'oauthTimeoutSeconds',30,1,300),follow_redirects=False);response.raise_for_status();claims=response.json()
            if claims.get('active') is not True or claims.get('exp') is not None and (not math.isfinite(float(claims['exp'])) or float(claims['exp'])<=time.time()):raise ValueError()
            scopes=set(str(claims.get('scope') or '').split())
            if not set(str(cfg.get('oauthRequiredScopes') or '').split()).issubset(scopes):raise ValueError()
            return claims
        except Exception:raise HTTPFault('Authentication failed') from None
    if scheme=='hmac':
        stamp=headers.get('x-mina-timestamp','');nonce=headers.get('x-mina-nonce','');window=number(cfg,'hmacClockSkewSeconds',300,1,3600)
        try:valid=abs(time.time()-int(stamp))<=window
        except ValueError:valid=False
        if not valid or not re.fullmatch(r'[A-Za-z0-9_-]{16,128}',nonce) or headers.get('x-mina-key-id')!=str(cfg.get('hmacKeyId') or 'default'):raise HTTPFault('Authentication failed')
        expected='HMAC '+hmac_signature(cfg,method,target,body,stamp,nonce)
        if not hmac.compare_digest(authorization,expected):raise HTTPFault('Authentication failed')
        if str(cfg.get('policyStore') or 'memory')=='redis':
            from .http_policy import claim_nonce
            if not claim_nonce(cfg,nonce,2*window):raise HTTPFault('Authentication failed')
            return {'keyId':cfg.get('hmacKeyId') or 'default'}
        with _SECURITY_LOCK:
            now=time.time()
            for key,deadline in list(_NONCES.items()):
                if deadline<now:del _NONCES[key]
            key=hashlib.sha256((str(cfg.get('hmacSecret'))+nonce).encode()).hexdigest()
            if key in _NONCES:raise HTTPFault('Authentication failed')
            if len(_NONCES)>=100000:raise HTTPFault('Authentication capacity exceeded','HTTP_SECURITY',503)
            _NONCES[key]=now+2*window
        return {'keyId':cfg.get('hmacKeyId') or 'default'}
    raise HTTPFault('Unsupported inbound authentication','HTTP_CONFIGURATION',400)
