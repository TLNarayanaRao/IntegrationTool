import json, os, re, shutil, sqlite3, threading
from unicodedata import normalize
from contextlib import closing
from functools import wraps
from pathlib import Path
from uuid import uuid4
from .models import Project
from .retry_policy import outbound_activity

DATA_DIR = Path(os.environ.get('MINA_DATA_DIR', Path(__file__).parents[1] / 'data')).expanduser().resolve()
PROJECTS_DIR = DATA_DIR / 'projects'
LEGACY_DB = DATA_DIR / 'mina.db'
STORE_LOCK = threading.RLock()


def synchronized(operation):
    @wraps(operation)
    def locked(*args, **kwargs):
        with STORE_LOCK: return operation(*args, **kwargs)
    return locked

def safe_component(value: str) -> str:
    reserved = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}
    if not value or not re.fullmatch(r'[A-Za-z0-9_.-]+', value) or value in ('.','..') or value.endswith('.') or value.split('.')[0].upper() in reserved:
        raise ValueError('Identifiers may contain only letters, numbers, dot, dash, and underscore')
    return value

def project_dir(project_id: str) -> Path:
    safe = safe_component(project_id)
    root = PROJECTS_DIR.resolve(); target = (PROJECTS_DIR / safe).resolve()
    if target.parent != root: raise ValueError('Invalid project id')
    return target

def write_json(path: Path, value):
    encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    try:
        # Studio saves the whole project model. Keep unchanged task and
        # connection files out of the write/rename path on shared hosts.
        if path.read_bytes() == encoded:
            return
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{uuid4().hex}.tmp')
    try:
        temporary.write_bytes(encoded)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)

def supports_outbound_retry(activity) -> bool:
    return outbound_activity(activity.type, str(activity.config.get('operation') or ''))

def clean_activity_policies(project: Project) -> None:
    for task in project.tasks:
        for activity in task.activities:
            if supports_outbound_retry(activity): continue
            advanced = activity.config.get('advanced')
            if not isinstance(advanced, dict): continue
            for key in list(advanced):
                if key.startswith('retry'): advanced.pop(key)

def _object_names(project: Project | None) -> dict:
    if project is None: return {}
    names = {}
    key = lambda value: normalize('NFKC', '-'.join(value.split())).lower()
    for category in ('tasks', 'resources', 'schemas'):
        for item in getattr(project, category):
            scope = key(item.package_path), key(item.name)
            names.setdefault(scope, {})[category, item.id] = item
    return names


@synchronized
def save_project(project: Project, *, enforce_names: bool = False) -> Project:
    if enforce_names:
        conflicts = {scope: entries for scope, entries in _object_names(project).items() if len(entries) > 1}
        previous = _object_names(get_project(project.id)) if conflicts else {}
        for scope, entries in conflicts.items():
            if not entries.keys() <= previous.get(scope, {}).keys():
                item = next(iter(entries.values()))
                raise ValueError(f'An object named “{item.name}” already exists in package “{item.package_path}”.')
    # Reject malformed child identifiers before changing any saved files.
    safe_component(project.id)
    for item in [*project.tasks, *project.resources]: safe_component(item.id)
    for items in (project.tasks, project.resources):
        if len({item.id.casefold() for item in items}) != len(items): raise ValueError('Task and resource identifiers must be unique within their collection')
    clean_activity_policies(project)
    folder = project_dir(project.id); tasks_dir = folder / 'tasks'; resources_dir = folder / 'resources'
    metadata = project.model_dump(exclude={'tasks','resources','process'})
    active_task_files = set()
    for task in project.tasks:
        path = tasks_dir / f'{safe_component(task.id)}.json'; write_json(path, task.model_dump()); active_task_files.add(path.resolve())
    active_resource_files = set()
    for resource in project.resources:
        path = resources_dir / f'{safe_component(resource.id)}.json'; write_json(path, resource.model_dump()); active_resource_files.add(path.resolve())
    for path in tasks_dir.glob('*.json') if tasks_dir.exists() else []:
        if path.resolve() not in active_task_files: path.unlink()
    for path in resources_dir.glob('*.json') if resources_dir.exists() else []:
        if path.resolve() not in active_resource_files: path.unlink()
    write_json(folder / 'project.json', metadata)
    return project

@synchronized
def get_project(project_id: str) -> Project | None:
    folder = project_dir(project_id); descriptor = folder / 'project.json'
    if not descriptor.exists():
        migrated = legacy_project(project_id)
        if migrated: save_project(migrated)
        return migrated
    metadata = json.loads(descriptor.read_text(encoding='utf-8'))
    metadata['tasks'] = [json.loads(path.read_text(encoding='utf-8')) for path in sorted((folder/'tasks').glob('*.json'))] if (folder/'tasks').exists() else []
    metadata['resources'] = [json.loads(path.read_text(encoding='utf-8')) for path in sorted((folder/'resources').glob('*.json'))] if (folder/'resources').exists() else []
    return Project.model_validate(metadata)

@synchronized
def list_projects() -> list[Project]:
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    projects = [item for folder in sorted(PROJECTS_DIR.iterdir()) if folder.is_dir() and (item := get_project(folder.name))]
    known = {item.id for item in projects}
    for item in legacy_projects():
        if item.id not in known: save_project(item); projects.append(item)
    return sorted(projects, key=lambda item: item.name.lower())

@synchronized
def delete_project(project_id: str) -> bool:
    folder = project_dir(project_id)
    deleted = folder.exists()
    if deleted: shutil.rmtree(folder)
    if LEGACY_DB.exists():
        try:
            with closing(sqlite3.connect(LEGACY_DB)) as conn:
                cursor = conn.execute('DELETE FROM projects WHERE id = ?', (project_id,))
                deleted = deleted or cursor.rowcount > 0
                conn.commit()
        except sqlite3.Error: pass
    return deleted

def legacy_projects() -> list[Project]:
    if not LEGACY_DB.exists(): return []
    try:
        with closing(sqlite3.connect(LEGACY_DB)) as conn:
            return [Project.model_validate_json(row[0]) for row in conn.execute('SELECT body FROM projects')]
    except (sqlite3.Error, ValueError): return []

def legacy_project(project_id: str) -> Project | None:
    return next((item for item in legacy_projects() if item.id == project_id), None)
